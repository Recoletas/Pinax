import { recordPassageEvidence, validQuotedAnchor } from './manuscriptEvidence.js'
import { inheritForkActor } from './worldForkActor.js'
import { adoptForkVersion } from './worldForkAdoption.js'
import { forkWorldFacts, listWorldFactForks } from './worldFactFork.js'
import { worldClaimText, worldClaimQualifiers } from './worldClaimPresentation.js'
import {
  LEDGER_FAILURE_REASONS,
  EVIDENCE_SOURCE_KINDS,
  PROPOSAL_ORIGINS,
  normalizeScopeRef,
  encodeScopeKey,
  normalizeStoryIntervalInput,
  deriveFactKey,
  worldOperand,
  claimFingerprint,
  payloadHash,
  sameInterval,
  resolvePredicateTemporalKind
} from './ledgerContract.js'
import { ensureWorldClaim, legacyWorldClaimForVersion, listWorldStatements, normalizeWorldClaim } from './worldClaims.js'
import { defineWorldCalendar as defineCalendar, listWorldCalendars, loadCalendarAt, normalizeStoryClock } from './worldCalendars.js'
import { validateTimeline } from '../knowledgeTime.js'
import { orphanAttitudes, eventClock } from './knowledgeReplay.js'
import { currentHeadOf } from './recordAxis.js'
import { planSingleValueTimeline } from './temporalCoordinator.js'
import { LEDGER_TX_TABLES as TX_TABLES } from '../ledgerSchema.js'

export function createFactLedgerModule({ ledgerId } = {}) {

// The single business owner of canonical facts. UI, model tools and backup
// parsers go through this repository; nothing else writes fact tables. Every
// mutation is one Dexie transaction keyed by an explicit commandId: retries
// with the same commandId and payload return the original decision, the same
// commandId with a different payload is refused, and failures leave no
// partial state behind.

const fail = (reason, extra = {}) => ({ ok: false, reason, retryable: reason === LEDGER_FAILURE_REASONS.dbUnavailable, ...extra })

function resolveScope(input) {
  const normalized = normalizeScopeRef(input)
  if (!normalized.ok) return normalized
  return { ok: true, scope: normalized.scope, scopeKey: encodeScopeKey(normalized.scope) }
}

async function allocateSeq(meta, scopeKey) {
  const record = await meta.get(`seq:${scopeKey}`)
  const seq = (Number.isFinite(record?.seq) ? record.seq : 0) + 1
  await meta.put({ id: `seq:${scopeKey}`, seq })
  return seq
}

// Envelope: idempotency probe, sequence allocation, decision write. The
// executor runs inside the transaction and may return {result, ...decision}
// or a plain {ok:false,...} refusal (no decision is written for refusals).
async function runCommand(db, scopeInput, commandId, payloadForHash, executor) {
  const scope = resolveScope(scopeInput)
  if (!scope.ok) return fail(scope.reason)
  const trimmed = typeof commandId === 'string' ? commandId.trim() : ''
  if (!trimmed) return fail('command-id-required')
  try {
    return await db.transaction('rw', TX_TABLES, async () => {
      const tables = {
        evidence: db.table('evidenceSnapshots'),
        proposals: db.table('factProposals'),
        versions: db.table('factVersions'),
        decisions: db.table('factDecisions'),
        rejections: db.table('rejectionMarks'),
        meta: db.table('ledgerMeta'),
        claims: db.table('worldClaims')
      }
      const prior = await tables.decisions.where('commandId').equals(trimmed).first()
      const hash = payloadHash(payloadForHash)
      if (prior) {
        if (prior.scopeKey !== scope.scopeKey || prior.payloadHash !== hash) return fail(LEDGER_FAILURE_REASONS.commandPayloadConflict, { commandId: trimmed, priorDecisionId: prior.id })
        return { ok: true, replay: true, decision: prior, result: prior.result }
      }
      const decisionId = ledgerId('dec')
      const seq = await allocateSeq(tables.meta, scope.scopeKey)
      const outcome = await executor({ tables, seq, scopeKey: scope.scopeKey, scope: scope.scope, decisionId })
      // Refusals always carry ok:false; executor success returns decision
      // fields without an ok flag.
      if (outcome.ok === false) {
        // Dexie commits a returned failure. Throw through its transaction so
        // manual evidence, the sequence counter and all linked writes roll back.
        const refusal = new Error(outcome.reason)
        refusal.ledgerRefusal = outcome
        throw refusal
      }
      const decision = {
        id: decisionId,
        commandId: trimmed,
        scopeKey: scope.scopeKey,
        scope: scope.scope,
        operation: outcome.operation,
        actorKind: 'author',
        actorRef: String(outcome.actorRef || ''),
        reason: String(outcome.reason || ''),
        beforeIds: outcome.beforeIds || [],
        afterIds: outcome.afterIds || [],
        recordedAt: Date.now(),
        recordedSeq: outcome.commitSeq ?? seq,
        payloadHash: hash,
        result: outcome.result || {}
      }
      await tables.decisions.add(decision)
      return { ok: true, replay: false, decision, result: decision.result }
    })
  } catch (error) {
    return error?.ledgerRefusal || fail(LEDGER_FAILURE_REASONS.dbUnavailable, { detail: error?.message || String(error) })
  }
}

// Evidence is immutable once written: quote is the frozen review fragment,
// sourceRevision the version it came from. Re-adding the identical fragment
// returns the existing row (import/retry idempotency).
async function appendEvidence(db, { scope, sourceKind, sourceId, sourceRevision = '', quote = '', recordedAt } = {}) {
  const resolved = resolveScope(scope)
  if (!resolved.ok) return fail(resolved.reason)
  if (!EVIDENCE_SOURCE_KINDS.includes(sourceKind)) return fail('evidence-kind-invalid')
  if (typeof quote !== 'string' || typeof sourceId !== 'string' || !sourceId.trim()) return fail('evidence-invalid')
  if (sourceKind === 'chapter-quote' && !String(sourceRevision || '').trim()) return fail('evidence-revision-required')
  const contentHash = payloadHash({ sourceKind, sourceId: sourceId.trim(), sourceRevision, quote })
  try {
    const table = db.table('evidenceSnapshots')
    return await db.transaction('rw', table, async () => {
      const existing = await table.where('[scopeKey+sourceId]').equals([resolved.scopeKey, sourceId.trim()]).toArray()
      const match = existing.find(row => row.contentHash === contentHash && !row.tombstoneAt)
      if (match) return { ok: true, replay: true, evidence: match }
      const evidence = {
        id: ledgerId('ev'),
        scopeKey: resolved.scopeKey,
        scope: resolved.scope,
        sourceKind,
        sourceId: sourceId.trim(),
        sourceRevision: String(sourceRevision || ''),
        quote,
        contentHash,
        recordedAt: Number.isFinite(Number(recordedAt)) ? Number(recordedAt) : Date.now(),
        tombstoneAt: null
      }
      await table.add(evidence)
      return { ok: true, replay: false, evidence }
    })
  } catch (error) {
    return fail(LEDGER_FAILURE_REASONS.dbUnavailable, { detail: error?.message || String(error) })
  }
}

async function createProposal(db, input) {
  const resolved = resolveScope(input?.scope)
  if (!resolved.ok) return fail(resolved.reason)
  const interval = normalizeStoryIntervalInput(input?.storyInterval, input?.kind)
  if (!interval.ok) return fail(interval.reason)
  const declared = validateTimeline(input?.timeline)
  if (!declared.ok) return fail(declared.error)
  const storyTimeline = declared.timeline && { id: declared.timeline.id, eras: declared.timeline.eras.map(({ id, order }) => ({ id, order })) }
  const timeline = normalizeTimelineConfig(storyTimeline)
  const invalidClock = validateIntervalClock(interval.interval, timeline)
  if (invalidClock) return fail(invalidClock)
  const origin = PROPOSAL_ORIGINS.includes(input?.origin) ? input.origin : 'author'
  const evidenceIds = Array.isArray(input?.evidenceIds) ? [...new Set(input.evidenceIds.filter(id => typeof id === 'string' && id))] : []
  const proposalId = ledgerId('prop')
  const occurrence = evidenceIds.length
    ? payloadHash([resolved.scopeKey, [...evidenceIds].sort(), interval.interval])
    : proposalId
  const claim = normalizeWorldClaim(input || {}, occurrence)
  if (!claim.ok) return fail(claim.reason)
  const fingerprint = claimFingerprint(resolved.scopeKey, claim.claim)
  try {
    return await db.transaction('rw', ['factProposals', 'evidenceSnapshots', 'rejectionMarks', 'factVersions'], async () => {
      const tables = { proposals: db.table('factProposals'), evidence: db.table('evidenceSnapshots'), rejections: db.table('rejectionMarks'), versions: db.table('factVersions') }
      for (const evidenceId of evidenceIds) {
        const evidence = await tables.evidence.get(evidenceId)
        if (!evidence || evidence.scopeKey !== resolved.scopeKey) return fail(LEDGER_FAILURE_REASONS.evidenceMissing, { evidenceId })
      }
      const primary = evidenceIds.length ? await tables.evidence.get(evidenceIds[0]) : null
      const sourceRevision = primary?.sourceRevision || ''
      // Same claim, same source revision, still pending → idempotent re-propose.
      const pending = await tables.proposals.where('[scopeKey+status]').equals([resolved.scopeKey, 'pending']).toArray()
      const duplicate = pending.find(row => row.fingerprint === fingerprint
        && (row.kind || claim.claim.kind) === claim.claim.kind && row.origin === origin
        && sameInterval(row.storyTimeline ?? null, storyTimeline)
        && (row.sourceRevision || '') === sourceRevision && sameInterval(row.storyInterval, interval.interval)
        && evidenceIds.length === row.evidenceIds.length && evidenceIds.every(id => row.evidenceIds.includes(id)))
      if (duplicate) return { ok: true, replay: true, proposal: duplicate }
      // A rejected claim with an unchanged source stays suppressed (A09): it
      // neither re-enters review nor adopts. A changed sourceRevision is a new
      // reviewable proposal; reopening the mark also lifts the suppression.
      const marks = await tables.rejections.where('[scopeKey+fingerprint]').equals([resolved.scopeKey, fingerprint]).toArray()
      const suppressedBy = marks.find(mark => !mark.reopenedAt && (mark.sourceRevision || '') === sourceRevision)
      if (suppressedBy) return { ok: true, suppressed: true, rejectionMarkId: suppressedBy.id }
      const proposal = {
        id: proposalId,
        schemaVersion: 2,
        scopeKey: resolved.scopeKey,
        scope: resolved.scope,
        ...claim.claim,
        factKey: deriveFactKey(claim.claim),
        evidenceIds,
        sourceRevision,
        storyInterval: interval.interval,
        ...(storyTimeline ? { storyTimeline } : {}),
        baseRevision: typeof input?.baseRevision === 'string' ? input.baseRevision : '',
        status: 'pending',
        origin,
        fingerprint,
        createdAt: Date.now()
      }
      // M03：单值状态谓词在提案阶段计算时序协调计划，随提案进入真实确认
      // 入口——作者看到将收口哪些旧版本、有哪些需要人工裁决的对子，然后才
      // 决定是否接受。
      proposal.temporalPlanV1 = await buildTemporalPlan(tables, {
        scopeKey: resolved.scopeKey,
        factKey: proposal.factKey,
        claim: claim.claim,
        interval: interval.interval,
        timeline
      })
      await tables.proposals.add(proposal)
      return { ok: true, replay: false, proposal }
    })
  } catch (error) {
    return fail(LEDGER_FAILURE_REASONS.dbUnavailable, { detail: error?.message || String(error) })
  }
}

function invalidation(now, seq) {
  return { invalidatedAt: now, invalidatedSeq: seq }
}

// 收口后继不是 succession：head 查找必须跳过它们，否则旧值的收口行会被
// 误认为当前事实。
function successionHead(versions) {
  return currentHeadOf(versions.filter(row => !row.supersedesKind))
}

// ── M03（nightly-20260918）：时序协调接线 ─────────────────────────────
// 提案创建时对单值状态谓词计算协调计划（纯算法见 temporalCoordinator），
// 计划随提案走真实确认入口；采纳在同一 Dexie 事务里原子写入故事轴收口
// （失败无半提交）。作者不点接受，任何收口都不发生。

const TEMPORAL_PLAN_LIMITS = Object.freeze({ maxCloses: 8, maxConflicts: 8 })

function normalizeTimelineConfig(input) {
  if (!input || !validateTimeline(input).ok) return null
  return { id: input.id, eras: new Map(input.eras.map(era => [era.id, era.order])) }
}

function validateIntervalClock(interval, timeline) {
  if (!timeline && interval?.endBy && interval.start.eraId !== interval.endBy.eraId) return 'timeline-era-invalid'
  if (!timeline && interval?.eventSpan && interval.start.eraId !== interval.end.eraId) return 'timeline-era-invalid'
  if (!timeline || !interval) return null
  if (interval.timelineId !== timeline.id) return 'timeline-mismatch'
  if ([interval.start, interval.end, interval.endBy].some(point => point && !timeline.eras.has(point.eraId))) return 'timeline-era-invalid'
  if (interval.endBy && compareBoundary(interval.start, interval.endBy, timeline) !== -1) return 'story-interval-invalid'
  if (compareBoundary(interval.start, interval.end, timeline) === 1) return 'story-interval-invalid'
  return null
}

// The coordinator compares scalar positions. Rank the actual boundaries
// within this proposal, then return their original era and ordinal to callers.
function rankBoundaries(intervals, timeline) {
  const byKey = new Map()
  const key = point => JSON.stringify([point.eraId, point.ordinal])
  for (const interval of intervals) {
    for (const point of [interval?.start, interval?.end]) {
      if (timeline?.eras.has(point?.eraId) && Number.isSafeInteger(point.ordinal)) byKey.set(key(point), point)
    }
  }
  const ordered = [...byKey.values()].sort((a, b) => compareBoundary(a, b, timeline))
  const ranks = new Map(ordered.map((point, i) => [key(point), i]))
  return { rank: point => point ? ranks.get(key(point)) ?? null : null,
    point: index => index == null ? null : ordered[index] }
}

// 版本 → 协调行。open = 无终点记录（endSemantic 'open' 或无 interval）；
// exclusive end 是作者写明的终点（引擎不得改写）；unknown 是"结束了，不知
// 哪天"（0022：未知日期不是开放终点）；引擎收口过的行带 endDerived 标记，
// 之后仍可被更好的后任重算。
function sameEventContext(left, right) {
  return payloadHash(left.eventContext ?? null) === payloadHash(right.eventContext ?? null)
}

function operandKey(claim) {
  return JSON.stringify(worldOperand(claim))
}

// Compare only declared eras on the same timeline. Within an era, integer
// ordinals compare directly even when a caller did not submit an era ladder.
function compareBoundary(left, right, timeline) {
  if (!left || !right) return null
  if (left.eraId === right.eraId) return Number.isSafeInteger(left.ordinal) && Number.isSafeInteger(right.ordinal)
    ? Math.sign(left.ordinal - right.ordinal) : null
  const a = timeline?.eras?.get(left.eraId)
  const b = timeline?.eras?.get(right.eraId)
  return Number.isFinite(a) && Number.isFinite(b) && a !== b ? Math.sign(a - b) : null
}

function temporalRowFromVersion(version, rank) {
  const interval = version.validInterval
  const hasExplicitEnd = interval?.endSemantic === 'exclusive' && interval?.end
  return {
    id: version.id,
    objectKey: operandKey(version),
    from: rank(interval?.start),
    to: hasExplicitEnd ? rank(interval.end) : null,
    endUnknown: interval?.endSemantic === 'unknown',
    anchorAt: null,
    endDerived: interval?.endDerived === true,
    authority: version.authority === 'author-confirmed' ? 'author' : 'derived'
  }
}

function temporalRowFromClaim(claim, interval, rank) {
  return {
    id: 'incoming',
    objectKey: operandKey(claim),
    from: rank(interval?.start),
    to: interval?.endSemantic === 'exclusive' && interval?.end ? rank(interval.end) : null,
    endUnknown: interval?.endSemantic === 'unknown',
    anchorAt: null,
    endDerived: false,
    authority: 'author'
  }
}

// 提案落库前计算协调计划：只对单值状态谓词；多值/事件由分类合同排除。
async function buildTemporalPlan(tables, { scopeKey, factKey, claim, interval, timeline }) {
  if (resolvePredicateTemporalKind(claim.predicate, claim.kind) !== 'single-value-state') return null
  const versions = (await tables.versions.where('[scopeKey+factKey]').equals([scopeKey, factKey]).toArray())
    .filter(row => !row.invalidatedAt && (!interval || !row.validInterval || row.validInterval.timelineId === interval.timelineId))
  // M04：与 head 完全一致的主张（同宾语、同故事区间）采纳时必被 no-change
  // 拒绝——不为它生成永远不会被执行的收口计划。
  const head = successionHead(versions)
  if (head && operandKey(head) === operandKey(claim) && sameInterval(head.validInterval, interval)) return null
  const positions = rankBoundaries([interval, ...versions.map(row => row.validInterval)], timeline)
  const describeEnd = end => end.kind === 'at' ? { ...end, at: positions.point(end.at) } : end
  const plan = planSingleValueTimeline({
    rows: versions.map(row => temporalRowFromVersion(row, positions.rank)),
    incoming: temporalRowFromClaim(claim, interval, positions.rank)
  })
  // 有界存储：超出上限的收口/冲突不静默丢弃语义——标记 truncated。
  const closes = plan.closes.slice(0, TEMPORAL_PLAN_LIMITS.maxCloses).map(close => ({
    id: close.id,
    from: positions.point(close.from),
    currentEnd: describeEnd(close.currentEnd),
    proposedEnd: describeEnd(close.proposedEnd),
    reason: close.reason,
    // 采纳前防并发：计划时的区间指纹；采纳时不一致则该收口按过期跳过
    snapshotHash: (() => {
      const target = versions.find(row => row.id === close.id)
      return target ? payloadHash({ interval: target.validInterval }) : null
    })()
  }))
  const conflicts = plan.conflicts.slice(0, TEMPORAL_PLAN_LIMITS.maxConflicts)
  if (!closes.length && !conflicts.length) return null
  return {
    version: 1,
    kind: plan.kind,
    closes,
    conflicts,
    truncated: plan.closes.length > closes.length || plan.conflicts.length > conflicts.length
  }
}

// 采纳事务内应用收口：故事轴终点写到新版本的起点（exclusive），并保留
// endDerived 标记；计划时指纹不符（来源已被并发更正/作废）的收口按过期
// 跳过并如实回报，绝不猜。
// M05 写形状（对齐上游"作废+改写"而非原地改）：每个收口目标保留原行
// （原样开着，被作废——as-of 收口之前回放看到的是开放形状），另铸一行
// "收口后继"（闭区间 + endDerived 标记，supersedes 指回目标）。撤销收口
// = 作废后继、复活目标，两个方向的双轴回放都成立。
async function applyTemporalCloses(tables, { plan, timeline, newVersion, scopeKey, currentHeadId, allocateCloseSeq, now }) {
  const applied = []
  const skipped = []
  for (const close of plan?.closes || []) {
    // A backfilled incoming interval is closed on insertion, below.
    if (close.id === 'incoming') continue
    const target = await tables.versions.get(close.id)
    if (!target || target.scopeKey !== scopeKey) {
      skipped.push({ id: close.id, reason: 'target-missing' })
      continue
    }
    // 本次采纳对 head 的 succession 作废（同事务）不阻断其收口；只有更早
    // 命令里已作废的目标才按过期跳过。
    if (target.invalidatedAt && target.id !== currentHeadId) {
      skipped.push({ id: close.id, reason: 'target-invalidated' })
      continue
    }
    if (close.snapshotHash && payloadHash({ interval: target.validInterval }) !== close.snapshotHash) {
      skipped.push({ id: close.id, reason: 'target-changed-since-plan' })
      continue
    }
    const proposed = close.proposedEnd || {}
    const endSemantic = { 'unknown-end': 'unknown', at: 'exclusive', open: 'open' }[proposed.kind]
    const source = proposed.derivedFrom && proposed.derivedFrom !== 'incoming'
      ? await tables.versions.get(proposed.derivedFrom) : newVersion
    if (!source || source.scopeKey !== scopeKey || source.factKey !== newVersion.factKey || (source.invalidatedAt && source.id !== currentHeadId)) {
      skipped.push({ id: close.id, reason: 'end-source-changed' })
      continue
    }
    const end = endSemantic === 'exclusive' ? source.validInterval?.start : null
    if (!endSemantic || (endSemantic === 'exclusive' && (!end || compareBoundary(target.validInterval?.start, end, timeline) !== -1))) {
      skipped.push({ id: close.id, reason: 'end-source-changed' })
      continue
    }
    const closedInterval = {
      ...(target.validInterval || { timelineId: newVersion.validInterval?.timelineId || 'default' }),
      end,
      endSemantic,
      endDerived: true
    }
    const closeSeq = await allocateCloseSeq()
    // 目标作废（收口 caused）；原区间不动地留在行上供 as-of 回放。
    await tables.versions.update(target.id, { invalidatedAt: now, invalidatedSeq: closeSeq })
    const closureRow = {
      id: ledgerId('fv'),
      schemaVersion: 2,
      factKey: target.factKey,
      ...(target.claimId ? { claimId: target.claimId, kind: target.kind } : {}),
      ...worldClaimQualifiers(target),
      ...(target.objectRef ? { objectRef: target.objectRef } : {}),
      ...(target.occurrenceId ? { occurrenceId: target.occurrenceId } : {}),
      scopeKey: target.scopeKey,
      scope: target.scope,
      subjectKey: target.subjectKey,
      subjectLabel: target.subjectLabel,
      predicate: target.predicate,
      object: target.object,
      evidenceIds: [...(target.evidenceIds || [])],
      validInterval: closedInterval,
      recordedAt: now,
      recordedSeq: closeSeq,
      supersedes: target.id,
      // head 目标的收口与 head 交接纠缠（目标作废来自 succession），撤销
      // 须经既有更正/撤回流程；只有纯时序收口（'temporal-closure'）可撤销。
      supersedesKind: target.id === currentHeadId ? 'temporal-closure-head' : 'temporal-closure',
      authority: target.authority,
      origin: target.origin,
      legacyRefs: null
    }
    await tables.versions.add(closureRow)
    applied.push({ id: closureRow.id, ofVersion: target.id, endSemantic: closedInterval.endSemantic })
  }
  return { applied, skipped }
}

// M05：撤销一次引擎收口（作者显式命令）。收口行是引擎**派生**的区间
// 断言——撤销只作废这一行，不动作者的采纳（succession）与目标行：任何
// 时点的回放都不会出现双重取值。作者若想改的是收口**点**，走对收口行的
// 既有更正流程（人工更正会去掉 endDerived 标记）。
async function revertTemporalClosure(db, input) {
  const payload = {
    scope: input?.scope, closureVersionId: input?.closureVersionId,
    actorRef: input?.actorRef ?? '', reason: input?.reason ?? ''
  }
  return runCommand(db, payload.scope, input?.commandId, payload, async ({ tables, seq, scopeKey }) => {
    const closure = await tables.versions.get(payload.closureVersionId)
    if (!closure || closure.scopeKey !== scopeKey) return fail(LEDGER_FAILURE_REASONS.factNotFound, { closureVersionId: payload.closureVersionId })
    if (!closure.supersedesKind || !closure.supersedesKind.startsWith('temporal-closure')) {
      return fail('not-temporal-closure', { closureVersionId: closure.id })
    }
    if (closure.invalidatedAt) return fail('closure-already-reverted', { closureVersionId: closure.id })
    const now = Date.now()
    await tables.versions.update(closure.id, { invalidatedAt: now, invalidatedSeq: seq })
    return {
      operation: 'revert-temporal-closure',
      actorRef: payload.actorRef,
      reason: payload.reason,
      beforeIds: [closure.id],
      afterIds: [],
      result: { revertedClosureId: closure.id, ofVersion: closure.supersedes, factKey: closure.factKey }
    }
  })
}

// Adopt a pending proposal as a canonical fact version. Concurrent adopts of
// the same proposal resolve to one fact: the second transaction reads the
// already-adopted status and refuses (or replays under the same commandId).
async function adoptProposal(db, input) {
  const payload = {
    scope: input?.scope, proposalId: input?.proposalId,
    object: input?.object ?? null, storyInterval: input?.storyInterval ?? null,
    evidenceIds: input?.evidenceIds ?? [], manualAssertion: Boolean(input?.manualAssertion),
    expectedHead: input?.expectedHead ?? null, actorRef: input?.actorRef ?? '', reason: input?.reason ?? '',
    // M06：调用方（事实审核入口）提供的来源现时性（evidenceId → 'current' |
    // 'revision-changed' | 'source-deleted'）。给出且存在非 current 时，必须
    // 显式 allowStaleEvidence 才能接受——旧引用不再静默当有效证据。
    evidenceCurrentness: (input?.evidenceCurrentness && typeof input.evidenceCurrentness === 'object')
      ? input.evidenceCurrentness
      : null,
    allowStaleEvidence: input?.allowStaleEvidence === true
  }
  if (input?.literalValue !== undefined) payload.literalValue = input.literalValue
  return runCommand(db, payload.scope, input?.commandId, payload, context => adoptInTransaction(context, payload))
}

async function adoptInTransaction({ tables, seq, scopeKey, scope }, payload) {
  const proposal = await tables.proposals.get(payload.proposalId)
  if (!proposal || proposal.scopeKey !== scopeKey) return fail(LEDGER_FAILURE_REASONS.proposalNotFound)
  if (proposal.status === 'adopted') return fail(LEDGER_FAILURE_REASONS.proposalAlreadyAdopted, { adoptedVersionId: proposal.adoptedVersionId || null })
  if (proposal.status !== 'pending') return fail(LEDGER_FAILURE_REASONS.proposalNotPending, { status: proposal.status })

  const claim = normalizeWorldClaim({
    ...proposal,
    literalValue: Object.hasOwn(payload, 'literalValue') ? payload.literalValue : proposal.literalValue,
    object: payload.object ?? (Object.hasOwn(payload, 'literalValue') ? null : proposal.object),
    objectRef: payload.object !== null && payload.object !== proposal.object ? null : proposal.objectRef
  }, proposal.id)
  if (!claim.ok) return fail(claim.reason)
  let factKey = deriveFactKey(claim.claim)
  // A pre-upgrade relation may already have one valid operand in the old
  // subject/predicate slot. Continue that particular assertion in place.
  // Another endpoint always gets its own key.
  const legacyKey = `fact:${claim.claim.subjectKey}:${claim.claim.predicate}`
  if (factKey !== legacyKey && claim.claim.kind === 'relation' && !claim.claim.objectRef && !claim.claim.literalValue && !claim.claim.polarity) {
    const legacy = successionHead(await tables.versions.where('[scopeKey+factKey]').equals([scopeKey, legacyKey]).toArray())
    if (legacy && (!legacy.kind || legacy.kind === 'relation') && legacy.subjectKey === claim.claim.subjectKey
      && legacy.predicate === claim.claim.predicate && legacy.object === claim.claim.object) factKey = legacyKey
  } else if (!proposal.kind && claim.claim.kind === 'state' && proposal.factKey) {
    factKey = proposal.factKey
  }

  const evidenceIds = [...new Set([...proposal.evidenceIds, ...payload.evidenceIds])]
  for (const evidenceId of evidenceIds) {
    const evidence = await tables.evidence.get(evidenceId)
    if (!evidence || evidence.scopeKey !== scopeKey) return fail(LEDGER_FAILURE_REASONS.evidenceMissing, { evidenceId })
  }
  let effectiveEvidenceIds = evidenceIds
  if (!effectiveEvidenceIds.length) {
    // A missing source may never be one-click promoted (G-A11); AI-origin
    // proposals must carry evidence. Only an explicit author manual
    // assertion can ground an otherwise sourceless claim.
    if (proposal.origin !== 'author' || !payload.manualAssertion) return fail(LEDGER_FAILURE_REASONS.evidenceMissing)
    const quote = claim.claim.polarity === 'negative' ? worldClaimText(claim.claim) : claim.claim.object
    const assertion = {
      id: ledgerId('ev'),
      scopeKey,
      scope,
      sourceKind: 'manual-assertion',
      sourceId: `author:${String(payload.actorRef || 'unknown')}`,
      sourceRevision: '',
      quote,
      contentHash: payloadHash({ quote }),
      recordedAt: Date.now(),
      tombstoneAt: null
    }
    await tables.evidence.add(assertion)
    effectiveEvidenceIds = [assertion.id]
  }

  // M06：来源现时性防线——审核入口给了现时性且证据已过期/删除时，
  // 未经作者显式确认（allowStaleEvidence）拒绝接受。
  if (payload.evidenceCurrentness) {
    const stale = effectiveEvidenceIds
      .filter(id => ['revision-changed', 'source-deleted'].includes(payload.evidenceCurrentness[id]))
    if (stale.length && !payload.allowStaleEvidence) {
      return fail('evidence-source-stale', { evidenceIds: stale, statuses: stale.map(id => payload.evidenceCurrentness[id]) })
    }
  }

  const fingerprint = claimFingerprint(scopeKey, claim.claim)
  const marks = await tables.rejections.where('[scopeKey+fingerprint]').equals([scopeKey, fingerprint]).toArray()
  const primaryEvidence = await tables.evidence.get(effectiveEvidenceIds[0])
  const sourceRevision = primaryEvidence?.sourceRevision || ''
  const activeRejection = marks.find(mark => !mark.reopenedAt && (mark.sourceRevision || '') === sourceRevision)
  if (activeRejection) return fail(LEDGER_FAILURE_REASONS.rejectionActive, { rejectionMarkId: activeRejection.id })

  const intervalInput = payload.storyInterval !== null ? payload.storyInterval : proposal.storyInterval
  const interval = normalizeStoryIntervalInput(intervalInput, claim.claim.kind)
  if (!interval.ok) return fail(interval.reason)

  const timeline = normalizeTimelineConfig(proposal.storyTimeline)
  if (proposal.storyTimeline && !timeline) return fail('timeline-invalid')
  const invalidClock = validateIntervalClock(interval.interval, timeline)
  if (invalidClock) return fail(invalidClock)
  // The reviewer can edit the object or interval while accepting. A plan
  // computed for the untouched draft cannot close the edited interval.
  const temporalPlan = sameInterval(interval.interval, proposal.storyInterval) && operandKey(claim.claim) === operandKey(proposal)
    ? proposal.temporalPlanV1
    : await buildTemporalPlan(tables, { scopeKey, factKey, claim: claim.claim, interval: interval.interval, timeline })
  const history = await tables.versions.where('[scopeKey+factKey]').equals([scopeKey, factKey]).toArray()
  const head = successionHead(history)
  if (payload.expectedHead !== null && payload.expectedHead !== (head?.id || null)) {
    return fail(LEDGER_FAILURE_REASONS.headConflict, { expectedHead: payload.expectedHead, actualHead: head?.id || null })
  }

  // M04：重复结束证据不重复生成版本。同一主张（同主语/谓词/宾语）且
  // 故事区间形状一致时，接受只会再铸一个内容相同的版本——拒绝而不是
  // 制造冗余修订；来源修订变化后提案本就会重新进入审阅（A09）。
  if (head
    && operandKey(head) === operandKey(claim.claim)
    && sameEventContext(head, claim.claim)
    && sameInterval(head.validInterval, interval.interval)) {
    return fail(LEDGER_FAILURE_REASONS.noChange, { headVersionId: head.id })
  }

  // An entry recorded today can describe a state before the current story
  // head. Close that historical interval at its known successor, preserving
  // the later head, and re-close any earlier interval affected by the insert.
  let validInterval = interval.interval
  let successor = null
  const periodFact = claim.claim.kind === 'state' || claim.claim.kind === 'relation'
  if (periodFact && validInterval?.start) {
    if (head?.validInterval && head.validInterval.timelineId !== validInterval.timelineId) return fail('timeline-mismatch')
    for (const version of history) {
      const other = version.validInterval
      if (version.invalidatedSeq != null || other?.timelineId !== validInterval.timelineId) continue
      const order = compareBoundary(other.start, validInterval.start, timeline)
      if (order === 0 && version.supersedesKind && operandKey(version) !== operandKey(claim.claim)) {
        return fail('story-interval-conflict', { factVersionId: version.id })
      }
      if (claim.claim.kind === 'relation' && (order === -1 || order === 0)) {
        const endOrder = compareBoundary(other.end, validInterval.start, timeline)
        if (other.endSemantic === 'open') return fail(LEDGER_FAILURE_REASONS.noChange, { headVersionId: version.id })
        if (other.endSemantic === 'exclusive' && endOrder === 1) return fail('story-interval-conflict', { factVersionId: version.id })
      }
      if (order === 1 && (!successor || compareBoundary(other.start, successor.validInterval.start, timeline) === -1)) successor = version
      if (order === -1 && other.endSemantic === 'exclusive' && !other.endDerived &&
          compareBoundary(other.end, validInterval.start, timeline) === 1 && operandKey(version) !== operandKey(claim.claim)) {
        return fail('story-interval-conflict', { factVersionId: version.id })
      }
    }
    if (successor) {
      if (validInterval.endSemantic === 'open') {
        validInterval = { ...validInterval, end: successor.validInterval.start, endSemantic: 'exclusive', endDerived: true }
      } else if (validInterval.endSemantic === 'exclusive' && compareBoundary(validInterval.end, successor.validInterval.start, timeline) === 1) {
        return fail('story-interval-conflict', { factVersionId: successor.id })
      }
    }
  }
  if (successor && validInterval.endSemantic === 'exclusive') {
    const covered = history.find(row => {
      const prior = row.validInterval
      if (row.invalidatedSeq != null || prior?.timelineId !== validInterval.timelineId ||
          operandKey(row) !== operandKey(claim.claim)) return false
      const from = compareBoundary(prior.start, validInterval.start, timeline)
      const to = compareBoundary(prior.end, validInterval.end, timeline)
      return (from === -1 || from === 0) && (prior.endSemantic === 'open' ||
        (prior.endSemantic === 'exclusive' && (to === 0 || to === 1)))
    })
    if (covered) return fail(LEDGER_FAILURE_REASONS.noChange, { headVersionId: covered.id })
  }
  const superseded = successor ? null : head
  const claimId = await ensureWorldClaim(tables.claims, { scopeKey, scope, seq }, claim.claim)
  const now = Date.now()
  if (superseded) await tables.versions.update(superseded.id, invalidation(now, seq))
  const version = {
    id: ledgerId('fv'),
    schemaVersion: 2,
    factKey,
    scopeKey,
    scope,
    ...claim.claim,
    claimId,
    evidenceIds: effectiveEvidenceIds,
    validInterval,
    recordedAt: now,
    recordedSeq: seq,
    supersedes: superseded?.id || null,
    ...(successor ? { supersedesKind: 'historical-state' } : {}),
    authority: 'author-confirmed',
    origin: proposal.origin,
    legacyRefs: proposal.baseRevision ? { legacyCandidateId: proposal.baseRevision } : null
  }
  await tables.versions.add(version)
  // M03：同一事务内应用协调收口——旧版本作废（head 已在上面按记录轴
  // 处理）与故事轴区间收口、新版本写入、提案状态翻转要么全成要么全滚，
  // 失败无半提交。
  let commitSeq = seq
  const allocateVersionSeq = async () => (commitSeq = await allocateSeq(tables.meta, scopeKey))
  let temporalApplied = []
  let temporalSkipped = []
  if (temporalPlan?.version === 1) {
    const outcome = await applyTemporalCloses(tables, {
      plan: temporalPlan,
      timeline,
      newVersion: version,
      scopeKey,
      currentHeadId: superseded?.id || null,
      allocateCloseSeq: allocateVersionSeq,
      now
    })
    temporalApplied = outcome.applied
    temporalSkipped = outcome.skipped
  }
  const historicalIds = []
  if (superseded && periodFact && validInterval?.start &&
      compareBoundary(superseded.validInterval?.start, validInterval.start, timeline) === -1 &&
      !temporalApplied.some(close => close.ofVersion === superseded.id)) {
    // A state which already had an explicit end needs no closure proposal.
    // Keep its established story interval visible when the newer head takes
    // over. A subsequent observation of the same value also keeps the prefix.
    const oldInterval = superseded.validInterval
    const preserve = oldInterval.endSemantic !== 'open' || !temporalSkipped.length
    if (preserve) {
      const id = ledgerId('fv')
      const retained = oldInterval.endSemantic === 'open'
        ? { ...oldInterval, end: validInterval.start, endSemantic: 'exclusive', endDerived: true } : oldInterval
      const copy = { ...superseded, id, recordedAt: now, recordedSeq: await allocateVersionSeq(), validInterval: retained,
        supersedes: superseded.id, supersedesKind: 'historical-state', invalidatedAt: null, invalidatedSeq: null }
      await tables.versions.add(copy)
      historicalIds.push(id)
    }
  }
  if (commitSeq !== seq) {
    // Physical sequences are unique for cursor paging. Visibility starts at
    // the final sequence for every row written by this author decision.
    for (const id of [version.id, ...historicalIds, ...temporalApplied.map(row => row.id)]) {
      await tables.versions.update(id, { visibleFromSeq: commitSeq })
    }
    for (const id of new Set([superseded?.id, ...temporalApplied.map(row => row.ofVersion)].filter(Boolean))) {
      await tables.versions.update(id, { invalidatedSeq: commitSeq })
    }
  }
  await tables.proposals.update(proposal.id, { status: 'adopted', adoptedVersionId: version.id })
  return {
    operation: 'adopt-proposal',
    commitSeq,
    actorRef: payload.actorRef,
    reason: payload.reason,
    beforeIds: superseded ? [superseded.id] : [],
    afterIds: [version.id, ...historicalIds, ...temporalApplied.map(entry => entry.id)],
    result: {
      factVersionId: version.id,
      claimId,
      factKey,
      proposalId: proposal.id,
      temporalCloses: { applied: temporalApplied, skipped: temporalSkipped },
      temporalConflicts: temporalPlan?.conflicts || []
    }
  }
}

// Manual authoring and ordinary proposal review share the same adoption code,
// evidence gate, rejection checks, temporal plan and decision transaction.
async function saveWorldStatement(db, input = {}) {
  const { scope, commandId, authority, storyAt = null, actorRef = '' } = input
  if (!['fact', 'rumor'].includes(authority)) return fail('claim-authority-invalid')
  if (storyAt !== null && !Number.isSafeInteger(storyAt)) return fail('story-time-invalid')
  const normalized = normalizeWorldClaim(input, typeof commandId === 'string' ? commandId.trim() : '')
  if (!normalized.ok) return fail(normalized.reason)
  const claim = normalized.claim
  const factPassage = input.factPassage ?? null
  if (factPassage !== null && (authority !== 'fact' || !validFactPassage(scope, factPassage))) return fail('manuscript-anchor-invalid')
  const periodEnd = input.periodEnd ?? null
  if (periodEnd !== null && authority !== 'fact') return fail('story-interval-invalid')
  const eventEnd = input.eventEnd ?? null
  if (eventEnd !== null && (authority !== 'fact' || claim.kind !== 'event')) return fail('story-interval-invalid')
  const storyClock = normalizeStoryClock(input.storyClock)
  if (!storyClock || (input.storyClock && (storyAt === null || authority !== 'fact'))) return fail('story-clock-invalid')
  const payload = { operation: 'save-world-statement', scope, authority, claim, storyAt, actorRef, ...(factPassage ? { factSource: factPassage.manuscriptAnchor } : {}), ...(eventEnd !== null ? { eventEnd } : {}), ...(periodEnd !== null ? { periodEnd } : {}), ...(input.storyClock ? { storyClock } : {}) }
  return runCommand(db, scope, commandId, payload, async context => {
    if (authority === 'rumor') {
      const claimId = await ensureWorldClaim(context.tables.claims, context, claim)
      return { operation: 'record-world-claim', actorRef, afterIds: [claimId], result: { claimId, storyAt } }
    }
    return adoptManualClaim(db, context, claim, storyAt, actorRef, storyClock, eventEnd, factPassage, periodEnd)
  })
}

// A rebuttal refers to the same occurrence, even if this person knows only
// the denial. Recording a counterclaim does not grant knowledge or authority.
async function recordOppositeClaim(db, { scope, commandId, claimId, actorRef = '' } = {}) {
  return runCommand(db, scope, commandId, { operation: 'record-opposite-claim', claimId, actorRef }, async context => {
    const source = await context.tables.claims.get(claimId)
    if (!source || source.scopeKey !== context.scopeKey) return fail('claim-not-found')
    const opposite = normalizeWorldClaim({ ...source, polarity: source.polarity === 'negative' ? 'positive' : 'negative' }, source.occurrenceId)
    if (!opposite.ok) return fail(opposite.reason)
    const id = await ensureWorldClaim(context.tables.claims, context, opposite.claim)
    if ((await context.tables.claims.get(id)).recordedSeq !== context.seq) return fail('claim-already-exists', { claimId: id })
    return { operation: 'record-opposite-claim', actorRef, beforeIds: [source.id], afterIds: [id], result: { claimId: id } }
  })
}

async function confirmWorldClaim(db, { scope, commandId, claimId, storyAt = null, eventEnd = null, periodEnd = null, factPassage = null, storyClock: clock, actorRef = '' } = {}) {
  if (typeof claimId !== 'string' || !claimId) return fail('claim-invalid')
  if (factPassage !== null && !validFactPassage(scope, factPassage)) return fail('manuscript-anchor-invalid')
  if (storyAt !== null && !Number.isSafeInteger(storyAt)) return fail('story-time-invalid')
  const storyClock = normalizeStoryClock(clock)
  if (!storyClock || (clock && storyAt === null)) return fail('story-clock-invalid')
  return runCommand(db, scope, commandId, { operation: 'confirm-world-claim', scope, claimId, storyAt, actorRef, ...(factPassage ? { factSource: factPassage.manuscriptAnchor } : {}), ...(eventEnd !== null ? { eventEnd } : {}), ...(periodEnd !== null ? { periodEnd } : {}), ...(clock ? { storyClock } : {}) }, async context => {
    const claim = await context.tables.claims.get(claimId)
    if (!claim || claim.scopeKey !== context.scopeKey) return fail('claim-not-found')
    const previous = await context.tables.versions.where('[scopeKey+subjectKey]').equals([context.scopeKey, claim.subjectKey])
      .filter(row => row.claimId === claimId).first()
    if (previous) return fail('claim-already-adjudicated')
    const outcome = await adoptManualClaim(db, context, claim, storyAt, actorRef, storyClock, eventEnd, factPassage, periodEnd)
    if (outcome.ok === false) return outcome
    if (outcome.result.claimId !== claimId) return fail('claim-identity-changed')
    return { ...outcome, operation: 'confirm-world-claim', beforeIds: [claimId, ...outcome.beforeIds] }
  })
}

function validFactPassage(scope, passage) {
  return ['book', 'session'].includes(scope?.domain) && scope.bookId === passage?.manuscriptAnchor?.bookId &&
    validQuotedAnchor(passage.manuscriptAnchor, passage.quote)
}

async function adoptManualClaim(db, context, claim, storyAt, actorRef, storyClock, eventEnd, factPassage, periodEnd) {
  const scope = context.scope
  const timeline = await loadCalendarAt(db, context.scopeKey, storyClock.timelineId)
  if (!timeline?.eras.some(era => era.id === storyClock.eraId)) return fail('timeline-era-invalid')
  const start = storyAt === null ? null : { eraId: storyClock.eraId, ordinal: storyAt }
  if (eventEnd !== null && (claim.kind !== 'event' || !start || !Number.isSafeInteger(eventEnd.ordinal) || !timeline.eras.some(era => era.id === eventEnd.eraId))) return fail('story-interval-invalid')
  if (!eventEnd && claim.kind === 'event' && storyAt === Number.MAX_SAFE_INTEGER) return fail('story-time-invalid')
  const end = eventEnd ?? (start && claim.kind === 'event' ? { ...start, ordinal: storyAt + 1 } : null)
  const storyInterval = start ? { timelineId: timeline.id, start, end, endSemantic: end ? 'exclusive' : 'open', ...(eventEnd ? { eventSpan: true } : {}) } : null
  if (periodEnd !== null) {
    if (!start || !['state', 'relation'].includes(claim.kind) || periodEnd.kind !== 'unknown') return fail('story-interval-invalid')
    storyInterval.endSemantic = 'unknown'
    if (periodEnd.by != null) storyInterval.endBy = periodEnd.by
  }
  const source = factPassage && await recordPassageEvidence(context.tables.evidence, { scope, scopeKey: context.scopeKey, manuscriptAnchor: factPassage.manuscriptAnchor, quote: factPassage.quote, ledgerId })
  const proposal = await createProposal(db, {
    ...claim, scope, origin: 'author', storyInterval, ...(source ? { evidenceIds: [source.id] } : {}),
    timeline
  })
  if (!proposal.ok) return proposal
  if (proposal.suppressed) return fail(LEDGER_FAILURE_REASONS.rejectionActive, { rejectionMarkId: proposal.rejectionMarkId })
  return adoptInTransaction(context, {
    proposalId: proposal.proposal.id, object: null, storyInterval, evidenceIds: [],
    manualAssertion: true, expectedHead: null, actorRef
  })
}

// A derived end at the previous start follows a corrected succession date.
// An author's explicit end is independent. Keep conflicts visible to the caller.
function planStateCorrection(history, head, interval, timeline) {
  const prior = head.validInterval
  const active = history.filter(row => row.id !== head.id && row.invalidatedSeq == null && row.validInterval)
  if (!active.length || sameInterval(prior, interval)) return { adjacent: [] }
  const adjacent = []
  for (const row of active) {
    const other = row.validInterval
    const conflict = () => fail('story-interval-conflict', { factVersionId: row.id })
    if (!interval?.start || interval.timelineId !== other.timelineId) return conflict()
    if (compareBoundary(other.start, interval.start, timeline) !== -1) return conflict()
    if (prior?.timelineId === other.timelineId && other.endDerived && other.endSemantic === 'exclusive' &&
        compareBoundary(other.end, prior.start, timeline) === 0) {
      if (compareBoundary(other.end, interval.start, timeline) !== 0) adjacent.push(row)
    } else if (other.endSemantic === 'unknown') {
      // A later start cannot establish the exact date an earlier state ended.
      continue
    } else if (other.endSemantic !== 'exclusive' || ![-1, 0].includes(compareBoundary(other.end, interval.start, timeline))) {
      return conflict()
    }
  }
  return { adjacent }
}

async function correctFact(db, input) {
  const payload = {
    scope: input?.scope, factKey: input?.factKey, object: input?.object,
    storyInterval: input?.storyInterval ?? null, evidenceIds: input?.evidenceIds ?? [],
    expectedHead: input?.expectedHead ?? null, actorRef: input?.actorRef ?? '', reason: input?.reason ?? ''
  }
  if (input?.literalValue !== undefined) payload.literalValue = input.literalValue
  if (input?.objectRef !== undefined) payload.objectRef = input.objectRef
  if (input?.eventContext !== undefined) payload.eventContext = input.eventContext
  if (input?.eventLabels !== undefined) payload.eventLabels = input.eventLabels
  return runCommand(db, payload.scope, input?.commandId, payload, context => correctInTransaction(db, payload, context))
}

async function correctInTransaction(db, payload, { tables, seq, scopeKey }) {
  const history = await tables.versions.where('[scopeKey+factKey]').equals([scopeKey, payload.factKey]).toArray()
  const head = successionHead(history)
  if (!head) return fail(LEDGER_FAILURE_REASONS.factNotFound, { factKey: payload.factKey })
  if (payload.expectedHead !== null && payload.expectedHead !== head.id) {
    return fail(LEDGER_FAILURE_REASONS.headConflict, { expectedHead: payload.expectedHead, actualHead: head.id })
  }
  // Subject and predicate are the fact identity and never change in a
  // correction; only the object, interval and evidence move forward.
  const previousClaim = head.kind ? head : legacyWorldClaimForVersion(head)
  const claim = normalizeWorldClaim({
    ...previousClaim, ...(Object.hasOwn(payload, 'eventContext') ? { eventContext: payload.eventContext } : {}),
    eventLabels: payload.eventLabels ?? previousClaim.eventLabels,
    literalValue: Object.hasOwn(payload, 'literalValue') ? payload.literalValue : previousClaim.literalValue,
    object: payload.object, objectRef: Object.hasOwn(payload, 'objectRef') ? payload.objectRef
      : (payload.object === head.object ? previousClaim.objectRef : null)
  }, previousClaim.occurrenceId)
  if (!claim.ok) return fail(claim.reason)
  const interval = payload.storyInterval !== null ? normalizeStoryIntervalInput(payload.storyInterval, claim.claim.kind) : { ok: true, interval: head.validInterval ?? null }
  if (!interval.ok) return fail(interval.reason)
  let adjacent = []
  if (payload.storyInterval !== null && !sameInterval(interval.interval, head.validInterval)) {
    const clock = interval.interval && await loadCalendarAt(db, scopeKey, interval.interval.timelineId)
    const timeline = normalizeTimelineConfig(clock)
    if (!timeline && interval.interval && interval.interval.timelineId !== head.validInterval?.timelineId) return fail('timeline-era-invalid')
    const invalidClock = validateIntervalClock(interval.interval, timeline)
    if (invalidClock) return fail(invalidClock)
    if (previousClaim.kind === 'state' || (previousClaim.kind === 'relation' && operandKey(previousClaim) === operandKey(claim.claim))) {
      const plan = planStateCorrection(history, head, interval.interval, timeline)
      if (plan.ok === false) return plan
      adjacent = plan.adjacent
    }
  }
  for (const evidenceId of payload.evidenceIds) {
    const evidence = await tables.evidence.get(evidenceId)
    if (!evidence || evidence.scopeKey !== scopeKey) return fail(LEDGER_FAILURE_REASONS.evidenceMissing, { evidenceId })
  }
  const evidenceIds = [...new Set([...(head.evidenceIds || []), ...payload.evidenceIds])]
  // A correction must change something; identical content is refused
  // instead of manufacturing a meaningless revision.
  if (claim.claim.object === head.object && operandKey(claim.claim) === operandKey(head)
    && (claim.claim.objectRef || null) === (head.objectRef || null)
    && sameEventContext(head, claim.claim)
    && sameInterval(interval.interval, head.validInterval)
    && evidenceIds.length === (head.evidenceIds || []).length) {
    return fail(LEDGER_FAILURE_REASONS.noChange)
  }
  const factKey = (previousClaim.kind === 'relation' || previousClaim.polarity === 'negative') && deriveFactKey(previousClaim) !== deriveFactKey(claim.claim)
    ? deriveFactKey(claim.claim) : head.factKey
  if (factKey !== head.factKey) {
    const other = successionHead(await tables.versions.where('[scopeKey+factKey]').equals([scopeKey, factKey]).toArray())
    if (other) return fail(LEDGER_FAILURE_REASONS.headConflict, { actualHead: other.id })
  }
  const claimId = await ensureWorldClaim(tables.claims, { scopeKey, scope: head.scope, seq }, claim.claim)
  const now = Date.now()
  await tables.versions.update(head.id, invalidation(now, seq))
  const version = {
    id: ledgerId('fv'),
    schemaVersion: 2,
    factKey,
    scopeKey,
    scope: payload.scope,
    ...claim.claim,
    claimId,
    evidenceIds,
    validInterval: interval.interval,
    recordedAt: now,
    recordedSeq: seq,
    supersedes: factKey === head.factKey ? head.id : null,
    authority: 'author-confirmed',
    origin: head.origin,
    legacyRefs: null
  }
  const afterIds = [version.id]
  let commitSeq = seq
  for (const prior of adjacent) {
    const id = ledgerId('fv')
    commitSeq = await allocateSeq(tables.meta, scopeKey)
    await tables.versions.add({ ...prior, id, recordedSeq: commitSeq, recordedAt: now,
      supersedes: prior.id, supersedesKind: 'historical-state', validInterval: { ...prior.validInterval, end: interval.interval.start } })
    afterIds.push(id)
  }
  if (adjacent.length) {
    for (const prior of [head, ...adjacent]) await tables.versions.update(prior.id, invalidation(now, commitSeq))
    for (const id of afterIds.slice(1)) await tables.versions.update(id, { visibleFromSeq: commitSeq })
    version.visibleFromSeq = commitSeq
  }
  await tables.versions.add(version)
  return {
    commitSeq,
    operation: 'correct-fact',
    actorRef: payload.actorRef,
    reason: payload.reason,
    beforeIds: [head.id, ...adjacent.map(row => row.id)],
    afterIds,
    result: { claimId, factVersionId: version.id, factKey, supersededId: head.id }
  }
}

// End an actual state or relationship at a story boundary. Reading the
// displayed version by ID also preserves the original payload on retries.
async function reviseWorldBoundary(db, input, edge) {
  const scope = resolveScope(input?.scope)
  if (!scope.ok) return fail(scope.reason)
  if (!input.expectedHead) return fail('fact-version-changed')
  if (edge !== 'uncertainty' && !Number.isSafeInteger(input.storyAt)) return fail('story-time-invalid')
  const clock = normalizeStoryClock(input.storyClock)
  if (!clock) return fail('story-clock-invalid')
  const version = await db.table('factVersions').get(input.expectedHead)
  if (!version || version.scopeKey !== scope.scopeKey || version.factKey !== input.factKey) return fail('fact-version-changed')
  const kind = version.kind ?? legacyWorldClaimForVersion(version).kind
  const old = version.validInterval
  const point = { eraId: clock.eraId, ordinal: input.storyAt }
  let storyInterval
  if (edge === 'uncertainty') {
    const end = input.periodEnd
    if (kind === 'event' || !old?.start || !end || !['unknown', 'open'].includes(end.kind) || (end.by != null && end.kind !== 'unknown')) return fail('story-interval-invalid')
    storyInterval = { timelineId: old.timelineId, start: old.start, end: null, endSemantic: end.kind, ...(end.by != null ? { endBy: end.by } : {}) }
  } else if (edge === 'end') {
    if (kind === 'event' && !Number.isSafeInteger(old?.start?.ordinal)) return fail('event-start-required')
    if (old && old.timelineId !== clock.timelineId) return fail('timeline-mismatch')
    storyInterval = { timelineId: clock.timelineId, start: old?.start ?? null, end: point, endSemantic: 'exclusive', ...(kind === 'event' ? { eventSpan: true } : {}) }
  } else if (kind === 'event' && (!old || (!old.eventSpan && old.endSemantic === 'exclusive' && old.start?.eraId === old.end?.eraId &&
      Number.isSafeInteger(old.start?.ordinal) && old.end.ordinal === old.start.ordinal + 1))) {
    if (input.storyAt === Number.MAX_SAFE_INTEGER) return fail('story-time-invalid')
    storyInterval = { timelineId: clock.timelineId, start: point, end: { ...point, ordinal: point.ordinal + 1 }, endSemantic: 'exclusive' }
  } else {
    if ((old?.end || old?.endBy) && old.timelineId !== clock.timelineId) return fail('timeline-mismatch')
    storyInterval = { timelineId: clock.timelineId, start: point, end: old?.end ?? null, endSemantic: old?.endSemantic ?? 'open', ...(old?.eventSpan ? { eventSpan: true } : {}), ...(old?.endBy ? { endBy: old.endBy } : {}) }
  }
  return correctFact(db, { scope: scope.scope, commandId: input.commandId, actorRef: input.actorRef,
    factKey: version.factKey, expectedHead: version.id, object: version.object, storyInterval })
}

async function withdrawKnowledgeEvent(db, { scope, commandId, actorKey, claimId, eventId } = {}) {
  if (!actorKey || !claimId || !eventId) return fail('knowledge-event-changed')
  return runCommand(db, scope, commandId, { action: 'withdraw-knowledge-event', actorKey, claimId, eventId }, async ({ seq, scopeKey }) => {
    const rows = db.table('knowledgeEvents')
    const original = await rows.get(eventId)
    if (!original || original.scopeKey !== scopeKey || original.actorKey !== actorKey || original.claimId !== claimId ||
        original.invalidatedSeq != null || await rows.where('supersedesEventId').equals(eventId).first()) return fail('knowledge-event-changed')
    const calendar = await loadCalendarAt(db, scopeKey, eventClock(original).timelineId)
    if (!calendar) return fail('timeline-era-invalid')
    const group = await rows.where('[scopeKey+actorKey]').equals([scopeKey, actorKey]).filter(row => row.claimId === claimId).toArray()
    const before = orphanAttitudes(group, calendar)
    const after = orphanAttitudes(group.map(row => row.id === eventId ? { ...row, invalidatedSeq: seq } : row), calendar)
    if ([...after].some(id => !before.has(id))) return fail('knowledge-dependent-attitude')
    await rows.update(eventId, { invalidatedSeq: seq })
    return { operation: 'withdraw-knowledge-event', beforeIds: [eventId], result: { withdrawnKnowledgeEventId: eventId, actorKey, claimId } }
  })
}

async function retractFact(db, input) {
  const payload = { scope: input?.scope, factKey: input?.factKey, expectedHead: input?.expectedHead ?? null, actorRef: input?.actorRef ?? '', reason: input?.reason ?? '' }
  return runCommand(db, payload.scope, input?.commandId, payload, async ({ tables, seq, scopeKey }) => {
    const head = successionHead(await tables.versions.where('[scopeKey+factKey]').equals([scopeKey, payload.factKey]).toArray())
    if (!head) return fail(LEDGER_FAILURE_REASONS.factNotFound, { factKey: payload.factKey })
    if (payload.expectedHead !== null && payload.expectedHead !== head.id) {
      return fail(LEDGER_FAILURE_REASONS.headConflict, { expectedHead: payload.expectedHead, actualHead: head.id })
    }
    await tables.versions.update(head.id, invalidation(Date.now(), seq))
    return {
      operation: 'retract-fact',
      actorRef: payload.actorRef,
      reason: payload.reason,
      beforeIds: [head.id],
      afterIds: [],
      result: { factKey: payload.factKey, retractedId: head.id }
    }
  })
}

// Rejection is scoped by claim fingerprint AND the source revision under
// review: the same claim re-appearing from a changed source is reviewable
// again, while an identical re-proposal stays suppressed until explicitly
// reopened (A09).
async function rejectProposal(db, input) {
  const payload = { scope: input?.scope, proposalId: input?.proposalId, actorRef: input?.actorRef ?? '', reason: input?.reason ?? '' }
  return runCommand(db, payload.scope, input?.commandId, payload, async ({ tables, scopeKey, decisionId }) => {
    const proposal = await tables.proposals.get(input?.proposalId)
    if (!proposal || proposal.scopeKey !== scopeKey) return fail(LEDGER_FAILURE_REASONS.proposalNotFound)
    if (proposal.status !== 'pending') return fail(LEDGER_FAILURE_REASONS.proposalNotPending, { status: proposal.status })
    await tables.proposals.update(proposal.id, { status: 'dismissed' })
    const mark = {
      id: ledgerId('rej'),
      scopeKey,
      fingerprint: proposal.fingerprint,
      sourceRevision: proposal.sourceRevision || '',
      rejectedAt: Date.now(),
      decisionId,
      reopenedAt: null
    }
    await tables.rejections.add(mark)
    return {
      operation: 'reject-proposal',
      actorRef: payload.actorRef,
      reason: payload.reason,
      beforeIds: [proposal.id],
      afterIds: [mark.id],
      result: { proposalId: proposal.id, rejectionMarkId: mark.id }
    }
  })
}

async function reopenRejection(db, input) {
  const payload = { scope: input?.scope, rejectionMarkId: input?.rejectionMarkId, actorRef: input?.actorRef ?? '', reason: input?.reason ?? '' }
  return runCommand(db, payload.scope, input?.commandId, payload, async ({ tables, scopeKey }) => {
    const mark = await tables.rejections.get(input?.rejectionMarkId)
    if (!mark || mark.scopeKey !== scopeKey) return fail(LEDGER_FAILURE_REASONS.rejectionNotFound)
    await tables.rejections.update(mark.id, { reopenedAt: Date.now() })
    return {
      operation: 'reopen-rejection',
      actorRef: payload.actorRef,
      reason: payload.reason,
      beforeIds: [mark.id],
      afterIds: [mark.id],
      result: { rejectionMarkId: mark.id }
    }
  })
}

// A19 seam: durable, idempotent storage for committed turn receipts. The
// ledger never drives game state — this is the persistent audit side of the
// seam O wires to the turn coordinator. payloadHash is recomputed here so the
// same receiptId arriving with different content is detectable.
async function appendCommittedTurnReceipt(db, { scope, receipt } = {}) {
  const resolved = resolveScope(scope)
  if (!resolved.ok) return fail(resolved.reason)
  const r = receipt || {}
  if (typeof r.receiptId !== 'string' || !r.receiptId.trim()
    || typeof r.turnId !== 'string' || !r.turnId
    || typeof r.commandId !== 'string' || !r.commandId
    || !Number.isFinite(Number(r.committedAt))) return fail('receipt-invalid')
  const payload = {
    receiptId: r.receiptId.trim(),
    commandId: r.commandId,
    turnId: r.turnId,
    parentTurnId: r.parentTurnId ?? null,
    branchId: r.branchId ?? null,
    rulesVersion: r.rulesVersion ?? null,
    resolutionRef: r.resolutionRef ?? null,
    stateDeltaRefs: Array.isArray(r.stateDeltaRefs) ? r.stateDeltaRefs : [],
    evidenceRefs: Array.isArray(r.evidenceRefs) ? r.evidenceRefs : [],
    committedAt: Number(r.committedAt),
    scopeKey: resolved.scopeKey
  }
  const hash = payloadHash(payload)
  try {
    return await db.transaction('rw', [...TX_TABLES, 'turnReceipts'], async () => {
      const table = db.table('turnReceipts')
      const existing = await table.get(payload.receiptId)
      if (existing) {
        if (existing.payloadHash !== hash) return fail('receipt-conflict', { receiptId: payload.receiptId })
        return { ok: true, replay: true, receipt: existing }
      }
      const seq = await allocateSeq(db.table('ledgerMeta'), resolved.scopeKey)
      const row = { ...payload, scope: resolved.scope, payloadHash: hash, archivedAt: Date.now(), archivedSeq: seq }
      await table.add(row)
      return { ok: true, replay: false, receipt: row }
    })
  } catch (error) {
    return fail(LEDGER_FAILURE_REASONS.dbUnavailable, { detail: error?.message || String(error) })
  }
}

// ---- read helpers (review UI / projection feed on these) ----

async function listProposals(db, { scope, status = 'pending' } = {}) {
  const resolved = resolveScope(scope)
  if (!resolved.ok) return []
  return db.table('factProposals').where('[scopeKey+status]').equals([resolved.scopeKey, status]).toArray()
}

async function listFactVersions(db, { scope, factKey } = {}) {
  const resolved = resolveScope(scope)
  if (!resolved.ok) return []
  if (factKey) return db.table('factVersions').where('[scopeKey+factKey]').equals([resolved.scopeKey, factKey]).toArray()
  return db.table('factVersions').where('scopeKey').equals(resolved.scopeKey).toArray()
}

async function listDecisions(db, { scope, limit = 100 } = {}) {
  const resolved = resolveScope(scope)
  if (!resolved.ok) return []
  const all = await db.table('factDecisions').where('scopeKey').equals(resolved.scopeKey).toArray()
  return all.sort((a, b) => b.recordedSeq - a.recordedSeq).slice(0, Math.max(1, limit))
}

// AX15: index-ranged paged decisions with a bounded chunk walk and reported
// scan cost — the review UI must not require a whole-log materialization.
async function listDecisionsPaged(db, { scope, cursor = null, limit = 50 } = {}) {
  const startedAt = Date.now()
  const resolved = resolveScope(scope)
  if (!resolved.ok) return { ok: false, reason: 'scope-invalid', items: [], nextCursor: null, scanned: 0, elapsedMs: 0 }
  const page = Math.min(200, Math.max(1, Math.floor(Number(limit) || 50)))
  const scopeKey = resolved.scopeKey
  try {
    let upperSeq = null
    if (cursor) {
      let parsed
      try { parsed = JSON.parse(atob(String(cursor))) } catch { return { ok: false, reason: 'cursor-invalid', items: [], nextCursor: null, scanned: 0, elapsedMs: 0 } }
      if (parsed?.v !== 1 || !Number.isFinite(parsed.lastSeq)) return { ok: false, reason: 'cursor-invalid', items: [], nextCursor: null, scanned: 0, elapsedMs: 0 }
      upperSeq = parsed.lastSeq
    }
    // recordedSeq can never exceed the scope counter; start the walk there.
    const seqRecord = await db.table('ledgerMeta').get(`seq:${scopeKey}`)
    const liveSeq = Number.isFinite(seqRecord?.seq) ? seqRecord.seq : 0
    if (upperSeq === null) upperSeq = liveSeq
    const CHUNK = 500
    const table = db.table('factDecisions')
    const items = []
    let scanned = 0
    let high = upperSeq
    let exhausted = false
    while (items.length <= page && !exhausted && scanned < 5000) {
      const low = Math.max(0, high - CHUNK + 1)
      const chunk = await table
        .where('[scopeKey+recordedSeq]')
        .between([scopeKey, low], [scopeKey, high], true, true)
        .reverse()
        .toArray()
      scanned += chunk.length
      for (const row of chunk) {
        if (items.length > page) break
        items.push(row)
      }
      if (low === 0) exhausted = true
      else high = low - 1
    }
    const hasMore = items.length > page
    const pageItems = items.slice(0, page)
    const nextCursor = hasMore && pageItems.length
      ? btoa(JSON.stringify({ v: 1, lastSeq: pageItems[pageItems.length - 1].recordedSeq }))
      : null
    return { ok: true, items, nextCursor, scanned, elapsedMs: Date.now() - startedAt }
  } catch (error) {
    return { ok: false, reason: 'db-unavailable', retryable: true, detail: error?.message || String(error), items: [], nextCursor: null, scanned: 0, elapsedMs: 0 }
  }
}

async function getFactHead(db, { scope, factKey }) {
  const resolved = resolveScope(scope)
  if (!resolved.ok) return null
  const versions = await db.table('factVersions').where('[scopeKey+factKey]').equals([resolved.scopeKey, factKey]).toArray()
  return successionHead(versions)
}

async function listRejectionMarks(db, { scope } = {}) {
  const resolved = resolveScope(scope)
  if (!resolved.ok) return []
  return db.table('rejectionMarks').where('scopeKey').equals(resolved.scopeKey).toArray()
}

async function listTurnReceipts(db, { scope, limit = 200 } = {}) {
  const resolved = resolveScope(scope)
  if (!resolved.ok) return []
  const all = await db.table('turnReceipts').where('scopeKey').equals(resolved.scopeKey).toArray()
  return all.sort((a, b) => b.archivedSeq - a.archivedSeq).slice(0, Math.max(1, limit))
}

return Object.freeze({ inheritWorldForkActor: (db, input) => inheritForkActor(db, input, { runCommand, ledgerId }), adoptWorldForkFact: (db, input) => adoptForkVersion(db, input, {
  runCommand, ledgerId, correctInTransaction, createProposal, adoptInTransaction
}), withdrawKnowledgeEvent, forkWorldFacts: (db, input) => forkWorldFacts(db, input, { runCommand, ledgerId }), listWorldFactForks, runWorldCommand: runCommand, defineWorldCalendar: (db, input) => defineCalendar(db, input, runCommand), listWorldCalendars, listWorldStatements, saveWorldStatement, recordOppositeClaim, confirmWorldClaim, moveWorldStart: (db, input) => reviseWorldBoundary(db, input, 'start'), setWorldPeriodEnd: (db, input) => reviseWorldBoundary(db, input, 'uncertainty'), endWorldPeriod: (db, input) => reviseWorldBoundary(db, input, 'end'), appendEvidence, createProposal, revertTemporalClosure, adoptProposal, correctFact, retractFact, rejectProposal, reopenRejection, appendCommittedTurnReceipt, listProposals, listFactVersions, listDecisions, listDecisionsPaged, getFactHead, listRejectionMarks, listTurnReceipts })
}
