import { validateTimeline } from '../knowledgeTime.js'
import { normalizeScopeRef, encodeScopeKey } from './ledgerContract.js'
import { isVisibleAt } from './recordAxis.js'

export { defaultCalendar, defaultStoryClock, normalizeStoryClock } from './storyClock.js'
import { defaultCalendar } from './storyClock.js'
import { effectiveEvents, orphanAttitudes } from './knowledgeReplay.js'
const fail = reason => ({ ok: false, reason })
const text = value => typeof value === 'string' ? value.trim() : ''

export function normalizeCalendar(input) {
  if (!input || !Array.isArray(input.eras)) return fail('timeline-invalid')
  const calendar = { id: text(input.id), label: text(input.label) || text(input.id), eras: input.eras.map(era => ({
    id: text(era?.id), label: text(era?.label) || text(era?.id), order: era?.order
  })) }
  const valid = validateTimeline(calendar)
  return valid.ok ? { ok: true, calendar } : fail(valid.error)
}

export async function loadCalendarAt(db, scopeKey, timelineId, recordedSeq = null) {
  if (timelineId === 'default') return { ...defaultCalendar, revisionId: null }
  const row = await db.table('factDecisions').where('[scopeKey+result.calendar.id+recordedSeq]')
    .between([scopeKey, timelineId, 0], [scopeKey, timelineId, recordedSeq ?? Number.MAX_SAFE_INTEGER], true, true).last()
  return row && isVisibleAt(row, recordedSeq) ? { ...row.result.calendar, revisionId: row.id } : null
}

export async function listWorldCalendars(db, { scope, recordedSeq = null }) {
  const resolved = normalizeScopeRef(scope)
  if (!resolved.ok) return resolved
  if (recordedSeq !== null && (!Number.isSafeInteger(recordedSeq) || recordedSeq < 0)) return fail('recorded-as-of-invalid')
  const scopeKey = encodeScopeKey(resolved.scope)
  const history = await db.table('factDecisions').where('[scopeKey+operation+recordedSeq]')
    .between([scopeKey, 'define-story-calendar', 0], [scopeKey, 'define-story-calendar', recordedSeq ?? Number.MAX_SAFE_INTEGER], true, true).toArray()
  const calendars = new Map([['default', { ...defaultCalendar, revisionId: null }]])
  for (const row of history.filter(row => isVisibleAt(row, recordedSeq))) calendars.set(row.result.calendar.id, { ...row.result.calendar, revisionId: row.id })
  return { ok: true, items: [...calendars.values()] }
}

export function defineWorldCalendar(db, input, runCommand) {
  const normalized = normalizeCalendar(input?.calendar)
  if (!normalized.ok) return normalized
  const { calendar } = normalized
  if (calendar.id === 'default') return fail('calendar-default-reserved')
  const expectedRevisionId = input.expectedRevisionId ?? null
  const payload = { operation: 'define-story-calendar', calendar, expectedRevisionId }
  return runCommand(db, input.scope, input.commandId, payload, async ({ tables, scopeKey }) => {
    const prior = await loadCalendarAt(db, scopeKey, calendar.id)
    if ((prior?.revisionId ?? null) !== expectedRevisionId) return fail('calendar-revision-changed')
    if (prior && prior.label === calendar.label && JSON.stringify(prior.eras) === JSON.stringify(calendar.eras)) return fail('no-change')
    const eras = new Map(calendar.eras.map(era => [era.id, era.order]))
    const conflict = await tables.versions.where('scopeKey').equals(scopeKey).filter(row => {
      const interval = row.validInterval
      if (!isVisibleAt(row) || interval?.timelineId !== calendar.id) return false
      return [interval.start, interval.end, interval.endBy].some(point => point && !eras.has(point.eraId)) ||
        [interval.end, interval.endBy].some(end => interval.start && end && eras.get(interval.start.eraId) > eras.get(end.eraId))
    }).first()
    if (conflict) return { ...fail('calendar-fact-conflict'), factVersionId: conflict.id }
    const events = await db.table('knowledgeEvents').where('scopeKey').equals(scopeKey).toArray()
    const knowledge = effectiveEvents(events).filter(row => row.storyClock?.timelineId === calendar.id)
    if (knowledge.some(row => !eras.has(row.storyClock.eraId))) return fail('calendar-knowledge-conflict')
    const uses = await db.table('claimUses').where('scopeKey').equals(scopeKey)
      .filter(row => isVisibleAt(row) && row.beliefUse?.storyClock?.timelineId === calendar.id && !eras.has(row.beliefUse.storyClock.eraId)).first()
    if (uses) return fail('calendar-knowledge-conflict')
    // A new era order must still place dated changes of mind after acquisition.
    if (knowledge.length && prior) {
      const groups = new Map()
      for (const row of knowledge) {
        const key = JSON.stringify([row.actorKey, row.claimId])
        if (!groups.has(key)) groups.set(key, [])
        groups.get(key).push(row)
      }
      for (const rows of groups.values()) {
        const old = orphanAttitudes(rows, prior)
        if ([...orphanAttitudes(rows, calendar)].some(id => !old.has(id))) return fail('calendar-knowledge-conflict')
      }
    }
    return { operation: payload.operation, beforeIds: prior ? [prior.revisionId] : [], result: { calendar } }
  })
}
