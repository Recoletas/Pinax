## 0.11.0

- 将Next小说/构思/大纲/世界书/剧本/资料工具和漫画等记录型载体的实际文件规则迁入Core；工具名、文件格式、权限与修订口径保留，文件和知识服务由Host注入。
- 迁入Next会话状态、分支/追加式JSONL恢复规则；明确失败回执不再被当作持久化成功，回答留在内存。
- 迁入移动双槽快照状态机；文件和排除键策略由Capacitor Host注入，只有写入确认后才返回native durable回执。
- 共享写作版本/崩溃恢复仓储、生成草稿恢复、任务面板owner、冻结运行会话/授权索引/实时依赖校验。地理索引仍通过Host函数注入，不移动地图引擎。
- 本版本仍保留不同Host的会话协议，不能据此宣称全部业务领域已统一。

## 0.10.0

- 将实际使用的上下文编译、来源读取/修订、世界书激活与关系/结算、记忆排序迁入独立包；Host以显式仓储端口提供数据。
- 迁入正文内核/写作编排/文档结构和助手任务/会话/讨论上下文；marked固定18.0.3。
- 迁入现有Pi会话装配及Next工具循环/写策略/审计，模型/SDK/文件存储仍由Host注入；未宣称两种运行方式已经合并。
- Web/Pinix实际书籍、大纲和速记仓储、条目更新规则共享；Web/Next世界书文件往返合同共享，保留富关系和未知字段。
- 章节三端真实调用已接，Next删除加入文件队列内expectedRevision校验。
- 本版本是已验证的抽取批次，不代表全部领域和Host迁移完成。仍需接齐其他载体、原生持久化与跨端任务生命周期。

## 0.9.0

抽取助手修改计算、审阅状态和权限/工具合同；增加可恢复多键写入协调、项目/操作/修订事务命令及异步flush确认。合入大纲边端点存在性校验。保留领域API兼容，宿主通过端口提供编辑器、存储与身份能力。

# Changelog

本项目遵循语义化版本。0.x 阶段接口可能变动，消费方应固定精确版本。

## 0.8.0

- 新增**资料(material / narrative asset)**域:扁平素材列表(按 projectId 归属)。`MaterialStore` 端口 + `createMaterialService`/`createSyncMaterialService` + `createMemoryMaterialStore` + `normalizeMaterial`/`createMaterial`/`updateMaterial`/`sortMaterialsNewestFirst`/`deriveMaterialTitle`/`normalizeMaterialKind`/`normalizeMaterialStatus`/`filterMaterials`/`buildMaterialUpdatePatch`。
  - 集中业务规则:**kind 白名单**(非法→`inspiration`)、**status 生命周期**(`inbox/accepted/rejected/archived`,非法→`inbox`;`active`= `inbox/accepted`)、**标题回退**(正文首行前 **24** 字)、非空正文、最新在前、按 `contentHash`(缺省回退正文)去重。中文 label/说明属 Host,不进 Core。
  - `list`(支持 status/kind/projectId/activeOnly 过滤)/`read`/`create`(可 `dedupe`)/`update`/`setStatus`/`remove`;`setStatus` 拒绝非法状态;重复 id → `DUPLICATE_MATERIAL`,缺资料 → `MATERIAL_NOT_FOUND`;无乐观并发。
  - 图片、`sourceRefs`/证据引用、批量合并/删除等富字段原样保留,**未建模**(后续切片)。
  - 新增错误码 `MATERIAL_NOT_FOUND` / `DUPLICATE_MATERIAL`。
- 覆盖度:写作(书+章节)+ 世界书条目 + 大纲 + 笔记 + 资料已入 Core;漫画/体验/记忆/Agent 仍未抽取;资料尚未接进 Host。

## 0.7.0

- 新增**笔记(note)**域:扁平素材列表(不分书)。`NoteStore` 端口 + `createNoteService`/`createSyncNoteService` + `createMemoryNoteStore` + `normalizeNote`/`createNote`/`updateNote` + 规则函数 `countNoteWords`/`deriveNoteTitle`/`buildNoteUpdatePatch`。
  - 集中两条真实业务规则:**字数口径**(CJK 单字 + 英文单词)与**标题回退**(取正文首个非空行前 18 字;空正文的显示占位仍归 Host,Core 不写死“素材”)。
  - 语义:`list`/`read`/`create`/`update`/`remove`;正文非空才可建/改;改正文重算字数(除非显式给);可改标题;新笔记插到最前(与宿主 prepend 一致);`source` 归一;重复 id → `DUPLICATE_NOTE`,缺笔记 → `NOTE_NOT_FOUND`;无乐观并发;富字段原样保留。
  - 新增错误码 `NOTE_NOT_FOUND` / `DUPLICATE_NOTE`。
- 覆盖度:写作(书+章节)+ 世界书条目 + 大纲(节点/边/重排)+ 笔记已入 Core;资料/漫画/体验/记忆/Agent 仍未抽取;笔记尚未接进 Host。

## 0.6.0

- 大纲补上**换父级/重排(环检测)**:`planOutlineMove`/`isDescendantOrSelf`(纯函数,树规则只在 Core 一处)+ `OutlineNodeStore` 新增 `move` 方法 + 内存适配器 `move` + 异步/同步 service `move`。
  - 语义:reparent 校验 目标父存在、**不能移到自身/自身后代(OUTLINE_CYCLE)**、乐观并发(`expectedRevision`,冲突 `STALE_REVISION`);支持置根(`parentId:''`→`null`)与设 `order`;写回经 `store.move` 再核一次修订号。
  - 新增错误码 `OUTLINE_CYCLE`。
- 大纲竖切片完整:节点 + 边 + 换父级/重排。仍缺端点存在性跨表校验(边指向不存在节点)留给一致性用例;其余域未抽取;大纲仍未接进 Host。

## 0.5.0

- 新增**大纲边(outline edge)**域,补齐大纲图: `OutlineEdgeStore` 端口 + `createOutlineEdgeService`（异步）/`createSyncOutlineEdgeService`（同步）+ `createMemoryOutlineEdgeStore` + `normalizeOutlineEdge`/`createOutlineEdge`/`outlineEdgeKey`/`outlineEdgeSummary`。
  - 语义：`list`/`add`/`remove`；边 {id, kind, fromNodeId, toNodeId}，兼容 legacy `from`/`to`；自环/缺端点/缺 id 判无效（`INVALID_INPUT`）；去重按同 id 或同 `(kind,from,to)` → `DUPLICATE_OUTLINE_EDGE`；缺边 → `OUTLINE_EDGE_NOT_FOUND`；`sourceRefs` 等原样保留。
  - 端点是否指向存在节点不在本端口跨表校验（留给上层重排/一致性用例）。
  - 新增错误码 `OUTLINE_EDGE_NOT_FOUND` / `DUPLICATE_OUTLINE_EDGE`。
- 大纲竖切片现为**节点 + 边**两级（仍缺换父级/重排的环检测）；其余域仍未抽取；节点与边均未接进 Host。

## 0.4.0

- 新增**大纲节点(outline node)**域：`OutlineNodeStore` 端口 + `createOutlineNodeService`（异步）/`createSyncOutlineNodeService`（同步）+ `createMemoryOutlineNodeStore` + `normalizeOutlineNode`/`createOutlineNode`/`outlineNodeSummary`/`outlineNodeRevision` + `applyOutlineNodePatch`/`OUTLINE_NODE_MUTABLE_FIELDS`。
  - 语义：`list`/`read`/`create`/`update`/`remove`,节点带**乐观并发**（`expectedRevision`,冲突 `STALE_REVISION`）;`update` 仅允许 `title`/`intent`/`status`/`order` 白名单字段,`create` 后 revision 1;重复 id → `DUPLICATE_OUTLINE_NODE`,缺节点 → `OUTLINE_NODE_NOT_FOUND`;`chapterRefs`/`explorationRefs`/`entityRefs` 等富字段原样保留。
  - 明确**不在本切片**:换父级(重排树结构,需环检测)与**边图(edge graph)**——`applyOutlineNodePatch` 拒绝带 `parentId` 的补丁,留给后续重排用例。
  - 新增错误码 `OUTLINE_NODE_NOT_FOUND` / `DUPLICATE_OUTLINE_NODE`。
- 覆盖度：写作(书+章节)+ 世界书条目 + 大纲节点已入 Core;大纲换父级/边图、笔记、资料、漫画、体验、记忆、Agent/上下文/工具与跨端迁移仍未抽取;大纲节点尚未接进任何 Host。

## 0.3.0

- 新增**世界书条目(worldbook entry)**域：`WorldbookEntryStore` 端口 + `createWorldbookEntryService`（异步）/`createSyncWorldbookEntryService`（同步）+ `createMemoryWorldbookEntryStore` 参照适配器 + `normalizeWorldbookEntry`/`createWorldbookEntry`/`worldbookEntrySummary`/`validateWorldbookEntryPatch`。
  - 语义：`list`/`read`/`create`/`update`/`remove`；条目不带乐观并发修订号（与宿主现状一致）；`name` 缺失回退 legacy `title`；`update` 至少改 `name`/`content` 其一并刷新 `updatedAt`；重复 id → `DUPLICATE_ENTRY`；缺条目 → `ENTRY_NOT_FOUND`；富字段（injection.group/category/tags…）作为未知字段原样保留。
  - 新增错误码 `ENTRY_NOT_FOUND` / `DUPLICATE_ENTRY`。
- 覆盖度：写作（书+章节）+ 世界书条目已入 Core；大纲、笔记、资料、漫画、体验、记忆、Agent/上下文/工具与跨端迁移仍未抽取；世界书条目尚未接进任何 Host。

## 0.2.0

- 新增**作品(book)**域：`BookStore` 端口 + `createBookService`（异步）/`createSyncBookService`（同步）+ `createMemoryBookStore` 参照适配器 + `normalizeBookRecord`/`createBookRecord`/`bookSummary`。
  - 语义：`list`/`read`/`create`/`rename`/`remove`；空书名在创建时合法（显示归 Host），`rename` 拒绝空书名；重复 id → `DUPLICATE_BOOK`；缺书 → `BOOK_NOT_FOUND`。
  - 新增错误码 `DUPLICATE_BOOK`。
- 章节仍由 `applyChapterPatch` 统一保存语义；三端消费方式不变。
- 覆盖度：写作 = 书 + 章节两级已入 Core；世界书、大纲、笔记、资料、漫画、体验、记忆、Agent/上下文/工具与跨端迁移仍未抽取。

## 0.1.0

- 首个独立包：把平台无关的业务内核从 Pinax 主仓抽出，三端（Web / Pinix / Next）以打包产物共用。
- 已覆盖领域：**章节**（读取 / 列表 / 创建 / 保存 / 删除 + 修订号乐观并发）。
  - `createChapterService`（异步，供移动 / 文件端）、`createSyncChapterService`（同步，供 localStorage 这类同步 Host），两者共用 `validateChapterSaveInput` 与 domain 规则。
  - `applyChapterPatch` / `CHAPTER_SIDECAR_KEYS`：集中保存语义（revision 递增、content-only 保存清结构化侧车、乐观并发），Host 适配器与内存参照适配器都调用它，避免实现漂移。
  - `ChapterStore` 端口 + `createMemoryChapterStore` 参照适配器。
- 边界：Core 不依赖 Vue / DOM / Electron / Capacitor / Node `fs` / `localStorage`；平台能力由 Host 通过端口注入。
- 发布状态：本包当前 `private: true`，发布配置（registry / 可见性）待作者确定私有远程后落。
- 尚未覆盖：世界书、大纲、笔记、资料、漫画、体验、记忆 / 事实账本、Agent / 上下文 / 工具，以及跨端数据迁移。这些在后续切片补，不代表当前包已「全功能」。
