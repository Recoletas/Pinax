import { sha256HexOfText } from '../../domain/contentHash.js'
import { stableStringify } from '../knowledgeContract.js'

// A-line fact ledger contract (nightly 20260916). Structural semantics follow
// Utopia `60df635d6924127c9a57e98acbd99e43bdd92d08` (Apache-2.0): facts are
// versioned claims with frozen evidence, a supersedes chain and two clocks.
// No Rust/SQL code is copied; the ledger runs on the existing Dexie database.

export const LEDGER_SCHEMA_VERSION = 2

export const LEDGER_DOMAINS = ['author', 'book', 'worldbook', 'session']

export const LEDGER_TABLES = [
  'evidenceSnapshots',
  'factProposals',
  'factVersions',
  'factDecisions',
  'rejectionMarks',
  'ledgerMeta',
  'turnReceipts'
]

// Five record types from the plan; the ledger only ever stores the middle
// three as ledger rows. Legacy candidates stay proposal-grade until an author
// decision adopts them; session events live in the turn owner, never here.
export const LEDGER_RECORD_TYPES = ['authorPreference', 'proposal', 'canonicalFact', 'sessionEvent', 'derivedClaim']

export const EVIDENCE_SOURCE_KINDS = ['chapter-quote', 'manual-assertion', 'legacy-candidate']

export const PROPOSAL_ORIGINS = ['author', 'ai', 'legacy-migration']

export const PROPOSAL_STATUSES = ['pending', 'adopted', 'dismissed']

export const DECISION_OPERATIONS = [
  'adopt-proposal',
  'correct-fact',
  'retract-fact',
  'reject-proposal',
  'reopen-rejection',
  'record-world-claim',
  'migrate-legacy'
]

export const LEDGER_FAILURE_REASONS = Object.freeze({
  scopeInvalid: 'scope-invalid',
  commandPayloadConflict: 'command-payload-conflict',
  proposalNotFound: 'proposal-not-found',
  proposalNotPending: 'proposal-not-pending',
  proposalAlreadyAdopted: 'proposal-already-adopted',
  evidenceMissing: 'evidence-missing',
  rejectionActive: 'rejection-active',
  factNotFound: 'fact-not-found',
  headConflict: 'head-conflict',
  noChange: 'no-change',
  rejectionNotFound: 'rejection-not-found',
  claimInvalid: 'claim-invalid',
  dbUnavailable: 'db-unavailable'
})

// K1 ScopeRef: unrelated fields are explicit null; no mixed projectId that
// secretly means both a book and a library.
export function normalizeScopeRef(input) {
  if (!input || typeof input !== 'object') return { ok: false, reason: LEDGER_FAILURE_REASONS.scopeInvalid }
  const domain = input.domain
  if (!LEDGER_DOMAINS.includes(domain)) return { ok: false, reason: LEDGER_FAILURE_REASONS.scopeInvalid }
  const scope = {
    domain,
    bookId: domain === 'book' || domain === 'worldbook' || domain === 'session' ? scopeIdText(input.bookId) : null,
    worldbookId: domain === 'worldbook' || domain === 'session' ? scopeIdText(input.worldbookId) : null,
    sessionId: domain === 'session' ? scopeIdText(input.sessionId) : null,
    branchId: domain === 'session' ? scopeIdText(input.branchId) : null
  }
  // Reject a malformed optional parent instead of addressing its parentless scope.
  const optionalParents = domain === 'session' ? ['bookId', 'worldbookId'] : domain === 'worldbook' ? ['bookId'] : []
  for (const key of optionalParents) {
    if (input[key] != null && !(typeof input[key] === 'string' && !input[key].trim()) && !scope[key]) {
      return { ok: false, reason: LEDGER_FAILURE_REASONS.scopeInvalid }
    }
  }
  if (domain === 'book' && !scope.bookId) return { ok: false, reason: LEDGER_FAILURE_REASONS.scopeInvalid }
  if (domain === 'worldbook' && !scope.worldbookId) return { ok: false, reason: LEDGER_FAILURE_REASONS.scopeInvalid }
  // Session facts need a session AND a branch; legacy session-scope candidates
  // without a branch are unattributable and must not silently claim one.
  if (domain === 'session' && (!scope.sessionId || !scope.branchId)) {
    return { ok: false, reason: LEDGER_FAILURE_REASONS.scopeInvalid }
  }
  return { ok: true, scope }
}

// Canonical fixed-arity encoding with a control-char separator; field ids are
// normalized to exclude it, so ["bo","ok"] and ["book",""] cannot collide.
const SCOPE_FIELD_SEPARATOR = '\u001f'
// Field ids must never contain the separator; enforce during normalization.
export function scopeIdText(value) {
  const text = typeof value === 'string' ? value.trim() : ''
  return text && !text.includes(SCOPE_FIELD_SEPARATOR) ? text : null
}
export function encodeScopeKey(scope) {
  return [
    scope.domain,
    scope.bookId ?? '',
    scope.worldbookId ?? '',
    scope.sessionId ?? '',
    scope.branchId ?? ''
  ].join(SCOPE_FIELD_SEPARATOR)
}

export function scopeRefFromLegacy(scope, scopeId) {
  const id = typeof scopeId === 'string' && scopeId.trim() ? scopeId.trim() : null
  if (scope === 'global-author') return normalizeScopeRef({ domain: 'author' })
  if (scope === 'project') return id ? normalizeScopeRef({ domain: 'book', bookId: id }) : { ok: false, reason: 'legacy-unattributable' }
  // Legacy session candidates carry no branch; record identityKind instead of
  // guessing one. They stay in the migration review list.
  if (scope === 'session') return { ok: false, reason: 'legacy-session-no-branch', identityKind: 'legacy-session' }
  return { ok: false, reason: 'legacy-unattributable' }
}

function normalizeClaimText(value) {
  return String(value ?? '').trim().toLowerCase().replace(/\s+/g, ' ')
}

export function normalizeClaim({ subjectKey, subjectLabel = '', predicate, object }) {
  const subject = normalizeClaimText(subjectKey)
  const action = normalizeClaimText(predicate)
  // Literal contents are evidence, not lookup keys: case and internal spacing
  // can distinguish names, passwords and units (mW vs MW).
  const value = String(object ?? '').trim()
  if (!subject || !action || !value) return { ok: false, reason: LEDGER_FAILURE_REASONS.claimInvalid }
  return {
    ok: true,
    claim: {
      subjectKey: subject,
      subjectLabel: String(subjectLabel ?? '').trim(),
      predicate: action,
      object: value
    }
  }
}

// Explicit policies take precedence. Unclassified historical predicates retain
// their original state slot, including old proposals and correction chains.
const predicateKinds = {
  relation: ['盟友', '同盟', '敌人', '朋友', '亲属', '师承', '成员', '拥有', '信任', 'allied with', 'ally', 'allies', 'enemy', 'member of'],
  event: ['结盟', '加冕', '相遇', '会面', '出生', '逝世', '战斗', 'met', 'visited', 'coronation']
}
export const LEDGER_TEMPORAL_PREDICATE_KINDS = Object.freeze(Object.fromEntries([
  ...predicateKinds.relation.map(name => [name, 'multi-value-relation']),
  ...predicateKinds.event.map(name => [name, 'event'])
]))

export function resolvePredicateTemporalKind(predicate, kind) {
  if (kind === 'state') return 'single-value-state'
  if (kind === 'relation') return 'multi-value-relation'
  if (kind === 'event') return 'event'
  const key = normalizeClaimText(predicate)
  return Object.hasOwn(LEDGER_TEMPORAL_PREDICATE_KINDS, key) ? LEDGER_TEMPORAL_PREDICATE_KINDS[key] : 'single-value-state'
}

export function worldOperand(claim) {
  if (claim.literalValue) return ['typed', claim.literalValue.type, claim.literalValue.value, claim.literalValue.unit ?? null]
  return claim.objectRef ? ['entity', claim.objectRef] : ['literal', claim.object]
}

export function deriveFactKey(claim) {
  if (claim.polarity === 'negative') return 'denial:' + payloadHash([claim.kind, claim.subjectKey, claim.predicate,
    claim.kind === 'event' ? claim.occurrenceId : worldOperand(claim)])
  if (claim.kind === 'relation') return 'relation:' + payloadHash([claim.subjectKey, claim.predicate, worldOperand(claim)])
  if (claim.kind === 'event') return 'event:' + payloadHash([claim.subjectKey, claim.predicate, claim.occurrenceId])
  if (claim.predicate.includes(':')) return 'state:' + payloadHash([claim.subjectKey, claim.predicate])
  return `fact:${claim.subjectKey}:${claim.predicate}`
}

export function claimFingerprint(scopeKey, claim) {
  // Preserve legacy literal rejection marks, including ordinary untyped
  // relationship proposals. Explicit different objects/occurrences stay independent.
  const fields = [scopeKey, claim.subjectKey, claim.predicate, claim.object]
  if (claim.objectRef || claim.occurrenceId || claim.literalValue) fields.splice(3, 1, worldOperand(claim), claim.occurrenceId || null)
  if (claim.eventContext) fields.push(claim.eventContext)
  if (claim.polarity === 'negative') fields.push('negative')
  return payloadHash(fields)
}

export function worldClaimId(scopeKey, claim) {
  const fields = [scopeKey, claim.kind, claim.subjectKey, claim.predicate, worldOperand(claim), claim.occurrenceId || null]
  if (claim.eventContext) fields.push(claim.eventContext)
  if (claim.polarity === 'negative') fields.push('negative')
  return 'claim:' + payloadHash(fields)
}

export function payloadHash(payload) {
  return `sha256-${sha256HexOfText(stableStringify(payload))}`
}

export function ledgerId(prefix, randomUUID) {
  return `${prefix}_${randomUUID()}`
}

export function normalizeStoryIntervalInput(input) {
  const invalid = () => ({ ok: false, reason: 'story-interval-invalid' })
  if (input == null || input.precision === 'unknown') return { ok: true, interval: null }
  if (typeof input !== 'object' || Array.isArray(input)) return invalid()
  const timelineId = typeof input.timelineId === 'string' && input.timelineId.trim()
  if (!timelineId) return invalid()
  function boundary(value) {
    if (typeof value?.eraId !== 'string' || !value.eraId.trim()) return null
    const raw = value.ordinal
    if (raw != null && raw !== '' && typeof raw !== 'number' &&
        !(typeof raw === 'string' && /^[+-]?\d+$/.test(raw.trim()))) return null
    const ordinal = raw == null || raw === '' ? null : Number(raw)
    return ordinal === null || Number.isSafeInteger(ordinal) ? { eraId: value.eraId.trim(), ordinal } : null
  }
  const start = boundary(input.start)
  const end = boundary(input.end)
  const endSemantic = input.endSemantic ?? (end ? 'exclusive' : 'unknown')
  if (!['exclusive', 'open', 'unknown'].includes(endSemantic) || (input.start != null && !start) ||
      (input.end != null && !end) || (endSemantic === 'exclusive') !== Boolean(end)) return invalid()
  if (start && end && start.eraId === end.eraId && start.ordinal !== null && end.ordinal !== null &&
      start.ordinal >= end.ordinal) return invalid()
  if (!start && !end) return { ok: true, interval: null }
  return { ok: true, interval: { timelineId, start, end, endSemantic } }
}

export function sameInterval(left, right) {
  if (left === right) return true
  if (!left || !right) return false
  return stableStringify(left) === stableStringify(right)
}
