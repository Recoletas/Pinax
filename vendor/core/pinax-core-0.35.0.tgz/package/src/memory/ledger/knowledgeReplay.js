import { defaultStoryClock, defaultCalendar } from './storyClock.js'

// A corrected event keeps its original place among events dated to the
// same story point. Its replacement only becomes visible at its own record cut.
function effectiveEvents(events) {
  const superseded = new Set(events.map(event => event.supersedesEventId).filter(Boolean))
  return events.filter(event => !superseded.has(event.id))
    .sort((a, b) => storyOrder(a) - storyOrder(b))
}

export function storyOrder(event) {
  return event.originalRecordedSeq ?? event.recordedSeq
}

export function eventClock(event) { return event.storyClock ?? defaultStoryClock }
function ordersFor(calendar) {
  return new Map(calendar.eras.map(era => [era.id, era.order]))
}
function sameCalendar(event, calendar, orders) {
  const clock = eventClock(event)
  return clock.timelineId === calendar.id && orders.has(clock.eraId)
}
function byStoryOrder(events, orders) {
  // Undated observations have no comparison to a fictional time. At the live
  // view keep them in their recording slots; dated observations replay by story.
  const dated = events.filter(event => event.storyAt != null)
    .sort((a, b) => orders.get(eventClock(a).eraId) - orders.get(eventClock(b).eraId) || a.storyAt - b.storyAt || storyOrder(a) - storyOrder(b))
  let next = 0
  return events.map(event => event.storyAt == null ? event : dated[next++])
}

export function foldEvents(events, storyAt, tally, includePassages, clock, calendar, strictDates = true) {
  const orders = ordersFor(calendar)
  const effective = effectiveEvents(events)
  const keyOf = event => event.claimId ? 'claim:' + event.claimId : 'version:' + event.factVersionId
  // No conversion between calendars has been declared. A later attitude
  // or forgetting in another calendar cannot be joined to this history.
  const uncertain = new Set(effective.filter(event => !sameCalendar(event, calendar, orders)).map(keyOf))
  if (uncertain.size) tally('calendar-incomparable')
  const targetEra = orders.get(clock.eraId)
  const arrived = event => {
    const era = orders.get(eventClock(event).eraId)
    return Number.isFinite(event.storyAt) && (era < targetEra || (era === targetEra && event.storyAt <= storyAt))
  }
  const undetermined = new Set()
  if (strictDates && storyAt !== null) {
    const datedKnowledge = new Set(), datedForgetting = new Set()
    const local = effective.filter(event => sameCalendar(event, calendar, orders))
    for (const event of local) {
      if (!arrived(event)) continue
      if (event.kind === 'known') datedKnowledge.add(keyOf(event))
      else if (event.belief === 'forgotten') datedForgetting.add(keyOf(event))
    }
    for (const event of local) {
      if (event.storyAt != null) continue
      const key = keyOf(event)
      if (event.kind === 'belief' || event.belief != null || !datedKnowledge.has(key) || datedForgetting.has(key)) undetermined.add(key)
    }
    if (undetermined.size) tally('knowledge-date-unknown')
  }
  const visible = effective.filter(event => {
    if (!sameCalendar(event, calendar, orders)) return false
    if (undetermined.has(keyOf(event))) {
      if (event.kind === 'known' && event.storyAt == null) tally('known-at-unknown-story-time')
      return false
    }
    if (uncertain.has(keyOf(event)) && !(includePassages && storyAt === null)) return false
    if (storyAt === null) return true
    if (arrived(event)) return true
    if (event.kind === 'known') tally(event.storyAt == null ? 'known-at-unknown-story-time' : 'known-later')
    return false
  })
  const groups = new Map()
  for (const event of visible) {
    const key = keyOf(event)
    if (!groups.has(key)) groups.set(key, [])
    groups.get(key).push(event)
  }
  const beliefs = []
  for (const group of groups.values()) {
    let entry
    const history = []
    for (const event of byStoryOrder(group, orders)) {
      history.push({ id: event.id, factVersionId: event.factVersionId ?? null, kind: event.kind, channel: event.channel, belief: event.belief ?? null,
        storyAt: event.storyAt ?? null, ...(event.storyClock ? { storyClock: event.storyClock } : {}), recordedSeq: event.recordedSeq, sourceRef: event.sourceRef ?? null,
        ...(event.speaker ? { speaker: event.speaker } : {}), ...(includePassages && event.passage ? { passage: event.passage } : {}) })
      if (event.kind === 'known') {
        if (entry && entry.belief !== 'forgotten') {
          entry.lastKnownVia = event.channel
          entry.lastSpeaker = event.speaker ?? null
          continue
        }
        entry = {
          claimId: event.claimId ?? null, factVersionId: event.factVersionId ?? null,
          ...(event.storyClock ? { knownClock: event.storyClock } : {}), lastSpeaker: event.speaker ?? null, knownVia: event.channel, lastKnownVia: event.channel, knownAtStory: event.storyAt ?? null, knownAtSeq: event.recordedSeq,
          belief: event.belief ?? (event.schemaVersion !== 2 && event.factVersionId ? 'active' : null), beliefAtSeq: event.recordedSeq
        }
      } else if (entry && entry.belief !== 'forgotten') {
        entry.belief = event.belief
        entry.beliefAtSeq = event.recordedSeq
      } else {
        tally('belief-without-known')
      }
    }
    if (entry) beliefs.push({ ...entry, history })
  }
  return beliefs
}

// Freeze the observations supporting a character's action at its story point.
// Use the same replay as the character view so corrections and forgetting agree.
export function knowledgeBasis(events, { actorKey, claimId, storyAt, recordedSeq, storyClock = defaultStoryClock, calendar = defaultCalendar, strictDates = true }) {
  const visible = events.filter(row => row.actorKey === actorKey && row.claimId === claimId &&
    (recordedSeq == null || row.recordedSeq <= recordedSeq))
  let incomparable = false
  let dateUnknown = false
  const [entry] = foldEvents(visible, storyAt, reason => {
    if (reason === 'calendar-incomparable') incomparable = true
    if (reason === 'knowledge-date-unknown') dateUnknown = true
  }, false, storyClock, calendar, strictDates)
  if (incomparable) return { incomparable: true }
  if (dateUnknown) return { dateUnknown: true }
  if (!entry) return null
  const observation = entry.history.filter(row => row.kind === 'known').at(-1)
  const attitude = entry.history.find(row => row.recordedSeq === entry.beliefAtSeq && row.kind === 'belief')
  return { observationId: observation.id, attitudeId: attitude?.id ?? null, channel: entry.lastKnownVia,
    belief: entry.belief, speakerKey: entry.lastSpeaker?.entityRef ?? null }
}

// A dated change of mind must stand on dated knowledge. For undated
// entries the author's recording order determines where they can be replayed.
export function orphanAttitudes(events, calendar) {
  const orders = ordersFor(calendar)
  const live = effectiveEvents(events).filter(event => sameCalendar(event, calendar, orders))
  const orphan = new Set()
  for (const rows of [live, live.filter(event => event.storyAt != null)]) {
    let aware = false
    for (const event of byStoryOrder(rows, orders)) {
      if (event.kind === 'known') aware = true
      else if (!aware) orphan.add(event.id)
      else if (event.belief === 'forgotten') aware = false
    }
  }
  return orphan
}
