import { encodeScopeKey, worldClaimId } from './ledgerContract.js'
import { factForkSession } from './worldFactFork.js'
import { isVisibleAt } from './recordAxis.js'
import { stableStringify } from '../knowledgeContract.js'

export function validateWorldForks({ version, decisions, versions, evidence, claims, meta }) {
  const ids = new Map(decisions.map(row => [row.id, row]))
  const targets = new Set()
  const fail = () => { throw new Error('试写分支的来源、记录截面或继承内容无效') }
  for (const row of decisions) {
    const fork = row.result?.fork
    if (!fork && row.operation !== 'fork-world-facts') continue
    if (version < 14 || row.operation !== 'fork-world-facts' || !fork || targets.has(row.scopeKey) ||
        row.scope?.domain !== 'session' || row.scope.sessionId !== factForkSession || !row.scope.bookId ||
        fork.parentScopeKey !== encodeScopeKey({ domain: 'book', bookId: row.scope.bookId }) ||
        typeof fork.label !== 'string' || !fork.label.trim() || !Number.isSafeInteger(fork.parentRecordedSeq) ||
        fork.parentRecordedSeq < 0 || fork.parentRecordedSeq > (meta.get('seq:' + fork.parentScopeKey)?.seq ?? 0) ||
        !Array.isArray(fork.factSources) || !Array.isArray(fork.calendarSources)) fail()
    targets.add(row.scopeKey)
    const expected = new Set([...versions.values()].filter(v => v.scopeKey === fork.parentScopeKey && isVisibleAt(v, fork.parentRecordedSeq)).map(v => v.id))
    const childIds = new Set()
    for (const pair of fork.factSources) {
      const source = versions.get(pair?.from), copy = versions.get(pair?.to)
      const claim = claims.get(source?.claimId) ?? source
      if (!source || !expected.delete(source.id) || !copy || childIds.has(copy.id) || copy.scopeKey !== row.scopeKey ||
          copy.visibleFromSeq !== row.recordedSeq || copy.supersedes || !isVisibleAt(copy, row.recordedSeq) ||
          copy.factKey !== source.factKey || copy.claimId !== worldClaimId(row.scopeKey, claim) ||
          Boolean(copy.supersedesKind) !== Boolean(source.supersedesKind) ||
          stableStringify(copy.validInterval ?? null) !== stableStringify(source.validInterval ?? null) ||
          copy.authority !== source.authority || copy.origin !== source.origin || copy.evidenceIds.length !== source.evidenceIds.length) fail()
      childIds.add(copy.id)
      for (let i = 0; i < copy.evidenceIds.length; i++) {
        const a = evidence.get(source.evidenceIds[i]), b = evidence.get(copy.evidenceIds[i])
        if (!a || !b || a.scopeKey !== fork.parentScopeKey || b.scopeKey !== row.scopeKey ||
            ['sourceKind', 'sourceId', 'sourceRevision', 'contentHash', 'quote'].some(key => a[key] !== b[key])) fail()
      }
    }
    if (expected.size) fail()
    const latest = new Map()
    for (const decision of decisions) {
      if (decision.scopeKey !== fork.parentScopeKey || decision.operation !== 'define-story-calendar' ||
          !isVisibleAt(decision, fork.parentRecordedSeq)) continue
      const id = decision.result.calendar.id
      if (!latest.has(id) || latest.get(id).recordedSeq < decision.recordedSeq) latest.set(id, decision)
    }
    for (const pair of fork.calendarSources) {
      const source = ids.get(pair?.from), copy = ids.get(pair?.to), calendar = source?.result?.calendar
      if (!calendar || latest.get(calendar.id)?.id !== source.id || !copy || copy.scopeKey !== row.scopeKey ||
          copy.visibleFromSeq !== row.recordedSeq || copy.operation !== 'define-story-calendar' ||
          stableStringify(calendar) !== stableStringify(copy.result?.calendar)) fail()
      latest.delete(calendar.id)
    }
    if (latest.size) fail()
  }
}
