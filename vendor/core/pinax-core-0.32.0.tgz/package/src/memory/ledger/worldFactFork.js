import { normalizeScopeRef, encodeScopeKey } from './ledgerContract.js'
import { ensureWorldClaim, legacyWorldClaimForVersion, normalizeWorldClaim } from './worldClaims.js'
import { isVisibleAt } from './recordAxis.js'
import { listWorldCalendars } from './worldCalendars.js'

const fail = reason => ({ ok: false, reason })
export const factForkSession = 'pinax-novel-facts'

export async function listWorldFactForks(db, { scope }) {
  const source = normalizeScopeRef(scope)
  if (!source.ok || source.scope.domain !== 'book') return fail('fork-parent-invalid')
  const rows = await db.table('factDecisions').where('result.fork.parentScopeKey').equals(encodeScopeKey(source.scope)).toArray()
  return { ok: true, items: rows.map(row => ({ scope: row.scope, label: row.result.fork.label,
    parentRecordedSeq: row.result.fork.parentRecordedSeq, count: row.result.fork.factSources.length, recordedAt: row.recordedAt }))
    .sort((a, b) => a.recordedAt - b.recordedAt || a.scope.branchId.localeCompare(b.scope.branchId)) }
}

// Materialize only confirmed world facts and the calendars that interpret
// them. Character and reader records are independently authored in each scope.
export function forkWorldFacts(db, input, { runCommand, ledgerId }) {
  const parent = normalizeScopeRef(input?.scope)
  const child = normalizeScopeRef({ domain: 'session', sessionId: factForkSession, bookId: parent.scope?.bookId, branchId: input?.branchId })
  if (!parent.ok || parent.scope.domain !== 'book' || !child.ok) return fail('fork-parent-invalid')
  const label = typeof input.label === 'string' && input.label.trim()
  const requested = input.recordedSeq ?? null
  if (!label || (requested !== null && (!Number.isSafeInteger(requested) || requested < 0))) return fail('fork-input-invalid')
  const parentScopeKey = encodeScopeKey(parent.scope)
  return runCommand(db, child.scope, input.commandId, { action: 'fork-world-facts', parentScopeKey, requested, label }, async context => {
    const { tables, seq, scopeKey, scope } = context
    if (seq !== 1 || await tables.proposals.where('scopeKey').equals(scopeKey).count() ||
        await tables.evidence.where('scopeKey').equals(scopeKey).count()) return fail('fork-target-used')
    const current = (await tables.meta.get('seq:' + parentScopeKey))?.seq ?? 0
    const cutoff = requested ?? current
    if (cutoff > current) return fail('fork-cutoff-future')
    const source = (await tables.versions.where('[scopeKey+recordedSeq]').between([parentScopeKey, 0], [parentScopeKey, cutoff], true, true).toArray())
      .filter(row => isVisibleAt(row, cutoff))
    const calendars = (await listWorldCalendars(db, { scope: parent.scope, recordedSeq: cutoff })).items.filter(row => row.id !== 'default')
    const forkSeq = seq + calendars.length + source.length
    let physical = seq
    const calendarSources = []
    for (const { revisionId, ...calendar } of calendars) {
      const id = ledgerId('dec')
      await tables.decisions.add({ id, commandId: 'fork-calendar:' + id, scopeKey, scope, operation: 'define-story-calendar',
        actorKind: 'author', actorRef: '', reason: '', beforeIds: [], afterIds: [], recordedAt: Date.now(),
        recordedSeq: physical++, visibleFromSeq: forkSeq, result: { calendar } })
      calendarSources.push({ from: revisionId, to: id })
    }
    const evidenceMap = new Map()
    const factSources = []
    for (const version of source) {
      const original = version.claimId ? await tables.claims.get(version.claimId) : legacyWorldClaimForVersion(version)
      if (original?.scopeKey !== parentScopeKey) return fail('fork-source-incomplete')
      const normalized = normalizeWorldClaim(original, original.occurrenceId)
      if (!normalized.ok) return fail('fork-source-incomplete')
      const claim = normalized.claim
      const claimId = await ensureWorldClaim(tables.claims, context, claim)
      const evidenceIds = []
      for (const oldId of version.evidenceIds || []) {
        if (!evidenceMap.has(oldId)) {
          const evidence = await tables.evidence.get(oldId)
          if (evidence?.scopeKey !== parentScopeKey) return fail('fork-source-incomplete')
          const newId = ledgerId('ev')
          await tables.evidence.add({ ...evidence, id: newId, scopeKey, scope })
          evidenceMap.set(oldId, newId)
        }
        evidenceIds.push(evidenceMap.get(oldId))
      }
      const newId = ledgerId('fv')
      await tables.versions.add({ id: newId, schemaVersion: 2, scopeKey, scope, ...claim, claimId, factKey: version.factKey, evidenceIds,
        validInterval: version.validInterval ?? null, authority: version.authority, origin: version.origin, legacyRefs: null,
        recordedAt: Date.now(), recordedSeq: physical++, visibleFromSeq: forkSeq, supersedes: null,
        ...(version.supersedesKind ? { supersedesKind: 'historical-state' } : {}) })
      factSources.push({ from: version.id, to: newId })
    }
    await tables.meta.put({ id: 'seq:' + scopeKey, seq: forkSeq })
    return { operation: 'fork-world-facts', commitSeq: forkSeq, result: { fork: { parentScopeKey, parentRecordedSeq: cutoff, label, factSources, calendarSources } } }
  })
}
