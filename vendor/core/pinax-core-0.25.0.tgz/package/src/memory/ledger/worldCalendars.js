import { validateTimeline } from '../knowledgeTime.js'
import { normalizeScopeRef, encodeScopeKey } from './ledgerContract.js'
import { isVisibleAt } from './recordAxis.js'

export const defaultStoryClock = Object.freeze({ timelineId: 'default', eraId: 'default' })
const defaultCalendar = Object.freeze({ id: 'default', label: '默认时间线', eras: Object.freeze([Object.freeze({ id: 'default', label: '默认纪元', order: 0 })]) })
const fail = reason => ({ ok: false, reason })
const text = value => typeof value === 'string' ? value.trim() : ''

export function normalizeStoryClock(clock) {
  if (clock == null) return defaultStoryClock
  const timelineId = text(clock.timelineId)
  const eraId = text(clock.eraId)
  return timelineId && eraId ? { timelineId, eraId } : null
}

export function normalizeCalendar(input) {
  if (!input || !Array.isArray(input.eras)) return fail('timeline-invalid')
  const calendar = { id: text(input.id), label: text(input.label) || text(input.id), eras: input.eras.map(era => ({
    id: text(era?.id), label: text(era?.label) || text(era?.id), order: era?.order
  })) }
  const valid = validateTimeline(calendar)
  return valid.ok ? { ok: true, calendar } : fail(valid.error)
}

export async function loadCalendarAt(db, scopeKey, timelineId, recordedSeq = null) {
  if (timelineId === 'default') return { ...defaultCalendar, revisionId: null }
  const row = await db.table('factDecisions').where('[scopeKey+result.calendar.id+recordedSeq]')
    .between([scopeKey, timelineId, 0], [scopeKey, timelineId, recordedSeq ?? Number.MAX_SAFE_INTEGER], true, true).last()
  return row ? { ...row.result.calendar, revisionId: row.id } : null
}

export async function listWorldCalendars(db, { scope, recordedSeq = null }) {
  const resolved = normalizeScopeRef(scope)
  if (!resolved.ok) return resolved
  if (recordedSeq !== null && (!Number.isSafeInteger(recordedSeq) || recordedSeq < 0)) return fail('recorded-as-of-invalid')
  const scopeKey = encodeScopeKey(resolved.scope)
  const history = await db.table('factDecisions').where('[scopeKey+operation+recordedSeq]')
    .between([scopeKey, 'define-story-calendar', 0], [scopeKey, 'define-story-calendar', recordedSeq ?? Number.MAX_SAFE_INTEGER], true, true).toArray()
  const calendars = new Map([['default', { ...defaultCalendar, revisionId: null }]])
  for (const row of history) calendars.set(row.result.calendar.id, { ...row.result.calendar, revisionId: row.id })
  return { ok: true, items: [...calendars.values()] }
}

export function defineWorldCalendar(db, input, runCommand) {
  const normalized = normalizeCalendar(input?.calendar)
  if (!normalized.ok) return normalized
  const { calendar } = normalized
  if (calendar.id === 'default') return fail('calendar-default-reserved')
  const expectedRevisionId = input.expectedRevisionId ?? null
  const payload = { operation: 'define-story-calendar', calendar, expectedRevisionId }
  return runCommand(db, input.scope, input.commandId, payload, async ({ tables, scopeKey }) => {
    const prior = await loadCalendarAt(db, scopeKey, calendar.id)
    if ((prior?.revisionId ?? null) !== expectedRevisionId) return fail('calendar-revision-changed')
    if (prior && prior.label === calendar.label && JSON.stringify(prior.eras) === JSON.stringify(calendar.eras)) return fail('no-change')
    const eras = new Map(calendar.eras.map(era => [era.id, era.order]))
    const conflict = await tables.versions.where('scopeKey').equals(scopeKey).filter(row => {
      const interval = row.validInterval
      if (!isVisibleAt(row) || interval?.timelineId !== calendar.id) return false
      return [interval.start, interval.end].some(point => point && !eras.has(point.eraId)) ||
        (interval.start && interval.end && eras.get(interval.start.eraId) > eras.get(interval.end.eraId))
    }).first()
    if (conflict) return { ...fail('calendar-fact-conflict'), factVersionId: conflict.id }
    return { operation: payload.operation, beforeIds: prior ? [prior.revisionId] : [], result: { calendar } }
  })
}
