import { shortenLine, uniqueStrings, SUMMARY_PREFIX, DEFAULT_MAX_SUMMARY_CHARS, normalizeMessages, resolveKeepRecentCount, isSummaryMessage, selectRecentMessages, stripSummaryPrefix, normalizeSummaryText, buildHeuristicContextSummary } from './heuristicContextSummary.js'

export function createContextCompression({ runGenerationTask }) {
async function compressChatHistory(chatHistory, options = {}) {
  const messages = normalizeMessages(chatHistory)
  const keepRecentCount = resolveKeepRecentCount(options.keepRecentCount)
  const systemPrompt = messages[0]?.role === 'system' && !isSummaryMessage(messages[0]) ? messages[0] : null
  const bodyStart = systemPrompt ? 1 : 0
  const bodyMessages = messages.slice(bodyStart)

  if (bodyMessages.length <= keepRecentCount) {
    return { compressed: false, reason: '历史过短，无需压缩' }
  }

  const recentMessages = selectRecentMessages(bodyMessages, keepRecentCount)
  const oldMessages = bodyMessages.slice(0, bodyMessages.length - recentMessages.length)
  const sourceMessages = oldMessages.filter((message) => !isSummaryMessage(message))
  const existingSummaries = oldMessages
    .filter(isSummaryMessage)
    .map((message) => stripSummaryPrefix(message.content))
    .filter(Boolean)

  if (sourceMessages.length === 0) {
    return { compressed: false, reason: '无新的历史可压缩' }
  }

  const heuristicSummary = buildHeuristicContextSummary(sourceMessages, {
    existingSummaries,
    maxSummaryChars: options.maxSummaryChars || DEFAULT_MAX_SUMMARY_CHARS
  })
  const llmSummary = await buildLlmSummary({
    messages: sourceMessages,
    existingSummaries,
    heuristicSummary,
    settings: options.settings,
    worldId: options.worldId,
    preferLlm: options.preferLlm !== false,
    maxSummaryChars: options.maxSummaryChars || DEFAULT_MAX_SUMMARY_CHARS
  })
  const summary = normalizeSummaryText(llmSummary || heuristicSummary, options.maxSummaryChars || DEFAULT_MAX_SUMMARY_CHARS)
  const summaryMessage = {
    role: 'system',
    content: `${SUMMARY_PREFIX}${summary}`
  }
  const newHistory = systemPrompt
    ? [systemPrompt, summaryMessage, ...recentMessages]
    : [summaryMessage, ...recentMessages]

  return {
    compressed: true,
    oldCount: oldMessages.length,
    sourceCount: sourceMessages.length,
    recentCount: recentMessages.length,
    newCount: newHistory.length,
    method: llmSummary ? 'llm' : 'heuristic',
    summary,
    newHistory
  }
}

function hasUsableSettings(settings) {
  return Boolean(settings?.baseUrl && settings?.apiKey && settings?.model)
}

async function buildLlmSummary({
  messages,
  existingSummaries,
  heuristicSummary,
  settings,
  worldId,
  preferLlm,
  maxSummaryChars
}) {
  if (!preferLlm || !hasUsableSettings(settings)) return ''

  try {
    const result = await runGenerationTask({
      taskType: 'authoring.context.compact',
      baseMessages: buildContextCompressionMessages({
        messages,
        existingSummaries,
        heuristicSummary,
        maxSummaryChars
      }),
      settings,
      worldId: worldId || null,
      generationOptions: {
        temperature: 0.1,
        attemptName: 'context-compress',
        max_input_chars: 9000
      },
      isValidParsed: null
    })
    return normalizeSummaryText(result?.content || '', maxSummaryChars)
  } catch {

    return ''
  }
}

function buildContextCompressionMessages({ messages, existingSummaries, heuristicSummary, maxSummaryChars }) {
  const source = messages
    .map((message, index) => `${index + 1}. ${message.role === 'assistant' ? '叙述者' : '用户'}：${shortenLine(message.content, 700)}`)
    .join('\n')
  const previous = uniqueStrings(existingSummaries || []).map((item) => `- ${shortenLine(stripSummaryPrefix(item), 240)}`).join('\n') || '无'

  return [
    {
      role: 'system',
      content: [
        '你是小说体验的上下文压缩器。',
        '任务：把历史对话压缩成可继续创作的中文系统摘要，不要续写剧情。',
        '保留：剧情因果、玩家意图、角色状态/关系、地点/物品、未解决线索、重要对白。',
        '删除：寒暄、重复措辞、无效转场、纯修辞。',
        `长度控制在 ${maxSummaryChars} 字以内，使用分节和短项目符号。`
      ].join('\n')
    },
    {
      role: 'user',
      content: [
        '【既有摘要】',
        previous,
        '',
        '【本地预摘要】',
        heuristicSummary || '无',
        '',
        '【待压缩历史】',
        source
      ].join('\n')
    }
  ]
}

return { compressChatHistory }
}
