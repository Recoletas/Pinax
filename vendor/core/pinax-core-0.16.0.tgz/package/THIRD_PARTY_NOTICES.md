# Third-party notices

`src/media/comicRequestGuard.js` 参考 yuanbw2025/storyforge 的请求登记与未知结果策略，基线 `cd1236cfa5c7cbd307ed0dfac5487f9fe5c98aed`，由 Pinax 按自身 owner 重写，并非逐行复制。来源为 `src/lib/comic/image-request-guard.ts`，MIT，Copyright (c) 2026 yuanbw2025。

原来源注释保留；完整许可随包提供于 `licenses/storyforge-LICENSE.txt`。Core 的私有许可证不替代此许可。其他包依赖沿用各自许可证。

体验/跑团模块保留 Pinax 原复用的 StoryForge MIT 代码：
- `src/experience/roleplay/third-party/storyforgeDice.js`：`src/lib/ttrpg/dice.ts`，基线 `cd1236cfa5c7cbd307ed0dfac5487f9fe5c98aed`，保留骰式、拒绝采样及trace；浏览器crypto实现留Host。
- `src/experience/run/runContract.js`：`src/lib/agent/run/hash.ts`及`checkpoint.ts`的规范化、恢复分类，基线`1935dab`，改为既有同步SHA-256与持久步骤回执。
- `src/experience/roleplay/roleplayKpCoordinator.js`：`src/lib/ttrpg/kp-coordinator.ts`协调结构，基线`1935dab`；数据库/生成/锁通过Pinax端口接入。

来源 https://github.com/yuanbw2025/storyforge ，Copyright (c) 2026 yuanbw2025。完整许可见`licenses/storyforge-LICENSE.txt`；原文件内归因保留。
