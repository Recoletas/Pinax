# @pinax/core

Pinax 三端（Web / Pinix 移动端 / Next 极简版）共用的**平台无关业务内核**。三端各自只保留 UI 与平台适配，业务规则集中在这里——改业务只改 Core，不再各写一份。

> 当前范围：已落 **写作两级（书 + 章节）**、**世界书条目**、**大纲（节点+边+换父级/重排）**、**笔记** 与 **资料(素材)** 七个域（v0.8.0）。这是纵向切片的推进,不是 Core 的最终形态——目标 Core 覆盖全部业务;边端点存在性跨表校验、资料的图片/证据引用/批量合并、漫画、体验、记忆/事实账本、Agent/上下文/工具与跨端数据迁移仍在后续切片。章节、大纲节点带乐观并发;书、世界书条目、大纲边、笔记、资料按各自宿主现状建模（富字段原样保留）。

## 边界

- 「平台无关」指 Core **不依赖** Vue / DOM / Electron / Capacitor / Node `fs` / `localStorage` 这类宿主能力；纯 JS 依赖允许。平台能力通过 `ChapterStore` 这类**端口**注入，由 Host 提供实现。
- Host 不写业务规则，只调用 Core + 平台 adapter。revision 递增、content-only 保存清结构化侧车、乐观并发等语义只在 `applyChapterPatch` 一处决定；Host 的 store 与内存参照适配器都调它。
- 数据字段：Core 只承诺章节的 `id/title/content/revision/editorDocument` 语义，未知字段原样保留。空标题合法（显示文案归 Host）。旧数据无独立 `chapter.revision` 时按 `editorDocument.revision` 读取。

## API

```js
import {
  createChapterService,       // 异步用例（移动 / 文件端）
  createSyncChapterService,   // 同步用例（localStorage 这类同步 Host）
  applyChapterPatch,          // 保存语义纯函数（Host store.update 调用）
  CHAPTER_SIDECAR_KEYS,
  createMemoryChapterStore,   // 内存参照适配器（测试 / 对照，非生产存储）
  normalizeChapterRecord,
  chapterRevision,
  CORE_ERROR_CODES,           // INVALID_INPUT / BOOK_NOT_FOUND / CHAPTER_NOT_FOUND / STALE_REVISION / DUPLICATE_CHAPTER / IO_FAILED
  ok, fail
} from '@pinax/core'
```

`ChapterStore` 端口方法：`list` / `read` / `create` / `update` / `remove`。Host 侧示例见 Pinax 的 `src/services/writing/chapterCoreStore.js`（浏览器）与 Pinix 的 `createNativeChapterStore`（移动端），两者 `update` 都走 `applyChapterPatch`，行为一致。

## 开发与验证

```bash
npm install
npm test          # vitest：章节用例 + applyChapterPatch 用例
npm run pack      # 生成 dist/pinax-core-<version>.tgz
npm run smoke     # 打 tarball、装进临时消费项目、跑一遍章节 CRUD（证明可作为独立产物被消费）
```

## 作为独立包被三端消费

跨仓共用走**独立仓库引用**：Core 是独立仓库里的 `@pinax/core` 包，三端引用打包产物，不复制源码、不用 monorepo、不用 submodule。0.x 阶段消费方固定精确版本。

- 本地开发：宿主用 `file:` 指向 `npm pack` 出的 tarball。刷新陷阱——版本号没变时 `npm install` 会判定 up-to-date，改完 Core 要在宿主显式重装该 tarball：`npm install <path>/pinax-core-<version>.tgz`。
- 正式发布 / CI：应换成可追溯版本（私有 registry / GitHub Packages）。**发布配置（registry、可见性）当前未写入，包保持 `private: true`**，待作者确定私有远程后再落。

## 目录

```text
src/
  contracts/   # result / error 信封
  domain/      # 章节规范形状、revision、applyChapterPatch
  ports/       # ChapterStore 合同
  usecases/    # 章节业务用例（异步 + 同步）
  adapters/    # 内存 Store（测试 / 对照）
test/          # Core 合同测试
scripts/       # consumer-smoke 自检
```

## 下一步

1. 章节其余路径（重排、历史恢复、大纲同步）与 Pinix 页面调用点切到 Core。
2. Next 的章节 carrier 改为调用 Core。
3. 扩到世界书、资料、Agent / 上下文、漫画。
4. 跨端数据迁移（旧 ZIP / 旧项目 / 移动快照 → Core 项目）。
