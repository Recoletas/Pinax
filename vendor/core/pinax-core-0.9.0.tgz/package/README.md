# @pinax/core

Pinax 三端（Web / Pinix 移动端 / Next 极简版）共用的**平台无关业务内核**。三端各自只保留 UI 与平台适配，业务规则集中在这里——改业务只改 Core，不再各写一份。

> 当前范围：已落 **写作两级（书 + 章节）**、**世界书条目**、**大纲（节点+边+换父级/重排）**、**笔记** 与 **资料(素材)** 七个域（v0.8.0）。这是纵向切片的推进,不是 Core 的最终形态——目标 Core 覆盖全部业务;边端点存在性跨表校验、资料的图片/证据引用/批量合并、漫画、体验、记忆/事实账本、Agent/上下文/工具与跨端数据迁移仍在后续切片。章节、大纲节点带乐观并发;书、世界书条目、大纲边、笔记、资料按各自宿主现状建模（富字段原样保留）。

## 边界

- 「平台无关」指 Core **不依赖** Vue / DOM / Electron / Capacitor / Node `fs` / `localStorage` 这类宿主能力；纯 JS 依赖允许。平台能力通过 `ChapterStore` 这类**端口**注入，由 Host 提供实现。
- Host 不写业务规则，只调用 Core + 平台 adapter。revision 递增、content-only 保存清结构化侧车、乐观并发等语义只在 `applyChapterPatch` 一处决定；Host 的 store 与内存参照适配器都调它。
- 数据字段：Core 只承诺章节的 `id/title/content/revision/editorDocument` 语义，未知字段原样保留。空标题合法（显示文案归 Host）。旧数据无独立 `chapter.revision` 时按 `editorDocument.revision` 读取。

## API

```js
import {
  createChapterService,       // 异步用例（移动 / 文件端）
  createSyncChapterService,   // 同步用例（localStorage 这类同步 Host）
  applyChapterPatch,          // 保存语义纯函数（Host store.update 调用）
  CHAPTER_SIDECAR_KEYS,
  createMemoryChapterStore,   // 内存参照适配器（测试 / 对照，非生产存储）
  normalizeChapterRecord,
  chapterRevision,
  CORE_ERROR_CODES,           // INVALID_INPUT / BOOK_NOT_FOUND / CHAPTER_NOT_FOUND / STALE_REVISION / DUPLICATE_CHAPTER / IO_FAILED
  ok, fail
} from '@pinax/core'
```

`ChapterStore` 端口方法：`list` / `read` / `create` / `update` / `remove`。Host 侧示例见 Pinax 的 `src/services/writing/chapterCoreStore.js`（浏览器）与 Pinix 的 `createNativeChapterStore`（移动端），两者 `update` 都走 `applyChapterPatch`，行为一致。

## 开发与验证

```bash
npm install
npm test          # vitest：章节用例 + applyChapterPatch 用例
npm run pack      # 生成 dist/pinax-core-<version>.tgz
npm run smoke     # 打 tarball、装进临时消费项目、跑一遍章节 CRUD（证明可作为独立产物被消费）
```

## 作为独立包被三端消费

跨仓共用走**独立仓库引用**：Core 是独立仓库里的 `@pinax/core` 包，三端引用打包产物，不复制源码、不用 monorepo、不用 submodule。0.x 阶段消费方固定精确版本。

- 本地开发：宿主用 `file:` 指向 `npm pack` 出的 tarball。刷新陷阱——版本号没变时 `npm install` 会判定 up-to-date，改完 Core 要在宿主显式重装该 tarball：`npm install <path>/pinax-core-<version>.tgz`。
- 正式发布 / CI：应换成可追溯版本（私有 registry / GitHub Packages）。**发布配置（registry、可见性）当前未写入，包保持 `private: true`**，待作者确定私有远程后再落。

## 目录

```text
src/
  contracts/   # result / error 信封
  domain/      # 章节规范形状、revision、applyChapterPatch
  ports/       # ChapterStore 合同
  usecases/    # 章节业务用例（异步 + 同步）
  adapters/    # 内存 Store（测试 / 对照）
test/          # Core 合同测试
scripts/       # consumer-smoke 自检
```

## 下一步

1. 章节其余路径（重排、历史恢复、大纲同步）与 Pinix 页面调用点切到 Core。
2. Next 的章节 carrier 改为调用 Core。
3. 扩到世界书、资料、Agent / 上下文、漫画。
4. 跨端数据迁移（旧 ZIP / 旧项目 / 移动快照 → Core 项目）。

## v0.9 分工基线：公共写入与助手修改

- `createAssistantProposalEngine({ documents, parseCharacterEntryProfile, idFactory, now, timestamp })`：冻结修改、定位原文、依赖分组、计算采纳/拒绝/撤销。返回新的内容与回执，不写存储；编辑器结构和人物卡正文投影由 Host 注入。`assistantConversationWorkingSet` 等函数统一已处理决定和结束审阅状态。模型循环及界面不属于此引擎。
- `assistantPermission`、`assistantEditProposal`、`assistantEntryDetails` 子路径：权限检查、工具 schema、修改验证和富关系合并的唯一实现。Host 兼容入口只转发，运行器打包携带这个固定包的合同源码。
- `createJournaledWriteStore`：注入同步读/写/删除/哈希与日志键，提供多键写入、回读校验和逆向补偿；可带每键 `expected` 快照。明确的 `operationId` 在同一事务保存回执，重复命令返回原回执、不同内容复用ID报错。同步 adapter 必须同步完成承诺的持久化。该算法是可恢复补偿，不是跨介质 ACID，也不提供跨进程锁。
- `createProjectTransactionService`：命令带 `projectId/operationId` 与各项 `entityType/entityId/expectedRevision/after`，统一校验、修订递增、幂等回执。Host 提供项目隔离的 `keyOf/operationKeyOf`，不能把界面当前作品当成异步任务目标。实体创建使用不存在对象的revision=0；删除暂走既有领域接口，不能用空对象冒充删除。
- `createDurableTransactionService`：移动/文件 Host 可将本地事务与 `flush` 串行组合。只有 `flush` 明确返回true或`{ok:true}`才发布 durable 成功；失败返回 `PERSISTENCE_PENDING`，保留本地事务供同operation重试。它不替代平台原子写和崩溃恢复，不把排队中的写入当保存完成。

A组实现存储端口、原子落盘/锁、flush、备份和恢复；B组调用领域服务/修改引擎并维护编辑器映射，不能在UI复制修订与采纳规则；C组实现媒体提交/轮询/产物保存，并使用稳定项目与实体身份。公共API增改由集成维护者发布新版本。三组不必等待全部历史业务迁入后才开工。

最小验收：同一修改可以采纳、拒绝、撤销、结束审阅；失效原文/错项目拒写；提交失败没有成功回执；幂等重试不重复增修订；flush失败后同操作可恢复。业务引擎不得依赖Vue、DOM、Electron、Capacitor或Node文件系统。正式文件写入与网络生命周期仍由相应Host负责。
