// A saved edition describes the order and text hashes of concrete manuscript
// units. Only evidence explicitly linked by the author retains its quoted prose.
import { encodeScopeKey, normalizeScopeRef, payloadHash } from './ledgerContract.js'
import { sha256HexOfText } from '../../domain/contentHash.js'

const populated = value => typeof value === 'string' && value.trim().length > 0
const unitHash = value => typeof value === 'string' && /^[0-9a-f]{64}$/.test(value)
const fail = () => ({ ok: false, reason: 'manuscript-edition-invalid' })

function editionPrefix(previous, kind, id) {
  return sha256HexOfText(JSON.stringify([previous, kind, id]))
}

const editionSeed = 'pinax-manuscript-prefix-v1'
const chapterRevisionId = (scopeKey, chapterId, units) => 'mchapter:' + payloadHash([scopeKey, chapterId, units])
const manuscriptEditionId = (scopeKey, chapters) => 'medition:' + payloadHash([scopeKey, chapters])

export function validRevision(row) {
  return populated(row.chapterId) && Array.isArray(row.units) &&
    row.units.every(unit => populated(unit?.unitId) && unitHash(unit.unitHash)) &&
    row.id === chapterRevisionId(row.scopeKey, row.chapterId, row.units)
}

export function validEdition(row) {
  return Array.isArray(row.chapters) && row.chapters.every(chapter => populated(chapter?.chapterId) &&
    populated(chapter.revisionId) && typeof chapter.title === 'string') &&
    row.id === manuscriptEditionId(row.scopeKey, row.chapters)
}

export function prepareEdition(scope, chapters) {
  const resolved = normalizeScopeRef(scope)
  if (!resolved.ok || !['book', 'session'].includes(resolved.scope.domain) || !resolved.scope.bookId || !Array.isArray(chapters)) return fail()
  const scopeKey = encodeScopeKey(resolved.scope)
  const revisions = []
  const contents = []
  for (const chapter of chapters) {
    if (!chapter || !populated(chapter.chapterId) || !Array.isArray(chapter.units) || chapter.units.some(unit => !unit || !populated(unit.unitId) || !unitHash(unit.unitHash))) return fail()
    const units = chapter.units.map(unit => ({ unitId: unit.unitId, unitHash: unit.unitHash }))
    const id = chapterRevisionId(scopeKey, chapter.chapterId, units)
    const row = { id, scopeKey, chapterId: chapter.chapterId, units }
    revisions.push(row)
    contents.push({ chapterId: chapter.chapterId, title: String(chapter.title ?? ''), revisionId: id })
  }
  return { ok: true, revisions, edition: { id: manuscriptEditionId(scopeKey, contents), scopeKey, chapters: contents } }
}

export async function storeEdition(db, prepared, { scope, seq }) {
  const editions = db.table('manuscriptEditions')
  if (await editions.get(prepared.edition.id)) return
  const chapters = db.table('manuscriptChapterRevisions')
  const revisions = [...new Map(prepared.revisions.map(row => [row.id, row])).values()]
  const found = await chapters.bulkGet(revisions.map(row => row.id))
  const missing = revisions.filter((_, index) => !found[index]).map(row => ({ ...row, scope, recordedSeq: seq }))
  if (missing.length) await chapters.bulkAdd(missing)
  await editions.add({ ...prepared.edition, scope, recordedSeq: seq })
}

export async function loadEdition(db, scopeKey, id) {
  const edition = await db.table('manuscriptEditions').get(id)
  if (!edition || edition.scopeKey !== scopeKey) return null
  const revisions = await db.table('manuscriptChapterRevisions').bulkGet(edition.chapters.map(row => row.revisionId))
  if (revisions.some((row, i) => !row || row.scopeKey !== scopeKey || row.chapterId !== edition.chapters[i].chapterId)) return null
  return { id, recordedSeq: edition.recordedSeq, chapters: edition.chapters.map((row, i) => ({
    chapterId: row.chapterId, title: row.title, units: revisions[i].units
  })) }
}

// Compute only from an archived edition supplied by the database. Repeated
// identities are ambiguous even when their text hashes happen to be equal.
export function indexEdition(chapters) {
  const byChapter = new Map()
  let prefix = editionSeed
  let position = 0
  for (const chapter of chapters) {
    prefix = editionPrefix(prefix, 'chapter', chapter.chapterId)
    const byUnit = new Map()
    byChapter.set(chapter.chapterId, byChapter.has(chapter.chapterId) ? null : byUnit)
    for (const unit of chapter.units) {
      prefix = editionPrefix(prefix, 'unit', unit.unitId)
      byUnit.set(unit.unitId, byUnit.has(unit.unitId) ? null : { unit, position, orderRevision: 'prefix-v1:' + prefix })
      position++
    }
  }
  return (chapterId, unitId) => byChapter.get(chapterId)?.get(unitId) ?? null
}

export function editionAnchor(edition, chapterId, unitId) {
  const match = indexEdition(edition.chapters)(chapterId, unitId)
  return match && { unitHash: match.unit.unitHash, orderRevision: match.orderRevision }
}

export function editionScope(scope) {
  const resolved = normalizeScopeRef(scope)
  return resolved.ok && ['book', 'session'].includes(resolved.scope.domain) && resolved.scope.bookId ? encodeScopeKey(resolved.scope) : null
}

export async function listWorldEditions(db, { scope }) {
  const scopeKey = editionScope(scope)
  if (!scopeKey) return { ok: false, reason: 'manuscript-scope-mismatch' }
  return db.transaction('r', ['manuscriptEditions', 'factDecisions'], async () => {
    const editions = await db.manuscriptEditions.where('scopeKey').equals(scopeKey).toArray()
    const items = await Promise.all(editions.map(async row => {
      const latest = await db.factDecisions.where('[scopeKey+result.manuscriptEditionId+recordedSeq]')
        .between([scopeKey, row.id, 0], [scopeKey, row.id, Number.MAX_SAFE_INTEGER], true, true).last()
      return { id: row.id, chapters: row.chapters.length, recordedSeq: latest?.recordedSeq ?? row.recordedSeq }
    }))
    return { ok: true, items: items.sort((a, b) => b.recordedSeq - a.recordedSeq) }
  })
}

export function readWorldEdition(db, { scope, editionId }) {
  const scopeKey = editionScope(scope)
  if (!scopeKey || !editionId) return null
  return db.transaction('r', ['manuscriptEditions', 'manuscriptChapterRevisions'], () => loadEdition(db, scopeKey, editionId))
}
