import { effectiveEvents } from './knowledgeReplay.js'
import { inheritedBelief } from './worldForkActor.js'
import { worldClaimText } from './worldClaimPresentation.js'
import { encodeScopeKey, worldClaimId, payloadHash } from './ledgerContract.js'
import { factForkSession } from './worldFactFork.js'
import { isVisibleAt } from './recordAxis.js'
import { stableStringify } from '../knowledgeContract.js'

export function validateWorldForks({ version, decisions, versions, evidence, claims, meta }) {
  const ids = new Map(decisions.map(row => [row.id, row]))
  const targets = new Set()
  const fail = () => { throw new Error('试写分支的来源、记录截面或继承内容无效') }
  for (const row of decisions) {
    const fork = row.result?.fork
    if (!fork && row.operation !== 'fork-world-facts') continue
    if (version < 14 || row.operation !== 'fork-world-facts' || !fork || targets.has(row.scopeKey) ||
        row.scope?.domain !== 'session' || row.scope.sessionId !== factForkSession || !row.scope.bookId ||
        fork.parentScopeKey !== encodeScopeKey({ domain: 'book', bookId: row.scope.bookId }) ||
        typeof fork.label !== 'string' || !fork.label.trim() || !Number.isSafeInteger(fork.parentRecordedSeq) ||
        fork.parentRecordedSeq < 0 || fork.parentRecordedSeq > (meta.get('seq:' + fork.parentScopeKey)?.seq ?? 0) ||
        !Array.isArray(fork.factSources) || !Array.isArray(fork.calendarSources)) fail()
    targets.add(row.scopeKey)
    const expected = new Set([...versions.values()].filter(v => v.scopeKey === fork.parentScopeKey && isVisibleAt(v, fork.parentRecordedSeq)).map(v => v.id))
    const childIds = new Set()
    for (const pair of fork.factSources) {
      const source = versions.get(pair?.from), copy = versions.get(pair?.to)
      const claim = claims.get(source?.claimId) ?? source
      if (!source || !expected.delete(source.id) || !copy || childIds.has(copy.id) || copy.scopeKey !== row.scopeKey ||
          copy.visibleFromSeq !== row.recordedSeq || copy.supersedes || !isVisibleAt(copy, row.recordedSeq) ||
          copy.factKey !== source.factKey || copy.claimId !== worldClaimId(row.scopeKey, claim) ||
          Boolean(copy.supersedesKind) !== Boolean(source.supersedesKind) ||
          stableStringify(copy.validInterval ?? null) !== stableStringify(source.validInterval ?? null) ||
          copy.authority !== source.authority || copy.origin !== source.origin || copy.evidenceIds.length !== source.evidenceIds.length) fail()
      childIds.add(copy.id)
      for (let i = 0; i < copy.evidenceIds.length; i++) {
        const a = evidence.get(source.evidenceIds[i]), b = evidence.get(copy.evidenceIds[i])
        if (!a || !b || a.scopeKey !== fork.parentScopeKey || b.scopeKey !== row.scopeKey ||
            ['sourceKind', 'sourceId', 'sourceRevision', 'contentHash', 'quote'].some(key => a[key] !== b[key])) fail()
      }
    }
    if (expected.size) fail()
    const latest = new Map()
    for (const decision of decisions) {
      if (decision.scopeKey !== fork.parentScopeKey || decision.operation !== 'define-story-calendar' ||
          !isVisibleAt(decision, fork.parentRecordedSeq)) continue
      const id = decision.result.calendar.id
      if (!latest.has(id) || latest.get(id).recordedSeq < decision.recordedSeq) latest.set(id, decision)
    }
    for (const pair of fork.calendarSources) {
      const source = ids.get(pair?.from), copy = ids.get(pair?.to), calendar = source?.result?.calendar
      if (!calendar || latest.get(calendar.id)?.id !== source.id || !copy || copy.scopeKey !== row.scopeKey ||
          copy.visibleFromSeq !== row.recordedSeq || copy.operation !== 'define-story-calendar' ||
          stableStringify(calendar) !== stableStringify(copy.result?.calendar)) fail()
      latest.delete(calendar.id)
    }
    if (latest.size) fail()
  }
}

export function validateForkAdoptions({ version, decisions, versions, evidence, meta }) {
  const origins = new Map(decisions.filter(row => row.operation === 'fork-world-facts').map(row => [row.id, row]))
  const consumed = new Set()
  for (const decision of decisions) {
    const ref = decision.result?.adoptedFromFork
    if (!ref && decision.operation !== 'adopt-fork-fact') continue
    const origin = origins.get(ref?.forkId), source = versions.get(ref?.factVersionId)
    const target = versions.get(decision.result?.factVersionId), snapshot = evidence.get(ref?.evidenceId)
    if (version < 16 || decision.operation !== 'adopt-fork-fact' || !origin || !source || !target || !snapshot ||
        origin.result.fork.parentScopeKey !== decision.scopeKey || source.scopeKey !== origin.scopeKey || source.supersedesKind ||
        !Number.isSafeInteger(ref.recordedSeq) || ref.recordedSeq > (meta.get('seq:' + source.scopeKey)?.seq ?? 0) ||
        !isVisibleAt(source, ref.recordedSeq) || !isVisibleAt(target, decision.recordedSeq) || target.scopeKey !== decision.scopeKey ||
        target.claimId !== worldClaimId(decision.scopeKey, source) || !target.evidenceIds.includes(snapshot.id) ||
        snapshot.scopeKey !== decision.scopeKey || snapshot.sourceKind !== 'fork-fact' || consumed.has(snapshot.id)) throw new Error('试写分支采纳来源无效')
    const expected = { sourceKind: 'fork-fact', sourceId: JSON.stringify([source.scopeKey, source.id]), sourceRevision: source.id, quote: worldClaimText(source) }
    if (Object.keys(expected).some(key => snapshot[key] !== expected[key]) || snapshot.contentHash !== payloadHash(expected)) throw new Error('试写分支采纳证据不符')
    consumed.add(snapshot.id)
  }
  // A subsequent fork can inherit the canonical evidence. Its correspondence
  // to the source was checked with every other evidence pair in validateWorldForks.
  for (const origin of origins.values()) {
    for (const pair of origin.result.fork.factSources) {
      for (const id of versions.get(pair.to).evidenceIds) consumed.add(id)
    }
  }
  if ([...evidence.values()].some(row => row.sourceKind === 'fork-fact' && !consumed.has(row.id))) throw new Error('分支证据缺少采纳决定')
}

export function validateForkActors({ version, decisions, events, claims, evidence, versions }) {
  const origins = new Map(decisions.filter(row => row.operation === 'fork-world-facts').map(row => [row.id, row]))
  const inherited = new Set()
  const actors = new Set()
  const fail = () => { throw new Error('分支人物经历与分叉点的原记录不符') }
  for (const decision of decisions) {
    const ref = decision.result?.inheritedActor
    if (!ref && decision.operation !== 'inherit-fork-actor') continue
    const origin = origins.get(ref?.forkId)
    if (version < 17 || decision.operation !== 'inherit-fork-actor' || !origin || origin.scopeKey !== decision.scopeKey ||
        !ref.actorKey || !Array.isArray(ref.sources) || !ref.sources.length || origin.recordedSeq >= decision.recordedSeq) fail()
    const actor = JSON.stringify([decision.scopeKey, ref.actorKey])
    if (actors.has(actor)) fail()
    actors.add(actor)
    const fork = origin.result.fork
    const originals = effectiveEvents([...events.values()].filter(row => row.scopeKey === fork.parentScopeKey && row.actorKey === ref.actorKey), fork.parentRecordedSeq)
    const copiedVersions = new Map(fork.factSources.map(pair => [pair.from, pair.to]))
    const firstSeq = decision.recordedSeq - originals.length + 1
    if (ref.sources.length !== originals.length || firstSeq <= origin.recordedSeq ||
        [...events.values()].some(row => row.scopeKey === origin.scopeKey && row.actorKey === ref.actorKey && row.recordedSeq < firstSeq)) fail()
    for (let i = 0; i < originals.length; i++) {
      const original = originals[i], pair = ref.sources[i], copy = events.get(pair?.to)
      const claim = claims.get(original.claimId), versionId = copiedVersions.get(original.factVersionId) ?? null
      if (!copy || !claim || pair.from !== original.id || inherited.has(copy.id) || copy.scopeKey !== origin.scopeKey ||
          copy.actorKey !== ref.actorKey || copy.actorLabel !== (original.actorLabel || '') || copy.supersedesEventId ||
          copy.recordedSeq !== decision.recordedSeq - originals.length + 1 + i || copy.visibleFromSeq !== decision.recordedSeq ||
          copy.claimId !== worldClaimId(origin.scopeKey, claim) || copy.factVersionId !== versionId || copy.factKey !== (versions.get(versionId)?.factKey ?? null) ||
          copy.kind !== original.kind || copy.channel !== original.channel || copy.schemaVersion !== (original.schemaVersion ?? 1) ||
          copy.belief !== inheritedBelief(original, versionId) || copy.storyAt !== (original.storyAt ?? null) ||
          copy.sourceRef !== (original.sourceRef ?? null) || stableStringify(copy.storyClock ?? null) !== stableStringify(original.storyClock ?? null) ||
          stableStringify(copy.speaker ?? null) !== stableStringify(original.speaker ?? null) ||
          stableStringify(copy.passage?.manuscriptAnchor ?? null) !== stableStringify(original.passage?.manuscriptAnchor ?? null) ||
          evidence.get(copy.passage?.evidenceId)?.quote !== evidence.get(original.passage?.evidenceId)?.quote) fail()
      inherited.add(copy.id)
    }
  }
  for (const row of events.values()) if (row.visibleFromSeq != null && !inherited.has(row.id)) fail()
}
