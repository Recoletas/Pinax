// Keep the qualifier ahead of the assertion even in truncated history excerpts.
export function worldClaimText(row, translate = value => value) {
  return [row.polarity === 'negative' ? translate('否定') : '', row.subjectLabel || row.subjectKey, row.predicate,
    row.literalValue?.type === 'number' ? translate('数值') : row.literalValue?.type === 'boolean' ? translate('布尔值') : '',
    row.object].filter(Boolean).join(' · ')
}

export function worldClaimQualifiers(row) {
  return { ...(row.polarity === 'negative' ? { polarity: 'negative' } : {}),
    ...(row.literalValue ? { literalValue: row.literalValue } : {}) }
}
