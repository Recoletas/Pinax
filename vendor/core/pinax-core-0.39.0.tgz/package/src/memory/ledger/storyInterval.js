// A bounded query compares fictional era order and discrete ordinals.
// The recording date never supplies a missing story boundary.
import { toTimePoint, validateTimeline, resolveEraOrder } from '../knowledgeTime.js'

// storyAt: { timelineId, eraId, ordinal, precision } — validated against the
// caller-declared timeline (eras with explicit orders). Returns:
// - { ok, match: 'inside' | 'outside' }   decisive answer
// - { ok, match: 'unknown', reason }      unknown/undeclared/mismatched time —
//                                         never silently treated as inside
// - { ok: false, reason }                 malformed request
export function storyTimeMatch(interval, storyAt, timeline) {
  if (storyAt === null || storyAt === undefined) return { ok: true, match: null }
  const uncertain = reason => ({ ok: true, match: 'unknown', reason })
  const answer = inside => ({ ok: true, match: inside ? 'inside' : 'outside' })
  const declaration = validateTimeline(timeline)
  if (!declaration.ok) return uncertain(declaration.error)
  const point = toTimePoint(storyAt, timeline)
  if (!point.ok) return uncertain(point.error)
  if (!interval) return uncertain('fact-time-unevidenced')
  if (interval.timelineId !== storyAt.timelineId) return uncertain('timeline-mismatch')
  const { eraOrder, ordinal, precision } = point.point
  const wholeEra = precision === 'era'
  if (!wholeEra && (!['year', 'moment'].includes(precision) || !Number.isSafeInteger(ordinal))) return uncertain('story-ordinal-unknown')
  const first = { eraOrder, ordinal: wholeEra ? Number.MIN_SAFE_INTEGER : ordinal }
  const last = { eraOrder, ordinal: wholeEra ? Number.MAX_SAFE_INTEGER : ordinal }
  function limits(boundary) {
    if (!boundary) return null
    const order = resolveEraOrder(timeline, boundary.eraId)
    if (order === null || (boundary.ordinal != null && !Number.isSafeInteger(boundary.ordinal))) return null
    return {
      first: { eraOrder: order, ordinal: boundary.ordinal ?? Number.MIN_SAFE_INTEGER },
      last: { eraOrder: order, ordinal: boundary.ordinal ?? Number.MAX_SAFE_INTEGER }
    }
  }
  const start = limits(interval.start)
  const end = limits(interval.end)
  if ((interval.start && !start) || (interval.end && !end)) return uncertain('timeline-era-invalid')
  if (!['exclusive', 'unknown', 'open'].includes(interval.endSemantic) ||
      (interval.endSemantic === 'exclusive') !== Boolean(end) ||
      (start && end && compare(start.first, end.last) >= 0)) return uncertain('story-interval-invalid')
  if (start && compare(start.first, last) > 0) return answer(false)
  if (end && compare(end.last, first) <= 0) return answer(false)
  // Every possible start lies within the query, even if the end is lost.
  if (start && compare(start.first, first) >= 0 && compare(start.last, last) <= 0) return answer(true)
  // A known exclusive end inside the query guarantees the preceding instant.
  if (end && compare(end.first, first) > 0 && compare(end.last, last) <= 0) return answer(true)
  if (start && compare(start.last, last) <= 0 &&
      (interval.endSemantic === 'open' || (end && compare(end.first, first) > 0))) return answer(true)
  return uncertain(start ? 'interval-end-unknown' : 'interval-start-unknown')
}

function compare(a, b) {
  return a.eraOrder === b.eraOrder ? Math.sign(a.ordinal - b.ordinal) : Math.sign(a.eraOrder - b.eraOrder)
}

// UI-facing description; never renders an unknown interval as definite.
// M11 文案合同（先判 unknown）：「未知日期不是开放终点」（0022）——
// endSemantic 'unknown' 且无端点时必须报「终点未知」，不得落进「此后仍成立」。
export function describeInterval(interval) {
  if (!interval) return '故事时间未知'
  const parts = []
  parts.push(interval.start ? `自 ${interval.start.eraId}${interval.start.ordinal !== null ? ` 第 ${interval.start.ordinal} 年` : ''}` : '开始未知')
  if (interval.endSemantic === 'unknown') parts.push('终点未知')
  else if (interval.endSemantic === 'open' || !interval.end) parts.push('此后仍成立（无记录终点）')
  else parts.push(`至 ${interval.end.eraId}${interval.end.ordinal !== null ? ` 第 ${interval.end.ordinal} 年前` : ''}`)
  return parts.join('，')
}
