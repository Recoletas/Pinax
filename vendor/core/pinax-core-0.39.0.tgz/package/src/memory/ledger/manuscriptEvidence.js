import { payloadHash } from './ledgerContract.js'
import { sha256HexOfText } from '../../domain/contentHash.js'

const anchorFields = ['bookId', 'chapterId', 'unitId', 'unitHash', 'orderRevision']
export const validAnchor = anchor => anchorFields.every(key => typeof anchor?.[key] === 'string' && anchor[key].trim())

export function validQuotedAnchor(anchor, quote) {
  return validAnchor(anchor) && typeof quote === 'string' && quote.trim().length > 0 && anchor.unitHash === sha256HexOfText(quote)
}

export async function recordPassageEvidence(table, { scope, scopeKey, manuscriptAnchor, quote, ledgerId }) {
  const sourceId = JSON.stringify([manuscriptAnchor.bookId, manuscriptAnchor.chapterId, manuscriptAnchor.unitId])
  const sourceRevision = manuscriptAnchor.unitHash
  const contentHash = payloadHash({ sourceKind: 'chapter-quote', sourceId, sourceRevision, quote })
  const evidenceRows = await table.where('[scopeKey+sourceId]').equals([scopeKey, sourceId]).toArray()
  let evidence = evidenceRows.find(row => row.contentHash === contentHash && !row.tombstoneAt)
  if (!evidence) {
    evidence = { id: ledgerId('ev'), scope, scopeKey, sourceKind: 'chapter-quote', sourceId, sourceRevision,
      quote, contentHash, recordedAt: Date.now(), tombstoneAt: null }
    await table.add(evidence)
  }
  return evidence
}
