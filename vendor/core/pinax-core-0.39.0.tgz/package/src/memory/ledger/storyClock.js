export const defaultStoryClock = Object.freeze({ timelineId: 'default', eraId: 'default' })
export const defaultCalendar = Object.freeze({ id: 'default', label: '默认时间线', eras: Object.freeze([Object.freeze({ id: 'default', label: '默认纪元', order: 0 })]) })
const text = value => typeof value === 'string' ? value.trim() : ''

export function normalizeStoryClock(clock) {
  if (clock == null) return defaultStoryClock
  const timelineId = text(clock.timelineId)
  const eraId = text(clock.eraId)
  return timelineId && eraId && (timelineId !== 'default' || eraId === 'default') ? { timelineId, eraId } : null
}
