import { normalizeScopeRef, encodeScopeKey } from './ledgerContract.js'
import { ensureWorldClaim, normalizeWorldClaim } from './worldClaims.js'
import { recordPassageEvidence, validQuotedAnchor } from './manuscriptEvidence.js'
import { effectiveEvents } from './knowledgeReplay.js'
import { factForkSession } from './worldFactFork.js'
import { loadCalendarAt } from './worldCalendars.js'

const fail = reason => ({ ok: false, reason })
// Old knowledge may be grounded in a fact that ceased to be canonical before
// the fork. Retain the exact proposition without creating a formal child fact.
export function inheritedBelief(event, targetVersionId) {
  return (event.schemaVersion ?? 1) === 1 && event.kind === 'known' && event.factVersionId && !targetVersionId
    ? event.belief ?? 'active' : event.belief ?? null
}

export function inheritForkActor(db, input, { runCommand, ledgerId }) {
  const child = normalizeScopeRef(input?.scope)
  if (!child.ok || child.scope.domain !== 'session' || child.scope.sessionId !== factForkSession || !child.scope.bookId) return fail('fork-scope-invalid')
  const actorKey = typeof input.actorKey === 'string' && input.actorKey.trim()
  if (!actorKey) return fail('actor-key-required')
  return runCommand(db, child.scope, input.commandId, { action: 'inherit-fork-actor', actorKey }, async ({ tables, scope, scopeKey, seq }) => {
    const origin = await tables.decisions.where('[scopeKey+operation+recordedSeq]')
      .between([scopeKey, 'fork-world-facts', 0], [scopeKey, 'fork-world-facts', Number.MAX_SAFE_INTEGER], true, true).first()
    const fork = origin?.result?.fork
    if (fork?.parentScopeKey !== encodeScopeKey({ domain: 'book', bookId: scope.bookId })) return fail('fork-scope-invalid')
    const events = db.table('knowledgeEvents')
    if (await events.where('[scopeKey+actorKey]').equals([scopeKey, actorKey]).first()) return fail('fork-actor-used')
    const old = await events.where('[scopeKey+actorKey+recordedSeq]').between(
      [fork.parentScopeKey, actorKey, 0], [fork.parentScopeKey, actorKey, fork.parentRecordedSeq], true, true).toArray()
    const selected = effectiveEvents(old, fork.parentRecordedSeq)
    if (!selected.length) return fail('fork-actor-empty')
    const commitSeq = seq + selected.length - 1
    const versionMap = new Map(fork.factSources.map(pair => [pair.from, pair.to]))
    const sources = []
    const checked = new Set()
    for (const event of selected) {
      const clock = event.storyClock?.timelineId
      if (clock && !checked.has(clock)) {
        const original = await loadCalendarAt(db, fork.parentScopeKey, clock, fork.parentRecordedSeq)
        const local = await loadCalendarAt(db, scopeKey, clock)
        const order = cal => cal?.eras.map(era => [era.id, era.order])
        if (!original || !local || JSON.stringify(order(original)) !== JSON.stringify(order(local))) return fail('fork-calendar-mismatch')
        checked.add(clock)
      }
      const original = await tables.claims.get(event.claimId)
      if (original?.scopeKey !== fork.parentScopeKey || original.recordedSeq > fork.parentRecordedSeq) return fail('fork-source-incomplete')
      const normalized = normalizeWorldClaim(original, original.occurrenceId)
      if (!normalized.ok) return fail(normalized.reason)
      const claimId = await ensureWorldClaim(tables.claims, { scope, scopeKey, seq: commitSeq }, normalized.claim)
      const factVersionId = versionMap.get(event.factVersionId) ?? null
      const fact = factVersionId && await tables.versions.get(factVersionId)
      const id = ledgerId('kn')
      const copy = { id, scope, scopeKey, actorKey, actorLabel: event.actorLabel || '', kind: event.kind, channel: event.channel,
        schemaVersion: event.schemaVersion ?? 1, factVersionId, factKey: fact?.factKey ?? null, claimId,
        storyAt: event.storyAt ?? null, belief: inheritedBelief(event, factVersionId), sourceRef: event.sourceRef ?? null,
        ...(event.storyClock ? { storyClock: event.storyClock } : {}), ...(event.speaker ? { speaker: event.speaker } : {}),
        recordedAt: Date.now(), recordedSeq: seq + sources.length, visibleFromSeq: commitSeq }
      if (event.passage) {
        const evidence = await tables.evidence.get(event.passage.evidenceId)
        const manuscriptAnchor = event.passage.manuscriptAnchor
        if (evidence?.scopeKey !== fork.parentScopeKey || !validQuotedAnchor(manuscriptAnchor, evidence.quote)) return fail('fork-source-incomplete')
        const frozen = await recordPassageEvidence(tables.evidence, { scope, scopeKey, manuscriptAnchor, quote: evidence.quote, ledgerId })
        copy.passage = { manuscriptAnchor, evidenceId: frozen.id }
      }
      await events.add(copy)
      sources.push({ from: event.id, to: id })
    }
    await tables.meta.put({ id: 'seq:' + scopeKey, seq: commitSeq })
    return { operation: 'inherit-fork-actor', commitSeq, result: { inheritedActor: { forkId: origin.id, actorKey, sources } } }
  })
}
