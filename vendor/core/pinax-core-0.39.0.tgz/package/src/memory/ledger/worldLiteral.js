// The canonical display string keeps older projections readable. The typed
// operand owns identity even when free text has exactly the same spelling.
export function normalizeWorldLiteral(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null
  if (Object.keys(input).some(key => !['type', 'value', 'unit'].includes(key))) return null
  if (input.type === 'boolean') return typeof input.value === 'boolean' && input.unit === undefined
    ? { type: 'boolean', value: input.value } : null
  if (input.type !== 'number' || !Number.isFinite(input.value) || Math.abs(input.value) > Number.MAX_SAFE_INTEGER ||
      (input.unit !== undefined && typeof input.unit !== 'string')) return null
  const unit = input.unit?.trim()
  return { type: 'number', value: input.value === 0 ? 0 : input.value, ...(unit ? { unit } : {}) }
}

export function worldLiteralText(literal) {
  if (literal.type === 'boolean') return literal.value ? '是' : '否'
  return [String(literal.value), literal.unit].filter(Boolean).join(' ')
}
