import { normalizeScopeRef, encodeScopeKey, payloadHash, worldClaimId } from './ledgerContract.js'
import { currentHeadOf, isVisibleAt } from './recordAxis.js'
import { normalizeWorldClaim } from './worldClaims.js'
import { worldClaimText } from './worldClaimPresentation.js'
import { compareWorldVersions } from './worldForkComparison.js'
import { passageUnitOf, recordPassageEvidence } from './manuscriptEvidence.js'
import { factForkSession } from './worldFactFork.js'
import { loadCalendarAt } from './worldCalendars.js'

const fail = reason => ({ ok: false, reason })
const eraOrder = calendar => calendar?.eras.map(era => [era.id, era.order])

// The caller selects a specific visible branch version. A single author
// decision creates the source evidence and co-ordinates the book mutation.
export function adoptForkVersion(db, input, { runCommand, ledgerId, correctInTransaction, createProposal, adoptInTransaction }) {
  const child = normalizeScopeRef(input?.scope)
  if (!child.ok || child.scope.domain !== 'session' || child.scope.sessionId !== factForkSession || !child.scope.bookId) return fail('fork-scope-invalid')
  if (typeof input.factVersionId !== 'string' || !input.factVersionId) return fail('fact-version-changed')
  const childKey = encodeScopeKey(child.scope)
  const parent = { domain: 'book', bookId: child.scope.bookId }
  const payload = { operation: 'adopt-fork-fact', childKey, factVersionId: input.factVersionId }
  return runCommand(db, parent, input.commandId, payload, async context => {
    const { tables, scopeKey, scope } = context
    const origin = await tables.decisions.where('[scopeKey+operation+recordedSeq]')
      .between([childKey, 'fork-world-facts', 0], [childKey, 'fork-world-facts', Number.MAX_SAFE_INTEGER], true, true).first()
    const fork = origin?.result?.fork
    if (fork?.parentScopeKey !== scopeKey) return fail('fork-scope-invalid')
    const candidate = await tables.versions.get(input.factVersionId)
    if (candidate?.scopeKey !== childKey || candidate.supersedesKind || !isVisibleAt(candidate)) return fail('fact-version-changed')
    if (fork.factSources.some(pair => pair.to === candidate.id)) return fail('no-change')
    const chain = await tables.versions.where('[scopeKey+factKey]').equals([scopeKey, candidate.factKey]).toArray()
    if (chain.some(row => (row.visibleFromSeq ?? row.recordedSeq) > fork.parentRecordedSeq || row.invalidatedSeq > fork.parentRecordedSeq)) return fail('fork-parent-changed')
    const head = currentHeadOf(chain.filter(row => !row.supersedesKind))
    if (head && !compareWorldVersions([head], [candidate]).length) return fail('no-change')
    const interval = candidate.validInterval
    const timeline = interval && await loadCalendarAt(db, scopeKey, interval.timelineId)
    if (interval) {
      const local = await loadCalendarAt(db, childKey, interval.timelineId)
      if (!timeline || !local || JSON.stringify(eraOrder(timeline)) !== JSON.stringify(eraOrder(local))) return fail('fork-calendar-mismatch')
    }
    const normalized = normalizeWorldClaim(candidate, candidate.occurrenceId)
    if (!normalized.ok) return fail(normalized.reason)
    const claim = normalized.claim
    const id = ledgerId('ev')
    const source = { sourceKind: 'fork-fact', sourceId: JSON.stringify([childKey, candidate.id]), sourceRevision: candidate.id, quote: worldClaimText(candidate) }
    await tables.evidence.add({ ...source, id, scope, scopeKey, contentHash: payloadHash(source), recordedAt: Date.now(), tombstoneAt: null })
    const chapterEvidence = []
    for (const proof of await tables.evidence.bulkGet(candidate.evidenceIds)) {
      if (proof?.scopeKey !== childKey) return fail('fork-source-incomplete')
      const unit = passageUnitOf(proof, scope.bookId)
      if (!unit) continue
      const copy = await recordPassageEvidence(tables.evidence, { scope, scopeKey, manuscriptAnchor: unit, quote: proof.quote, ledgerId })
      chapterEvidence.push({ from: proof.id, to: copy.id })
    }
    const evidenceIds = [id, ...chapterEvidence.map(pair => pair.to)]
    const actorRef = 'world-fork'
    let outcome
    const baselineId = head && fork.factSources.find(pair => pair.from === head.id)?.to
    let keepsPriorPeriod = false
    if (baselineId && ['state', 'relation'].includes(claim.kind)) {
      const history = await tables.versions.where('[scopeKey+factKey]').equals([childKey, candidate.factKey]).toArray()
      const byId = new Map(history.map(row => [row.id, row]))
      keepsPriorPeriod = history.some(row => {
        if (!row.supersedesKind || !isVisibleAt(row)) return false
        let ancestor = byId.get(row.supersedes)
        while (ancestor && ancestor.recordedSeq < row.recordedSeq) {
          if (ancestor.id === baselineId) return true
          row = ancestor
          ancestor = byId.get(row.supersedes)
        }
        return false
      })
    }
    if (head && !keepsPriorPeriod) {
      outcome = await correctInTransaction(db, { scope, factKey: candidate.factKey, object: claim.object, literalValue: claim.literalValue ?? null,
        objectRef: claim.objectRef ?? null, eventContext: claim.eventContext ?? null, eventLabels: claim.eventLabels ?? [],
        expectedHead: head.id, storyInterval: interval ?? { precision: 'unknown' }, evidenceIds, actorRef, reason: '' }, context)
    } else {
      const proposal = await createProposal(db, { ...claim, scope, timeline, origin: 'author', evidenceIds, storyInterval: interval })
      if (!proposal.ok) return proposal
      if (proposal.suppressed) return fail('rejection-active')
      outcome = await adoptInTransaction(context, { proposalId: proposal.proposal.id, object: null, storyInterval: interval ?? null,
        evidenceIds: [], expectedHead: null, actorRef })
    }
    if (outcome.ok === false) return outcome
    if (outcome.result.claimId !== worldClaimId(scopeKey, claim)) return fail('claim-identity-changed')
    const sourceSeq = (await tables.meta.get('seq:' + childKey)).seq
    return { ...outcome, operation: payload.operation, result: { ...outcome.result,
      adoptedFromFork: { forkId: origin.id, factVersionId: candidate.id, recordedSeq: sourceSeq, evidenceId: id, chapterEvidence } } }
  })
}
