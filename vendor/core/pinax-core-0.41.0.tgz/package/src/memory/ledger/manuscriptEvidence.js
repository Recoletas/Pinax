import { payloadHash } from './ledgerContract.js'
import { sha256HexOfText } from '../../domain/contentHash.js'

const anchorFields = ['bookId', 'chapterId', 'unitId', 'unitHash', 'orderRevision']
export const validAnchor = anchor => anchorFields.every(key => typeof anchor?.[key] === 'string' && anchor[key].trim())

export function validQuotedAnchor(anchor, quote) {
  return validAnchor(anchor) && typeof quote === 'string' && quote.trim().length > 0 && anchor.unitHash === sha256HexOfText(quote)
}

export async function recordPassageEvidence(table, { scope, scopeKey, manuscriptAnchor, quote, ledgerId }) {
  const sourceId = JSON.stringify([manuscriptAnchor.bookId, manuscriptAnchor.chapterId, manuscriptAnchor.unitId])
  const sourceRevision = manuscriptAnchor.unitHash
  const contentHash = payloadHash({ sourceKind: 'chapter-quote', sourceId, sourceRevision, quote })
  const evidenceRows = await table.where('[scopeKey+sourceId]').equals([scopeKey, sourceId]).toArray()
  let evidence = evidenceRows.find(row => row.contentHash === contentHash && !row.tombstoneAt)
  if (!evidence) {
    evidence = { id: ledgerId('ev'), scope, scopeKey, sourceKind: 'chapter-quote', sourceId, sourceRevision,
      quote, contentHash, recordedAt: Date.now(), tombstoneAt: null }
    await table.add(evidence)
  }
  return evidence
}

// Early chapter evidence used free-form source IDs. Only an exact, verified
// unit reference can navigate to a paragraph on behalf of the author.
export function passageUnitOf(evidence, bookId) {
  if (evidence?.sourceKind !== 'chapter-quote' || typeof evidence.sourceId !== 'string' || !evidence.sourceId.startsWith('[')) return null
  let parts
  try { parts = JSON.parse(evidence.sourceId) } catch { return null }
  if (!Array.isArray(parts) || parts.length !== 3 || parts[0] !== bookId || !parts.every(id => typeof id === 'string' && id.trim()) ||
      typeof evidence.quote !== 'string' || evidence.sourceRevision !== sha256HexOfText(evidence.quote)) return null
  return { bookId, chapterId: parts[1], unitId: parts[2], unitHash: evidence.sourceRevision }
}
