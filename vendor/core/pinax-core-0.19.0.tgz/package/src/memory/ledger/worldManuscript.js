import { encodeScopeKey, normalizeScopeRef, payloadHash } from './ledgerContract.js'
import { isVisibleAt } from './recordAxis.js'
import { sha256HexOfText } from '../../domain/contentHash.js'

const disclosureKinds = ['narrator-assertion', 'reported-speech']
const useKinds = ['assertion-use', 'belief-use', 'constraint-use']
const requiresFact = kind => ['narrator-assertion', 'assertion-use'].includes(kind)
const unknown = () => ({ ok: true, status: 'unknown', items: [] })
const fail = reason => ({ ok: false, reason, items: [] })
const anchorFields = ['bookId', 'chapterId', 'unitId', 'unitHash', 'orderRevision']
const validAnchor = anchor => anchorFields.every(key => typeof anchor?.[key] === 'string' && anchor[key].trim())
const atUnit = (a, b) => a.bookId === b.bookId && a.chapterId === b.chapterId && a.unitId === b.unitId

function scopeForBook(input, bookId) {
  const resolved = normalizeScopeRef(input)
  if (!resolved.ok || !['book', 'session'].includes(resolved.scope.domain) || resolved.scope.bookId !== bookId) return fail('manuscript-scope-mismatch')
  return { ...resolved, scopeKey: encodeScopeKey(resolved.scope) }
}

export function createWorldManuscriptModule({ ledgerId, runWorldCommand }) {
  async function recordManuscriptLink(db, input) {
    const { scope, commandId, claimId, kind, manuscriptAnchor, quote, useId = null } = input
    if (!validAnchor(manuscriptAnchor) || typeof quote !== 'string' || !quote.trim() ||
        manuscriptAnchor.unitHash !== sha256HexOfText(quote)) return fail('manuscript-anchor-invalid')
    const resolved = scopeForBook(scope, manuscriptAnchor.bookId)
    if (!resolved.ok) return resolved
    const disclosure = disclosureKinds.includes(kind)
    if (!disclosure && !useKinds.includes(kind)) return fail('manuscript-link-kind-invalid')
    if (useId && disclosure) return fail('manuscript-use-invalid')
    const expectedVersionId = input.factVersionId || null
    if (requiresFact(kind) && !expectedVersionId) return fail('confirmed-fact-required')
    const payload = { action: 'record-manuscript-link', claimId, kind, expectedVersionId, manuscriptAnchor, useId }
    return runWorldCommand(db, resolved.scope, commandId, payload, async ({ tables, scope, scopeKey, seq }) => {
      const claim = await tables.claims.get(claimId)
      if (!claim || claim.scopeKey !== scopeKey) return fail('claim-scope-mismatch')
      if (expectedVersionId) {
        const version = await tables.versions.get(expectedVersionId)
        if (version?.scopeKey !== scopeKey || version.claimId !== claimId || !isVisibleAt(version) || version.supersedesKind) return fail('fact-version-changed')
      }
      const table = db.table(disclosure ? 'disclosures' : 'claimUses')
      const { chapterId, unitId } = manuscriptAnchor
      const previous = useId && await table.get(useId)
      if (useId && (!previous || previous.scopeKey !== scopeKey || !atUnit(previous.manuscriptAnchor, manuscriptAnchor) || !isVisibleAt(previous))) return fail('manuscript-use-changed')
      const existing = await table.where('[scopeKey+chapterId]').equals([scopeKey, chapterId]).toArray()
      const matching = existing.filter(row => isVisibleAt(row) && row.kind === kind && row.claimId === claimId && row.manuscriptAnchor.unitId === unitId)
      const same = matching.find(row => row.manuscriptAnchor.unitHash === manuscriptAnchor.unitHash &&
        row.manuscriptAnchor.orderRevision === manuscriptAnchor.orderRevision && row.expectedVersionId === expectedVersionId)
      const beforeIds = [...new Set([...matching.map(row => row.id), ...(previous ? [previous.id] : [])])].filter(id => id !== same?.id)
      for (const id of beforeIds) await table.update(id, { invalidatedSeq: seq })
      let linkId = same?.id
      if (!linkId) {
        const sourceId = JSON.stringify([manuscriptAnchor.bookId, chapterId, unitId])
        const sourceRevision = manuscriptAnchor.unitHash
        const contentHash = payloadHash({ sourceKind: 'chapter-quote', sourceId, sourceRevision, quote })
        const evidenceRows = await tables.evidence.where('[scopeKey+sourceId]').equals([scopeKey, sourceId]).toArray()
        let evidence = evidenceRows.find(row => row.contentHash === contentHash && !row.tombstoneAt)
        if (!evidence) {
          evidence = { id: ledgerId('ev'), scope, scopeKey, sourceKind: 'chapter-quote', sourceId, sourceRevision,
            quote, contentHash, recordedAt: Date.now(), tombstoneAt: null }
          await tables.evidence.add(evidence)
        }
        linkId = ledgerId(disclosure ? 'disclosure' : 'use')
        await table.add({ id: linkId, scopeKey, scope, claimId, expectedVersionId, kind, chapterId,
          manuscriptAnchor, evidenceIds: [evidence.id], recordedSeq: seq, invalidatedSeq: null })
      }
      return { operation: useId ? 'review-manuscript-use' : 'record-' + kind, beforeIds, afterIds: [linkId], result: { linkId } }
    })
  }

  async function queryManuscript(db, { scope, bookId, chapterId, unitId, recordedSeq = null, positionOf }, reader) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    if (recordedSeq !== null && (!Number.isSafeInteger(recordedSeq) || recordedSeq < 0)) return fail('recorded-as-of-invalid')
    const table = db.table(reader ? 'disclosures' : 'claimUses')
    const { scopeKey } = resolved
    return db.transaction('r', [table, db.table('worldClaims'), db.table('factVersions')], async () => {
      const rows = reader ? await table.where('scopeKey').equals(scopeKey).toArray()
        : await table.where('[scopeKey+chapterId]').equals([scopeKey, chapterId]).toArray()
      const items = []
      for (const row of rows.sort((a, b) => a.recordedSeq - b.recordedSeq)) {
        if (!isVisibleAt(row, recordedSeq)) continue
        if (!reader && row.manuscriptAnchor.unitId !== unitId) continue
        const position = positionOf(row.manuscriptAnchor)
        if (reader && position === 'after-target') continue
        if (reader && !['before-target', 'at-target'].includes(position)) return unknown()
        const claim = await db.table('worldClaims').get(row.claimId)
        if (claim?.scopeKey !== scopeKey || (recordedSeq !== null && claim.recordedSeq > recordedSeq)) return unknown()
        const item = { id: row.id, subjectLabel: claim.subjectLabel, subjectKey: claim.subjectKey, predicate: claim.predicate, object: claim.object,
          ...(claim.eventContext ? { eventContext: claim.eventContext, eventLabels: claim.eventLabels } : {}) }
        if (reader) {
          items.push({ ...item, disclosureKind: row.kind })
        } else {
          const version = row.expectedVersionId && await db.table('factVersions').get(row.expectedVersionId)
          const staleFact = row.kind !== 'belief-use' && row.expectedVersionId && (!version || !isVisibleAt(version, recordedSeq))
          items.push({ ...item, kind: row.kind, claimId: row.claimId, needsReview: position !== 'at-target' || Boolean(staleFact) })
        }
      }
      return { ok: true, status: 'ok', items }
    })
  }
  async function listAnchorIssues(db, { scope, bookId, matches }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    return db.transaction('r', ['worldClaims', 'disclosures', 'claimUses', 'evidenceSnapshots'], async () => {
      const items = []
      for (const table of ['disclosures', 'claimUses']) {
        const rows = await db.table(table).where('scopeKey').equals(resolved.scopeKey).toArray()
        for (const row of rows) {
          if (!isVisibleAt(row) || matches(row.manuscriptAnchor)) continue
          const claim = await db.table('worldClaims').get(row.claimId)
          const evidence = await db.table('evidenceSnapshots').get(row.evidenceIds[0])
          if (claim?.scopeKey === resolved.scopeKey) items.push({ id: row.id, kind: row.kind, chapterId: row.chapterId,
            unitId: row.manuscriptAnchor.unitId, quote: evidence?.scopeKey === resolved.scopeKey ? evidence.quote : '',
            subjectLabel: claim.subjectLabel, subjectKey: claim.subjectKey, predicate: claim.predicate, object: claim.object,
          ...(claim.eventContext ? { eventContext: claim.eventContext, eventLabels: claim.eventLabels } : {}) })
        }
      }
      return { ok: true, items }
    })
  }

  async function archiveAnchor(db, { scope, bookId, linkId, kind, commandId, matches }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    if (![...disclosureKinds, ...useKinds].includes(kind)) return fail('manuscript-link-kind-invalid')
    return runWorldCommand(db, resolved.scope, commandId, { action: 'archive-world-anchor', kind, linkId }, async ({ seq, scopeKey }) => {
      const table = db.table(disclosureKinds.includes(kind) ? 'disclosures' : 'claimUses')
      const row = await table.get(linkId)
      if (!row || row.kind !== kind || row.scopeKey !== scopeKey || !isVisibleAt(row) || matches(row.manuscriptAnchor)) return fail('manuscript-link-changed')
      await table.update(linkId, { invalidatedSeq: seq })
      return { operation: 'archive-world-anchor', beforeIds: [linkId], result: { linkId } }
    })
  }

  async function previewFactChange(db, { scope, bookId, factVersionId, matches }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    const { scopeKey } = resolved
    return db.transaction('r', ['factVersions', 'claimUses', 'evidenceSnapshots'], async () => {
      const version = await db.table('factVersions').get(factVersionId)
      if (version?.scopeKey !== scopeKey || !isVisibleAt(version) || version.supersedesKind) return fail('fact-version-changed')
      const uses = await db.table('claimUses').where('[scopeKey+expectedVersionId]').equals([scopeKey, factVersionId]).toArray()
      const items = []
      for (const row of uses) {
        if (!isVisibleAt(row) || row.kind === 'belief-use') continue
        const evidence = await db.table('evidenceSnapshots').get(row.evidenceIds[0])
        items.push({ id: row.id, kind: row.kind, chapterId: row.chapterId, unitId: row.manuscriptAnchor.unitId,
          quote: evidence?.scopeKey === scopeKey ? evidence.quote : '', needsReview: !matches(row.manuscriptAnchor) })
      }
      return { ok: true, items }
    })
  }
  return { recordManuscriptLink, listAnchorIssues, archiveAnchor, previewFactChange,
    readReader: (db, input) => queryManuscript(db, input, true), readUses: (db, input) => queryManuscript(db, input, false) }
}
