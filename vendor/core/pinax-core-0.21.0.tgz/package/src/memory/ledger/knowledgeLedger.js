import { normalizeScopeRef, encodeScopeKey, payloadHash } from './ledgerContract.js'
import { headAsOf } from './recordAxis.js'

const KNOWLEDGE_SCAN_MAX = 20000
const READ_TABLES = ['knowledgeEvents', 'factVersions', 'worldClaims', 'ledgerMeta']
const KNOWLEDGE_CHANNELS = Object.freeze(['witnessed', 'heard', 'inferred', 'author-granted'])
const KNOWLEDGE_BELIEFS = Object.freeze(['active', 'confirmed', 'disputed', 'disproved', 'forgotten'])
const KNOWLEDGE_EVENT_KINDS = Object.freeze(['known', 'belief'])
const fail = (reason, extra = {}) => ({ ok: false, reason, retryable: reason === 'db-unavailable', ...extra })

function resolveScope(input) {
  const normalized = normalizeScopeRef(input)
  if (!normalized.ok) return normalized
  return { ok: true, scope: normalized.scope, scopeKey: encodeScopeKey(normalized.scope) }
}

function actorList(input) {
  return [...new Set((Array.isArray(input) ? input : [input])
    .map(key => String(key ?? '').trim()).filter(Boolean))].slice(0, 8)
}

function numericPoint(value) {
  if (value == null) return null
  if (typeof value === 'number' || (typeof value === 'string' && value.trim())) return Number(value)
  return NaN
}

function readAxes({ storyAt, recordedAsOf }) {
  const point = numericPoint(storyAt)
  if (point !== null && !Number.isFinite(point)) return fail('story-time-invalid')
  const seq = numericPoint(recordedAsOf?.seq)
  if (recordedAsOf != null && (!Number.isSafeInteger(seq) || seq < 0)) return fail('recorded-as-of-invalid')
  return { ok: true, point, seq }
}

async function resolveTarget(db, scopeKey, { factVersionId, claimId }) {
  let version = null
  if (factVersionId != null) {
    if (typeof factVersionId !== 'string' || !factVersionId) return fail('fact-version-scope-mismatch')
    version = await db.table('factVersions').get(factVersionId)
    if (!version || version.scopeKey !== scopeKey) return fail('fact-version-scope-mismatch')
  }
  if (!version && claimId == null) return fail('knowledge-target-required')
  if (version && claimId != null && version.claimId !== claimId) return fail('knowledge-target-mismatch')
  const id = claimId ?? version?.claimId ?? null
  if (id !== null) {
    if (typeof id !== 'string' || !id) return fail('claim-scope-mismatch')
    const claim = await db.table('worldClaims').get(id)
    if (!claim || claim.scopeKey !== scopeKey) return fail('claim-scope-mismatch')
  }
  return { ok: true, version, claimId: id }
}

// A corrected event keeps its original place among events dated to the
// same story point. Its replacement only becomes visible at its own record cut.
function effectiveEvents(events) {
  const superseded = new Set(events.map(event => event.supersedesEventId).filter(Boolean))
  return events.filter(event => !superseded.has(event.id))
    .sort((a, b) => storyOrder(a) - storyOrder(b))
}

function storyOrder(event) {
  return event.originalRecordedSeq ?? event.recordedSeq
}

function byStoryOrder(events) {
  // Undated observations have no comparison to a fictional time. At the live
  // view keep them in their recording slots; dated observations replay by story.
  const dated = events.filter(event => event.storyAt != null)
    .sort((a, b) => a.storyAt - b.storyAt || storyOrder(a) - storyOrder(b))
  let next = 0
  return events.map(event => event.storyAt == null ? event : dated[next++])
}

function foldEvents(events, storyAt, tally) {
  const visible = effectiveEvents(events).filter(event => {
    if (storyAt === null) return true
    if (Number.isFinite(event.storyAt) && event.storyAt <= storyAt) return true
    if (event.kind === 'known') tally(event.storyAt == null ? 'known-at-unknown-story-time' : 'known-later')
    return false
  })
  const groups = new Map()
  for (const event of visible) {
    const key = event.claimId ? 'claim:' + event.claimId : 'version:' + event.factVersionId
    if (!groups.has(key)) groups.set(key, [])
    groups.get(key).push(event)
  }
  const beliefs = []
  for (const group of groups.values()) {
    let entry
    const history = []
    for (const event of byStoryOrder(group)) {
      history.push({ id: event.id, factVersionId: event.factVersionId ?? null, kind: event.kind, channel: event.channel, belief: event.belief ?? null,
        storyAt: event.storyAt ?? null, recordedSeq: event.recordedSeq, sourceRef: event.sourceRef ?? null })
      if (event.kind === 'known') {
        if (entry && entry.belief !== 'forgotten') {
          entry.lastKnownVia = event.channel
          continue
        }
        entry = {
          claimId: event.claimId ?? null, factVersionId: event.factVersionId ?? null,
          knownVia: event.channel, lastKnownVia: event.channel, knownAtStory: event.storyAt ?? null, knownAtSeq: event.recordedSeq,
          belief: event.belief ?? (event.schemaVersion !== 2 && event.factVersionId ? 'active' : null), beliefAtSeq: event.recordedSeq
        }
      } else if (entry && entry.belief !== 'forgotten') {
        entry.belief = event.belief
        entry.beliefAtSeq = event.recordedSeq
      } else {
        tally('belief-without-known')
      }
    }
    if (entry) beliefs.push({ ...entry, history })
  }
  return beliefs
}

// A dated change of mind must stand on dated knowledge. For undated
// entries the author's recording order determines where they can be replayed.
function orphanAttitudes(events) {
  const live = effectiveEvents(events)
  const orphan = new Set()
  for (const rows of [live, live.filter(event => event.storyAt != null)]) {
    let aware = false
    for (const event of byStoryOrder(rows)) {
      if (event.kind === 'known') aware = true
      else if (!aware) orphan.add(event.id)
      else if (event.belief === 'forgotten') aware = false
    }
  }
  return orphan
}

async function scopedRows(table, ids, scopeKey, snapshotSeq) {
  const rows = await table.bulkGet([...new Set(ids.filter(Boolean))])
  return new Map(rows.filter(row => row && row.scopeKey === scopeKey &&
    (row.recordedSeq == null || row.recordedSeq <= snapshotSeq)).map(row => [row.id, row]))
}

async function readActor(db, scopeKey, actorKey, snapshotSeq, storyAt, includeInactive) {
  const events = await db.table('knowledgeEvents').where('[scopeKey+actorKey+recordedSeq]')
    .between([scopeKey, actorKey, 0], [scopeKey, actorKey, snapshotSeq], true, true)
    .limit(KNOWLEDGE_SCAN_MAX + 1).toArray()
  const excluded = {}
  const tally = reason => { excluded[reason] = (excluded[reason] || 0) + 1 }
  if (events.length > KNOWLEDGE_SCAN_MAX) {
    return { mode: 'character', facts: [], excluded, incomplete: true, scanned: events.length }
  }
  const entries = foldEvents(events, storyAt, tally)
  const versions = await scopedRows(db.table('factVersions'), entries.map(row => row.factVersionId), scopeKey, snapshotSeq)
  const claims = await scopedRows(db.table('worldClaims'), entries.map(row => row.claimId), scopeKey, snapshotSeq)
  const heads = new Map()
  const facts = []
  for (const entry of entries) {
    const version = versions.get(entry.factVersionId)
    if (entry.factVersionId && !version) { tally('fact-version-missing'); continue }
    const claim = entry.claimId ? claims.get(entry.claimId) : version
    if (!claim || (entry.claimId && version && version.claimId !== entry.claimId)) { tally('claim-missing'); continue }
    if (entry.belief === 'forgotten' || entry.belief === 'disproved') {
      tally(entry.belief)
      if (!includeInactive) continue
    }
    if (version && !heads.has(version.factKey)) {
      const chain = await db.table('factVersions').where('[scopeKey+factKey]').equals([scopeKey, version.factKey]).toArray()
      heads.set(version.factKey, headAsOf(chain, snapshotSeq)?.id)
    }
    const head = version && heads.get(version.factKey)
    facts.push({
      ...entry, factKey: version?.factKey ?? null,
      claim: { subjectKey: claim.subjectKey, subjectLabel: claim.subjectLabel, predicate: claim.predicate, object: claim.object,
        ...(claim.eventContext ? { eventContext: claim.eventContext, eventLabels: claim.eventLabels } : {}) },
      supersededForCharacter: Boolean(head && head !== version.id),
      sourceRefs: [version ? 'fact:' + version.id : 'claim:' + claim.id]
    })
  }
  return { mode: facts.length || Object.keys(excluded).length ? 'character' : 'public-fallback',
    facts, excluded, scanned: events.length }
}

async function readCharacterKnowledge(db, input = {}) {
  const startedAt = Date.now()
  const scope = resolveScope(input.scope)
  if (!scope.ok) return fail(scope.reason)
  const actorKeys = actorList(input.actorKeys)
  if (!actorKeys.length) return fail('actor-key-required')
  const axes = readAxes(input)
  if (!axes.ok) return axes
  try {
    return await db.transaction('r', READ_TABLES, async () => {
      const counter = await db.table('ledgerMeta').get('seq:' + scope.scopeKey)
      const current = counter?.seq ?? 0
      const snapshotVersion = Math.min(axes.seq ?? current, current)
      const actors = Object.create(null)
      let scanned = 0
      let incomplete = false
      for (const key of actorKeys) {
        const actor = await readActor(db, scope.scopeKey, key, snapshotVersion, axes.point, input.includeInactive === true)
        scanned += actor.scanned
        incomplete ||= actor.incomplete === true
        delete actor.scanned
        actors[key] = actor
      }
      return { ok: true, scope: scope.scope, scopeKey: scope.scopeKey, snapshotVersion, actors, scanned, incomplete,
        mode: Object.values(actors).some(actor => actor.mode === 'character') ? 'character' : 'public-fallback',
        elapsedMs: Date.now() - startedAt }
    })
  } catch (error) {
    return fail('db-unavailable', { detail: error?.message || String(error) })
  }
}

function forCharacter(result) {
  if (!result.ok) return { ok: false, reason: result.reason }
  const actors = Object.create(null)
  for (const [key, view] of Object.entries(result.actors)) {
    const facts = view.facts.map(({ factKey, claim, knownVia, lastKnownVia, knownAtStory, belief }) => ({
      factKey, claim, knownVia, lastKnownVia, knownAtStory, belief
    }))
    // The actor may know their own changes of mind. Audit data about a future
    // observation, an author correction or a missing claim stays out of context.
    const excluded = {}
    if (view.excluded.disproved) excluded.disproved = view.excluded.disproved
    if (view.excluded.forgotten) excluded.forgotten = view.excluded.forgotten
    const mode = facts.length || Object.keys(excluded).length || view.incomplete ? 'character' : 'public-fallback'
    actors[key] = { mode, facts, excluded }
  }
  return { ok: true, scopeKey: result.scopeKey, actors,
    mode: Object.values(actors).some(actor => actor.mode === 'character') ? 'character' : 'public-fallback' }
}

export function createKnowledgeLedgerModule({ ledgerId, openLedgerDb, closeLedgerDb } = {}) {
  async function recordKnowledgeEvent(db, input) {
    // Keep the legacy payload hash byte-for-byte when no claimId was supplied.
    const payload = {
      scope: input?.scope, actorKey: input?.actorKey, actorLabel: input?.actorLabel ?? '',
      factVersionId: input?.factVersionId, kind: input?.kind || 'known',
      channel: input?.channel || 'witnessed', belief: input?.belief || null,
      sourceRef: input?.sourceRef ?? null, storyAt: input?.storyAt ?? null,
      actorRef: input?.actorRef ?? '', reason: input?.reason ?? ''
    }
    if (input?.claimId != null) payload.claimId = input.claimId
    if (input?.supersedesEventId != null) payload.supersedesEventId = input.supersedesEventId
    const scope = resolveScope(payload.scope)
    if (!scope.ok) return fail(scope.reason)
    const commandId = typeof input?.commandId === 'string' ? input.commandId.trim() : ''
    if (!commandId) return fail('command-id-required')
    const actorKey = String(payload.actorKey ?? '').trim()
    if (!actorKey) return fail('actor-key-required')
    const storyAt = numericPoint(payload.storyAt)
    if (storyAt !== null && !Number.isFinite(storyAt)) return fail('story-time-invalid')
    if (!KNOWLEDGE_EVENT_KINDS.includes(payload.kind)) return fail('knowledge-kind-invalid')
    if (!KNOWLEDGE_CHANNELS.includes(payload.channel)) return fail('knowledge-channel-invalid')
    if (payload.kind === 'belief' ? !KNOWLEDGE_BELIEFS.includes(payload.belief) : payload.belief !== null) return fail('knowledge-belief-invalid')
    try {
      return await db.transaction('rw', [...READ_TABLES, 'factDecisions'], async () => {
        const decisions = db.table('factDecisions')
        const hash = payloadHash(payload)
        const prior = await decisions.where('commandId').equals(commandId).first()
        if (prior) {
          if (prior.scopeKey !== scope.scopeKey || prior.operation !== 'record-knowledge-event' || prior.payloadHash !== hash) return fail('command-payload-conflict', { commandId })
          return { ok: true, replay: true, decision: prior, result: prior.result }
        }
        const target = await resolveTarget(db, scope.scopeKey, payload)
        if (!target.ok) return target
        const rows = db.table('knowledgeEvents')
        let original = null
        if (payload.supersedesEventId != null) {
          if (typeof payload.supersedesEventId !== 'string' || !payload.supersedesEventId) return fail('knowledge-event-changed')
          original = await rows.get(payload.supersedesEventId)
          if (!original || original.scopeKey !== scope.scopeKey || original.actorKey !== actorKey ||
            original.claimId !== target.claimId || original.kind !== payload.kind ||
            (original.factVersionId ?? null) !== (target.version?.id ?? null) ||
            await rows.where('supersedesEventId').equals(original.id).first()) return fail('knowledge-event-changed')
        }
        const meta = db.table('ledgerMeta')
        const counterId = 'seq:' + scope.scopeKey
        const counter = await meta.get(counterId)
        const seq = (counter?.seq ?? 0) + 1
        const recordedAt = Date.now()
        const event = {
          id: ledgerId('kn'), schemaVersion: original?.schemaVersion ?? (original || payload.claimId == null ? 1 : 2),
          ...(original ? { supersedesEventId: original.id, originalRecordedSeq: storyOrder(original) } : {}), scopeKey: scope.scopeKey, scope: scope.scope,
          actorKey, actorLabel: String(payload.actorLabel || '').slice(0, 120),
          claimId: target.claimId, factVersionId: target.version?.id ?? null, factKey: target.version?.factKey ?? null,
          kind: payload.kind, channel: payload.channel, belief: payload.belief,
          sourceRef: payload.sourceRef ? String(payload.sourceRef).slice(0, 200) : null, storyAt, recordedAt, recordedSeq: seq
        }
        if (original || (payload.claimId != null && payload.kind === 'belief')) {
          const group = await rows.where('[scopeKey+actorKey]').equals([scope.scopeKey, actorKey])
            .filter(row => row.claimId === target.claimId).toArray()
          const previous = orphanAttitudes(group)
          for (const orphan of orphanAttitudes([...group, event])) {
            if (orphan === event.id || !previous.has(orphan)) {
              return fail(original ? 'knowledge-dependent-attitude' : 'knowledge-not-yet-acquired')
            }
          }
        }
        const result = { knowledgeEventId: event.id, actorKey, factVersionId: event.factVersionId, claimId: event.claimId }
        const decision = {
          id: ledgerId('dec'), commandId, scopeKey: scope.scopeKey, scope: scope.scope, operation: 'record-knowledge-event',
          actorKind: 'author', actorRef: String(payload.actorRef || ''), reason: String(payload.reason || ''),
          beforeIds: original ? [original.id] : [], afterIds: [event.id], recordedAt, recordedSeq: seq, payloadHash: hash, result
        }
        await db.table('knowledgeEvents').add(event)
        await decisions.add(decision)
        await meta.put({ id: counterId, seq })
        return { ok: true, replay: false, decision, result }
      })
    } catch (error) {
      return fail('db-unavailable', { detail: error?.message || String(error) })
    }
  }

  async function createCharacterKnowledgeProvider({ scope, actorKeys, storyAt = null, recordedAsOf = null } = {}) {
    const resolved = resolveScope(scope)
    if (!resolved.ok) throw Object.assign(new Error('knowledge provider scope invalid'), { code: resolved.reason })
    const actors = actorList(actorKeys)
    if (!actors.length) throw Object.assign(new Error('knowledge provider needs actorKeys'), { code: 'actor-key-required' })
    const axes = readAxes({ storyAt, recordedAsOf })
    if (!axes.ok) throw Object.assign(new Error('knowledge provider time invalid'), { code: axes.reason })
    return async function readForCharacter() {
      const opened = await openLedgerDb({ openTimeoutMs: 1500 })
      if (!opened.ok) return { ok: false, reason: opened.reason }
      try {
        const result = await readCharacterKnowledge(opened.db, {
          scope: resolved.scope, actorKeys: actors, storyAt: axes.point, recordedAsOf: axes.seq == null ? null : { seq: axes.seq }
        })
        return forCharacter(result)
      } finally {
        await closeLedgerDb(opened.db)
      }
    }
  }

  return Object.freeze({ KNOWLEDGE_CHANNELS, KNOWLEDGE_BELIEFS, KNOWLEDGE_EVENT_KINDS, recordKnowledgeEvent, readCharacterKnowledge, createCharacterKnowledgeProvider })
}
