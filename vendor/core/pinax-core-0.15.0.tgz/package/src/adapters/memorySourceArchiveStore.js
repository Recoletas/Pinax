import { SOURCE_ARCHIVE_STORES } from '../worldbook/sourceArchiveSchema.js'

// A reference/volatile adapter, not a durable save implementation.
export function createMemorySourceArchiveStore(initial = {}) {
  const names = Object.values(SOURCE_ARCHIVE_STORES)
  let tables = Object.fromEntries(names.map(name => [name, new Map((initial[name] || []).map(record => [String(record.id), structuredClone(record)]))]))
  return {
    async readAll(name) { return structuredClone([...tables[name].values()]) },
    async readMany(name, ids) { return structuredClone(ids.map(id => tables[name].get(String(id)))) },
    async snapshot() { return structuredClone(Object.fromEntries(names.map(name => [name, [...tables[name].values()]]))) },
    async write(changes, { signal } = {}) {
      if (signal?.aborted) { const error = new Error('资料归档已取消'); error.name = 'AbortError'; throw error }
      const next = { ...tables }
      for (const [name, change] of Object.entries(changes)) {
        if (!names.includes(name)) throw new Error('未知来源归档表')
        next[name] = change.clear ? new Map() : new Map(tables[name])
        for (const record of change.put || []) {
          if (record.id == null) { const error = new Error('来源记录缺少 ID'); error.name = 'DataError'; throw error }
          next[name].set(String(record.id), structuredClone(record))
        }
        for (const id of change.delete || []) next[name].delete(String(id))
      }
      tables = next
      return { ok: true, durable: false }
    }
  }
}
