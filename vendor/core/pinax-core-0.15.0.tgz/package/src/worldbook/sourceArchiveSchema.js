export const SOURCE_ARCHIVE_SCHEMA_VERSION = 1
export const SOURCE_ARCHIVE_DB_NAME = 'pinax-source-archive'
export const SOURCE_ARCHIVE_DB_VERSION = 1
export const SOURCE_ARCHIVE_CAPACITY_BYTES = 64 * 1024 * 1024
export const SOURCE_ARCHIVE_WARNING_BYTES = 48 * 1024 * 1024
export const SOURCE_PARSE_SLOW_THRESHOLD_MS = 3000
export const SOURCE_ARCHIVE_STORES = Object.freeze({
  artifacts: 'artifacts',
  chunks: 'chunks',
  workspaces: 'workspaces'
})

