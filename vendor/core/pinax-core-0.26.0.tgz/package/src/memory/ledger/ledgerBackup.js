import { defaultCalendar, normalizeCalendar, normalizeStoryClock } from './worldCalendars.js'
import { knowledgeBasis } from './knowledgeReplay.js'
import { validQuotedAnchor } from './manuscriptEvidence.js'
import { validRevision, validEdition, indexEdition } from './manuscriptEdition.js'
import { encodeScopeKey, normalizeScopeRef, worldClaimId } from './ledgerContract.js'
import { stableStringify } from '../knowledgeContract.js'
import { sha256HexOfText } from '../../domain/contentHash.js'
import { legacyWorldClaimForVersion, materializeLegacyWorldClaims, normalizeEventContext } from './worldClaims.js'

// The archive contract evolves independently of the schema-2 fact records.
export const LEDGER_BACKUP_VERSION = 10
const NEW_TABLES = ['worldClaims', 'disclosures', 'claimUses']

// A16 — export/validate/import/compensate interface for the ledger domain,
// integrated into workspaceBackupBundle next to the existing
// memory-history domain (same patterns: count manifests, idempotent import,
// same-ID-different-content domain rejection, compensation restricted to IDs
// inserted by this restore). This module is the
// complete domain behavior.

export const LEDGER_DOMAIN_FILES = {
  evidenceSnapshots: 'ledger/evidence-snapshots.json',
  factProposals: 'ledger/fact-proposals.json',
  factVersions: 'ledger/fact-versions.json',
  factDecisions: 'ledger/fact-decisions.json',
  rejectionMarks: 'ledger/rejection-marks.json',
  ledgerMeta: 'ledger/meta.json',
  turnReceipts: 'ledger/turn-receipts.json',
  knowledgeEvents: 'ledger/knowledge-events.json',
  worldClaims: 'ledger/world-claims.json',
  disclosures: 'ledger/disclosures.json',
  claimUses: 'ledger/claim-uses.json',
  manuscriptEditions: 'ledger/manuscript-editions.json',
  manuscriptChapterRevisions: 'ledger/manuscript-chapter-revisions.json'
}

const LEDGER_TABLE_KEYS = Object.keys(LEDGER_DOMAIN_FILES)

export async function collectLedgerDomain(db) {
  const tables = {}
  const counts = {}
  await db.transaction('r', LEDGER_TABLE_KEYS, async () => {
    for (const key of LEDGER_TABLE_KEYS) {
      const rows = await db.table(key).toArray()
      tables[key] = rows
      counts[key] = rows.length
    }
  })
  const domain = { schemaVersion: LEDGER_BACKUP_VERSION, counts, tables }
  validateLedgerDomain(domain, { counts })
  return domain
}

// turnReceipts is keyed by receiptId (the receipt's own identity); every
// other ledger table uses id.
const LEDGER_TABLE_PK = Object.fromEntries(LEDGER_TABLE_KEYS.map(key => [key, key === 'turnReceipts' ? 'receiptId' : 'id']))

function validateRows(key, rows) {
  if (!Array.isArray(rows)) throw new Error(`事实账本 ${key} 必须是数组`)
  const pk = LEDGER_TABLE_PK[key]
  const ids = new Set()
  for (const row of rows) {
    if (!row || typeof row !== 'object' || typeof row[pk] !== 'string' || !row[pk]) {
      throw new Error(`事实账本 ${key} 存在缺少 ${pk} 的记录`)
    }
    if (ids.has(row[pk])) throw new Error(`事实账本 ${key} 存在重复 ${pk}：${row[pk]}`)
    ids.add(row[pk])
    if (key !== 'ledgerMeta') {
      const [domain, bookId, worldbookId, sessionId, branchId] = String(row.scopeKey || '').split('\u001f')
      // v2 rejection marks store the canonical key only, not a duplicate scope.
      const normalized = normalizeScopeRef(row.scope || { domain, bookId, worldbookId, sessionId, branchId })
      if (!normalized.ok || encodeScopeKey(normalized.scope) !== row.scopeKey) throw new Error(`事实账本 ${key} 作用域不一致`)
    }
    if (key === 'factVersions' && row.schemaVersion !== 2) throw new Error('事实版本 schema 不受支持')
    if (['factDecisions', 'factVersions', 'knowledgeEvents', ...NEW_TABLES].includes(key) && (!Number.isSafeInteger(row.recordedSeq) || row.recordedSeq < 1)) throw new Error('事实或决定缺少有效记录序号')
    if (key === 'factVersions' && (typeof row.object !== 'string' || typeof row.subjectKey !== 'string' || typeof row.predicate !== 'string')) throw new Error('事实主张字段无效')
  }
}

function requiredText(value) {
  return typeof value === 'string' && Boolean(value.trim())
}

function assertReference(rows, id, row, description) {
  const target = rows.get(id)
  if (!target || target.scopeKey !== row.scopeKey ||
      (target.recordedSeq != null && row.recordedSeq != null && (target.visibleFromSeq ?? target.recordedSeq) > row.recordedSeq)) {
    throw new Error(`事实账本${description}引用缺失、跨域或晚于记录`)
  }
  return target
}

function validateAnchor(row) {
  const anchor = row.manuscriptAnchor
  const [domain, bookId] = row.scopeKey.split('\u001f')
  if (!anchor || !requiredText(row.kind) || !requiredText(row.chapterId) ||
      !['book', 'session'].includes(domain) || !bookId || anchor.bookId !== bookId || anchor.chapterId !== row.chapterId ||
      !['unitId', 'unitHash', 'orderRevision'].every(key => requiredText(anchor[key]))) {
    throw new Error('世界模型正文锚点无效或不属于当前书章')
  }
}

// The ZIP manifest and its contained ledger declare the same domain version.
// Schema 2 predates world statements and may also predate knowledgeEvents.
export function validateLedgerDomain(value, manifest) {
  if (!value || typeof value !== 'object') throw new Error('事实账本域缺失或格式损坏')
  const version = value.schemaVersion
  if (![2, 3, 4, 5, 6, 7, 8, 9, LEDGER_BACKUP_VERSION].includes(version) ||
      (manifest?.schemaVersion !== undefined && manifest.schemaVersion !== version)) {
    throw new Error(`事实账本 schema 版本不受支持或与清单不匹配：${version}`)
  }
  if (!value.tables || typeof value.tables !== 'object') throw new Error('事实账本域缺少表数据')
  for (const key of LEDGER_TABLE_KEYS) {
    const rows = value.tables[key]
    const expected = manifest?.counts?.[key]
    const count = value.counts?.[key]
    if ((version < 6 && ['manuscriptChapterRevisions', 'manuscriptEditions'].includes(key)) || (version === 2 && NEW_TABLES.includes(key))) {
      if (rows !== undefined || expected !== undefined || count !== undefined) throw new Error('旧版事实账本包含未声明的世界模型表')
      continue
    }
    if (version === 2 && key === 'knowledgeEvents') {
      if (rows === undefined && (expected ?? 0) === 0 && (count ?? 0) === 0) continue
      if (rows !== undefined && expected === undefined && count === undefined) {
        validateRows(key, rows)
        continue
      }
    }
    validateRows(key, rows)
    if (!Number.isSafeInteger(expected) || expected !== rows.length || count !== expected) {
      throw new Error(`事实账本 ${key} 数量校验失败：包清单 ${expected}，文件 ${rows.length}`)
    }
  }
  const tables = value.tables
  const byId = (rows = []) => new Map(rows.map(row => [row.id, row]))
  const evidence = byId(tables.evidenceSnapshots)
  const versions = byId(tables.factVersions)
  const claims = byId(tables.worldClaims)
  const meta = byId(tables.ledgerMeta)
  const calendarHistory = new Map()
  for (const decision of tables.factDecisions.filter(row => row.operation === 'define-story-calendar' || row.result?.calendar != null)
    .sort((a, b) => a.recordedSeq - b.recordedSeq)) {
    const calendar = decision.result?.calendar
    const normalized = normalizeCalendar(calendar)
    if (version < 9 || decision.operation !== 'define-story-calendar' || !normalized.ok || calendar.id === 'default' ||
        stableStringify(normalized.calendar) !== stableStringify(calendar)) throw new Error('作品历法记录无效')
    const key = JSON.stringify([decision.scopeKey, calendar.id])
    if (!calendarHistory.has(key)) calendarHistory.set(key, [])
    const prior = calendarHistory.get(key).at(-1)
    if (stableStringify(decision.beforeIds) !== stableStringify(prior ? [prior.id] : []) ||
        (prior && decision.recordedSeq <= prior.recordedSeq)) throw new Error('作品历法修订链无效')
    calendarHistory.get(key).push(decision)
  }
  function calendarFor(clock, row) {
    if (clock == null) return defaultCalendar
    if (version < 10 || !normalizeStoryClock(clock) || clock.timelineId === 'default') throw new Error('人物故事时点的历法无效')
    const revisions = calendarHistory.get(JSON.stringify([row.scopeKey, clock.timelineId])) || []
    const calendar = revisions.findLast(decision => decision.recordedSeq < row.recordedSeq)?.result.calendar
    if (!calendar?.eras.some(era => era.id === clock.eraId)) throw new Error('登记时的纪元不存在')
    return calendar
  }
  const links = [...(tables.disclosures || []), ...(tables.claimUses || [])]
  const revisions = byId(tables.manuscriptChapterRevisions)
  const editions = byId(tables.manuscriptEditions)
  for (const row of revisions.values()) {
    if (!['book', 'session'].includes(row.scope?.domain) || !row.scope.bookId || !validRevision(row)) throw new Error('稿面章节修订无效')
  }
  for (const row of editions.values()) {
    if (!['book', 'session'].includes(row.scope?.domain) || !row.scope.bookId || !validEdition(row)) throw new Error('稿面修订无效')
    for (const chapter of row.chapters) {
      if (assertReference(revisions, chapter.revisionId, row, '稿面章节').chapterId !== chapter.chapterId) throw new Error('稿面章节身份不一致')
    }
  }
  for (const row of [...claims.values(), ...tables.factVersions, ...tables.factProposals]) {
    if (row.eventContext === undefined && row.eventLabels === undefined) continue
    const normalized = normalizeEventContext(row.eventContext)
    if (version < 5 || row.kind !== 'event' || !normalized.ok || !normalized.value ||
        stableStringify(normalized.value) !== stableStringify(row.eventContext)) throw new Error('事件地点或参与者无效')
    if (row.eventLabels != null) {
      const refs = new Set([...normalized.value.placeRefs, ...normalized.value.participants.map(person => person.entityRef)])
      if (!Array.isArray(row.eventLabels) || row.eventLabels.some(entry => !entry || !refs.has(entry.entityRef) || !requiredText(entry.label)) ||
          new Set(row.eventLabels.map(entry => entry.entityRef)).size !== row.eventLabels.length) throw new Error('事件实体名称缺少对应的引用')
    }
  }
  for (const row of claims.values()) {
    if (!['state', 'relation', 'event'].includes(row.kind) ||
        ![row.subjectKey, row.predicate, row.object].every(requiredText) ||
        (row.kind === 'event' && !requiredText(row.occurrenceId)) ||
        row.id !== worldClaimId(row.scopeKey, row)) throw new Error('世界命题标识或内容无效')
  }
  for (const row of [...tables.factProposals, ...tables.factVersions, ...links]) {
    if (!Array.isArray(row.evidenceIds)) throw new Error('事实账本证据列表无效')
    for (const id of row.evidenceIds) assertReference(evidence, id, row, '证据')
    if (row.claimId != null) assertReference(claims, row.claimId, row, '命题')
    if (row.supersedes) {
      const prior = versions.get(row.supersedes)
      if (!prior || prior.scopeKey !== row.scopeKey || prior.factKey !== row.factKey || prior.recordedSeq >= row.recordedSeq) throw new Error('事实账本更正链无效')
    }
  }
  for (const row of tables.factVersions) {
    if (row.claimId != null) {
      const expectedId = row.kind ? worldClaimId(row.scopeKey, row) : legacyWorldClaimForVersion(row)?.id
      if (expectedId !== row.claimId) throw new Error('事实版本与世界命题内容不符')
    }
  }
  for (const row of tables.disclosures || []) {
    if (!['narrator-assertion', 'reported-speech'].includes(row.kind)) throw new Error('读者披露类型无效')
  }
  for (const row of tables.claimUses || []) {
    if (!['assertion-use', 'belief-use', 'constraint-use'].includes(row.kind)) throw new Error('正文引用类型无效')
  }
  const editionIndexes = new Map()
  for (const row of links) {
    if (['narrator-assertion', 'assertion-use'].includes(row.kind) && row.expectedVersionId == null) throw new Error('正文断言缺少预期事实版本')
    validateAnchor(row)
    if (row.manuscriptEditionId != null) {
      const edition = assertReference(editions, row.manuscriptEditionId, row, '稿面修订')
      if (!editionIndexes.has(edition.id)) editionIndexes.set(edition.id, indexEdition(edition.chapters.map(ch => revisions.get(ch.revisionId))))
      const anchor = editionIndexes.get(edition.id)(row.chapterId, row.manuscriptAnchor.unitId)
      if (!anchor || anchor.unit.unitHash !== row.manuscriptAnchor.unitHash || anchor.orderRevision !== row.manuscriptAnchor.orderRevision) throw new Error('稿面修订与揭示或引用位置不一致')
    }
    const { bookId, chapterId, unitId, unitHash } = row.manuscriptAnchor
    const sourceId = JSON.stringify([bookId, chapterId, unitId])
    if (!row.evidenceIds.length || row.evidenceIds.some(id => {
      const snapshot = evidence.get(id)
      return snapshot.sourceKind !== 'chapter-quote' || snapshot.sourceId !== sourceId || snapshot.sourceRevision !== unitHash ||
        !requiredText(snapshot.quote) || sha256HexOfText(snapshot.quote) !== unitHash
    })) throw new Error('正文证据与章节锚点不一致')
    assertReference(claims, row.claimId, row, '正文命题')
    if (row.expectedVersionId != null) {
      const fact = assertReference(versions, row.expectedVersionId, row, '正文事实版本')
      if (fact.claimId !== row.claimId || fact.supersedesKind || (fact.invalidatedSeq != null && fact.invalidatedSeq <= row.recordedSeq)) {
        throw new Error('正文引用与当时的预期事实版本不符')
      }
    }
  }
  const linksById = byId(links)
  for (const decision of tables.factDecisions) {
    if (decision.result?.manuscriptEditionId == null) continue
    const edition = assertReference(editions, decision.result.manuscriptEditionId, decision, '登记的稿面修订')
    const link = assertReference(linksById, decision.result.linkId, decision, '登记的稿面关联')
    if (!editionIndexes.has(edition.id)) editionIndexes.set(edition.id, indexEdition(edition.chapters.map(ch => revisions.get(ch.revisionId))))
    const source = editionIndexes.get(edition.id)(link.chapterId, link.manuscriptAnchor.unitId)
    if (!source || source.unit.unitHash !== link.manuscriptAnchor.unitHash ||
        source.orderRevision !== link.manuscriptAnchor.orderRevision) throw new Error('稿面登记决定与原文不符')
  }
  const events = byId(tables.knowledgeEvents)
  const replaced = new Set()
  for (const row of events.values()) {
    calendarFor(row.storyClock, row)
    if (row.speaker != null && (version < 7 || row.kind !== 'known' || row.channel !== 'heard' ||
        !requiredText(row.speaker.entityRef) || !requiredText(row.speaker.label) || row.speaker.entityRef === row.actorKey)) throw new Error('人物消息来源无效')
    if (row.passage != null) {
      const { evidenceId, manuscriptAnchor } = row.passage
      const source = assertReference(evidence, evidenceId, row, '人物原文')
      const [domain, bookId] = row.scopeKey.split('\u001f')
      if (version < 7 || !['book', 'session'].includes(domain) || !bookId || manuscriptAnchor?.bookId !== bookId ||
          source.sourceKind !== 'chapter-quote' || !validQuotedAnchor(manuscriptAnchor, source.quote) ||
          source.sourceRevision !== manuscriptAnchor.unitHash ||
          source.sourceId !== JSON.stringify([bookId, manuscriptAnchor.chapterId, manuscriptAnchor.unitId])) throw new Error('人物获知出处与原文不一致')
    }
    if (row.schemaVersion != null && ![1, 2].includes(row.schemaVersion)) throw new Error('角色获知记录版本无效')
    if (row.supersedesEventId != null) {
      const original = events.get(row.supersedesEventId)
      if (version < 4 || !original || replaced.has(original.id) || original.recordedSeq >= row.recordedSeq ||
          row.originalRecordedSeq !== (original.originalRecordedSeq ?? original.recordedSeq) ||
          original.scopeKey !== row.scopeKey || original.actorKey !== row.actorKey ||
          original.kind !== row.kind || original.claimId !== row.claimId ||
          (original.factVersionId ?? null) !== (row.factVersionId ?? null) ||
          (original.schemaVersion ?? 1) !== row.schemaVersion) throw new Error('角色获知更正链无效')
      replaced.add(original.id)
    } else if (row.originalRecordedSeq != null) throw new Error('角色获知记录缺少更正来源')
    if (row.schemaVersion === 2 && (version < 4 || !row.claimId || (row.kind === 'known' && row.belief != null))) {
      throw new Error('角色获知与态度记录不一致')
    }
    if (!requiredText(row.actorKey) || !['known', 'belief'].includes(row.kind) ||
        !['heard', 'witnessed', 'inferred', 'author-granted'].includes(row.channel) ||
        (row.storyAt != null && !Number.isFinite(row.storyAt)) ||
        (row.kind === 'belief' && !['active', 'confirmed', 'disputed', 'disproved', 'forgotten'].includes(row.belief))) {
      throw new Error('角色获知事件无效')
    }
    if (row.claimId == null && row.factVersionId == null) throw new Error('角色知识缺少命题或事实版本')
    if (row.claimId != null) assertReference(claims, row.claimId, row, '角色命题')
    if (row.factVersionId != null) {
      const fact = assertReference(versions, row.factVersionId, row, '角色事实版本')
      if ((row.claimId != null && fact.claimId !== row.claimId) || (row.factKey != null && fact.factKey !== row.factKey)) {
        throw new Error('角色知识与事实版本不一致')
      }
    }
  }
  const byActorClaim = new Map()
  for (const link of links) {
    const ref = link.beliefUse
    if (ref == null) continue
    if (version < 8 || link.kind !== 'belief-use' || !requiredText(ref.actorKey) || !requiredText(ref.actorLabel) ||
        !Number.isSafeInteger(ref.storyAt)) throw new Error('人物行动依据无效')
    if (!byActorClaim.size) {
      for (const event of events.values()) {
        const key = JSON.stringify([event.scopeKey, event.actorKey, event.claimId])
        if (!byActorClaim.has(key)) byActorClaim.set(key, [])
        byActorClaim.get(key).push(event)
      }
    }
    const rows = byActorClaim.get(JSON.stringify([link.scopeKey, ref.actorKey, link.claimId])) || []
    const basis = knowledgeBasis(rows, { ...ref, calendar: calendarFor(ref.storyClock, link), claimId: link.claimId, recordedSeq: link.recordedSeq })
    if (!basis || basis.incomparable || basis.belief === 'forgotten' || stableStringify(basis) !== stableStringify(ref.basis)) throw new Error('行动依据与登记时的人物知情不符')
  }
  for (const row of [...tables.factVersions, ...tables.factDecisions, ...tables.turnReceipts,
    ...(tables.knowledgeEvents || []), ...claims.values(), ...links, ...revisions.values(), ...editions.values()]) {
    const seq = row.recordedSeq ?? row.archivedSeq
    const counter = meta.get(`seq:${row.scopeKey}`)?.seq
    if (!Number.isSafeInteger(seq) || seq < 1 || !Number.isSafeInteger(counter) || counter < seq) throw new Error('事实账本序号超出作用域计数器')
    const visibleFrom = row.visibleFromSeq ?? seq
    if (!Number.isSafeInteger(visibleFrom) || visibleFrom < seq || visibleFrom > counter) {
      throw new Error('事实版本可见时刻超出记录轴范围')
    }
    if (row.invalidatedSeq != null && (!Number.isSafeInteger(row.invalidatedSeq) || row.invalidatedSeq <= visibleFrom || row.invalidatedSeq > counter)) {
      throw new Error('事实账本失效时刻超出记录轴范围')
    }
  }
  const counts = Object.fromEntries(LEDGER_TABLE_KEYS.map(key => [key, tables[key]?.length || 0]))
  return { total: Object.values(counts).reduce((sum, count) => sum + count, 0), counts }
}

async function sameRestoredRow(db, key, existing, incoming) {
  if (incoming.claimId == null && existing.claimId != null) {
    let expected
    if (key === 'factVersions') expected = legacyWorldClaimForVersion(incoming)?.id
    if (key === 'knowledgeEvents' && incoming.factVersionId) expected = (await db.table('factVersions').get(incoming.factVersionId))?.claimId
    if (expected === existing.claimId) {
      // Old exports predate this derived reference. Compare every other field.
      existing = { ...existing }
      if (Object.hasOwn(incoming, 'claimId')) existing.claimId = incoming.claimId
      else delete existing.claimId
    }
  }
  return stableStringify(JSON.parse(JSON.stringify(existing))) === stableStringify(JSON.parse(JSON.stringify(incoming)))
}

// Idempotent restore. Same id + same content → skipped; same id + different
// content → the whole domain refuses (like v1 history) so a restore can never
// silently overwrite ledger facts. Returns per-table inserted/skipped ids for
// compensation.
export async function importLedgerDomain(db, value) {
  const written = {}
  const skipped = {}
  try {
    validateLedgerDomain(value, { counts: value?.counts })
    await db.transaction('rw', LEDGER_TABLE_KEYS, async () => {
      for (const key of LEDGER_TABLE_KEYS) {
        const table = db.table(key)
        const pk = LEDGER_TABLE_PK[key]
        written[key] = []
        skipped[key] = []
        for (const row of (value.tables[key] || [])) {
          const rowKey = row[pk]
          // The 'schema' meta row is environment metadata regenerated at open;
          // the seq:* rows are DATA (record-axis ordering depends on them) and
          // must restore like any other row.
          if (key === 'ledgerMeta' && rowKey === 'schema') {
            const localSchema = await table.get(rowKey)
            if (!localSchema) { await table.add(structuredClone(row)); written[key].push(rowKey) }
            else skipped[key].push(rowKey)
            continue
          }
          const existing = await table.get(rowKey)
          if (existing) {
            if (!await sameRestoredRow(db, key, existing, row)) {
              throw new Error(`事实账本 ${key} 同一 id 内容不一致：${rowKey}`)
            }
            skipped[key].push(rowKey)
            continue
          }
          await table.add(structuredClone(row))
          written[key].push(rowKey)
        }
      }
      const migrated = await materializeLegacyWorldClaims(db, {
        versionIds: written.factVersions, knowledgeIds: written.knowledgeEvents
      })
      written.worldClaims.push(...migrated.insertedClaimIds)
    })
  } catch (error) {
    // Nothing partial survives a refused domain import.
    return { ok: false, reason: error?.message || String(error), written: null, skipped: null }
  }
  return { ok: true, written, skipped }
}

// Compensation deletes ONLY ids inserted by this restore; existing author
// data is never cleared.
export async function rollbackImportedLedgerDomain(db, written) {
  if (!written) return
  await db.transaction('rw', LEDGER_TABLE_KEYS, async () => {
    for (const key of LEDGER_TABLE_KEYS) {
      const ids = written[key] || []
      if (ids.length) await db.table(key).bulkDelete(ids)
    }
  })
}
