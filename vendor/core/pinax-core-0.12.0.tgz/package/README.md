# @pinax/core

Pinax 三端（Web / Pinix 移动端 / Next 极简版）共用的**平台无关业务内核**。三端各自只保留 UI 与平台适配，业务规则集中在这里——改业务只改 Core，不再各写一份。

> 当前范围：0.12已抽取世界书状态/生命周期/迁移，以及记忆候选、历史与事实/知情账本；三端以固定包消费已有能力。Web/Pinix的存储与UI绑定、Next文件工具保留各自平台接口。Agent运行协议和媒体二进制仓储仍需统一，不能把本批抽取完成等同于全量迁移完成。

## 边界

- 「平台无关」指 Core **不依赖** Vue / DOM / Electron / Capacitor / Node `fs` / `localStorage` 这类宿主能力；纯 JS 依赖允许。平台能力通过 `ChapterStore` 这类**端口**注入，由 Host 提供实现。
- Host 不写业务规则，只调用 Core + 平台 adapter。revision 递增、content-only 保存清结构化侧车、乐观并发等语义只在 `applyChapterPatch` 一处决定；Host 的 store 与内存参照适配器都调它。
- 数据字段：Core 只承诺章节的 `id/title/content/revision/editorDocument` 语义，未知字段原样保留。空标题合法（显示文案归 Host）。旧数据无独立 `chapter.revision` 时按 `editorDocument.revision` 读取。

## API

```js
import {
  createChapterService,       // 异步用例（移动 / 文件端）
  createSyncChapterService,   // 同步用例（localStorage 这类同步 Host）
  applyChapterPatch,          // 保存语义纯函数（Host store.update 调用）
  CHAPTER_SIDECAR_KEYS,
  createMemoryChapterStore,   // 内存参照适配器（测试 / 对照，非生产存储）
  normalizeChapterRecord,
  chapterRevision,
  CORE_ERROR_CODES,           // INVALID_INPUT / BOOK_NOT_FOUND / CHAPTER_NOT_FOUND / STALE_REVISION / DUPLICATE_CHAPTER / IO_FAILED
  ok, fail
} from '@pinax/core'
```

`ChapterStore` 端口方法：`list` / `read` / `create` / `update` / `remove`。Host 侧示例见 Pinax 的 `src/services/writing/chapterCoreStore.js`（浏览器）与 Pinix 的 `createNativeChapterStore`（移动端），两者 `update` 都走 `applyChapterPatch`，行为一致。

## 开发与验证

```bash
npm install
npm test          # vitest：章节用例 + applyChapterPatch 用例
npm run pack      # 生成 dist/pinax-core-<version>.tgz
npm run smoke     # 打 tarball、装进临时消费项目、跑一遍章节 CRUD（证明可作为独立产物被消费）
```

## 作为独立包被三端消费

跨仓共用走**独立仓库引用**：Core 是独立仓库里的 `@pinax/core` 包，三端引用打包产物，不复制源码、不用 monorepo、不用 submodule。0.x 阶段消费方固定精确版本。

- 本地开发：宿主用 `file:` 指向 `npm pack` 出的 tarball。刷新陷阱——版本号没变时 `npm install` 会判定 up-to-date，改完 Core 要在宿主显式重装该 tarball：`npm install <path>/pinax-core-<version>.tgz`。
- 正式发布 / CI：应换成可追溯版本（私有 registry / GitHub Packages）。**发布配置（registry、可见性）当前未写入，包保持 `private: true`**，待作者确定私有远程后再落。

## 目录

```text
src/
  contracts/   # result / error 信封
  domain/      # 章节规范形状、revision、applyChapterPatch
  ports/       # ChapterStore 合同
  usecases/    # 章节业务用例（异步 + 同步）
  adapters/    # 内存 Store（测试 / 对照）
test/          # Core 合同测试
scripts/       # consumer-smoke 自检
```

## 下一步

1. 章节其余路径（重排、历史恢复、大纲同步）与 Pinix 页面调用点切到 Core。
2. Next 的章节 carrier 改为调用 Core。
3. 扩到世界书、资料、Agent / 上下文、漫画。
4. 跨端数据迁移（旧 ZIP / 旧项目 / 移动快照 → Core 项目）。

## v0.9 分工基线：公共写入与助手修改

- `createAssistantProposalEngine({ documents, parseCharacterEntryProfile, idFactory, now, timestamp })`：冻结修改、定位原文、依赖分组、计算采纳/拒绝/撤销。返回新的内容与回执，不写存储；编辑器结构和人物卡正文投影由 Host 注入。`assistantConversationWorkingSet` 等函数统一已处理决定和结束审阅状态。模型循环及界面不属于此引擎。
- `assistantPermission`、`assistantEditProposal`、`assistantEntryDetails` 子路径：权限检查、工具 schema、修改验证和富关系合并的唯一实现。Host 兼容入口只转发，运行器打包携带这个固定包的合同源码。
- `createJournaledWriteStore`：注入同步读/写/删除/哈希与日志键，提供多键写入、回读校验和逆向补偿；可带每键 `expected` 快照。明确的 `operationId` 在同一事务保存回执，重复命令返回原回执、不同内容复用ID报错。同步 adapter 必须同步完成承诺的持久化。该算法是可恢复补偿，不是跨介质 ACID，也不提供跨进程锁。
- `createProjectTransactionService`：命令带 `projectId/operationId` 与各项 `entityType/entityId/expectedRevision/after`，统一校验、修订递增、幂等回执。Host 提供项目隔离的 `keyOf/operationKeyOf`，不能把界面当前作品当成异步任务目标。实体创建使用不存在对象的revision=0；删除暂走既有领域接口，不能用空对象冒充删除。
- `createDurableTransactionService`：移动/文件 Host 可将本地事务与 `flush` 串行组合。只有 `flush` 明确返回true或`{ok:true}`才发布 durable 成功；失败返回 `PERSISTENCE_PENDING`，保留本地事务供同operation重试。它不替代平台原子写和崩溃恢复，不把排队中的写入当保存完成。

A组实现存储端口、原子落盘/锁、flush、备份和恢复；B组调用领域服务/修改引擎并维护编辑器映射，不能在UI复制修订与采纳规则；C组实现媒体提交/轮询/产物保存，并使用稳定项目与实体身份。公共API增改由集成维护者发布新版本。三组不必等待全部历史业务迁入后才开工。

最小验收：同一修改可以采纳、拒绝、撤销、结束审阅；失效原文/错项目拒写；提交失败没有成功回执；幂等重试不重复增修订；flush失败后同操作可恢复。业务引擎不得依赖Vue、DOM、Electron、Capacitor或Node文件系统。正式文件写入与网络生命周期仍由相应Host负责。

## 0.10 的宿主接线

- `@pinax/core/usecases/writingBookRepository`、`projectOutlineRepository`、`writingNotesRepository`：实际仓储行为工厂，传入存储/结果/恢复端口；每个Host创建自己的实例，不跨项目共用全局存储。
- `@pinax/core/context/authoringRunContextReaders`、`writingContextCompiler`：来源、修订与冻结输入；读取使用调用方传入的仓储，Core不回退到浏览器全局状态。
- `@pinax/core/domain/worldbookContextBuilder`、`worldbookFileContract`、`worldbookEntryEditor`：激活规则、无损文件格式与编辑规则；持久化和地图投影仍归Host。
- `@pinax/core/agent/nativeAssistantSession`：保留原Pi会话行为，注入SDK、会话存储、摘要模型及取消端口。
- `@pinax/core/agent/carrierToolLoop`、`carrierWritePolicy`、`carrierToolInterceptors`：Next既有执行行为的共享入口，保留调用方配置及原默认值，不替换Pi协议。

这些子路径由Web/Pinix/Next原路径的兼容转发消费；历史通用领域Service与兼容仓储输入形状不同，不能无校验地互换。UI、原生flush、文件原子性和权限授权仍需Host实际实现。独立测试与包安装smoke证明本批次的可消费性，不代表真实模型质量、Android真机或全部业务迁移已通过。

## 0.11 的文件、恢复与确认边界

- `usecases/file*Tools` 接收Host工具结果适配、载体描述以及路径/知识端口；现有工具的文件约定不变。媒体记录不等于二进制媒体迁移。
- `agent/fileSessionState`、`adapters/fileSessionStore` 管理会话状态、分支与JSONL折叠/追加恢复；Node文件、路径和项目事件从外部注入。
- `adapters/storageSnapshotMirror` 接收字符串存储与异步文件端口、排除键集合和槽文件名。原生写入拒绝返回失败；收到写回执后才返回`durable:true`。这不是跨介质原子事务或设备断电fsync保证。
- `usecases/writingSnapshotRepository`、`writingRecoveryRepository`、`generatedDraftRecovery` 保存版本和恢复副本；重开不代表重新授权采用模型内容。
- `agent/authoringRunSession`及Adapter、`context/manifestToolAuthorization`、`narrative/narrativeResourceIndex` 管理冻结目标和授权资源。地理索引构建函数由Host注入，不引入地图或平台依赖。

本批除包测试外，Host覆盖了切作品后的迟到回答、旧项目保存归属、未知项目拒写、设备保存迟到不清新恢复稿、失败后重试。Android同步不等于APK或真机验证。

## 0.12 的世界书与记忆端口

`worldbook/worldbookState.createWorldbookStateModule`返回普通`state/getters/actions`和只读快照/指纹函数；Web与Pinix用同一组状态/动作绑定Pinia。存储键与读写、归档、地点目录、文件可用性/装载/推送、当前owner访问均由Host提供。独立安装smoke在无Pinia的对象上执行库创建/删除和条目幂等upsert/删除。移动端明确关闭本机localmirror文件源，继续走原生JSON快照。

`memory/memoryCandidates.createMemoryCandidateRepository`使用候选存储和历史快照端口；`memory/memoryHistoryStore.createMemoryHistoryRepository`将历史写进待归档outbox，异步归档确认后再删除待处理事件。归档失败不会把内存/候选作为已归档历史清理。浏览器事件通过`emitCandidate`注入。

`memory/ledger/*`保留现有逻辑表、事务与查询接口：Host数据库对象需要实现原有table/where/transaction等能力。Core不包含Dexie或数据库打开/升级逻辑；ID工厂和打开/关闭由适配器供给。Web/Pinix均使用同一v4装载器读历史和事实账本，表版本、追加式决定和证据绑定保持原合同。直接调用Core的`ledgerContract.ledgerId(prefix, idFactory)`需显式提供ID工厂；原Host路径继续保留单参数兼容函数。

本批隔离浏览器验证覆盖209条修订与v4共存、1059条账本域记录/1001条回执、事实采用/更正和备份；世界书迁移/双写/结算分别由34/47/109项检查覆盖。真实供应商质量、Android设备和媒体二进制迁移不在这些证据内。
