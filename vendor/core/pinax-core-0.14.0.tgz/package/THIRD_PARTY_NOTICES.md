# Third-party notices

`src/media/comicRequestGuard.js` 参考 yuanbw2025/storyforge 的请求登记与未知结果策略，基线 `cd1236cfa5c7cbd307ed0dfac5487f9fe5c98aed`，由 Pinax 按自身 owner 重写，并非逐行复制。来源为 `src/lib/comic/image-request-guard.ts`，MIT，Copyright (c) 2026 yuanbw2025。

原来源注释保留；完整许可随包提供于 `licenses/storyforge-LICENSE.txt`。Core 的私有许可证不替代此许可。其他包依赖沿用各自许可证。
