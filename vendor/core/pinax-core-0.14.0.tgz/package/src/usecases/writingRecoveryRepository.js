import { normalizeStoredWritingSnapshot, normalizeStoredWritingSnapshots } from './writingSnapshotRepository.js'
export function createWritingRecoveryRepository({ getItem, setItem, recoveryKey, mutationFailure, mutationSuccess, storageWriteFailure } = {}) {


function readDrafts() {
  return normalizeStoredWritingSnapshots(getItem(recoveryKey))
    .filter((snapshot) => snapshot.reason === 'crash-recovery')
}

function listWritingRecoveryDrafts(chapterId = null) {
  const drafts = readDrafts()
  return chapterId == null
    ? drafts
    : drafts.filter((draft) => String(draft.chapterId) === String(chapterId))
}

function saveWritingRecoveryDraft(snapshot) {
  const normalized = normalizeStoredWritingSnapshot(snapshot)
  if (!normalized || normalized.reason !== 'crash-recovery') return mutationFailure('invalid-recovery-draft')
  const drafts = readDrafts().filter((draft) => String(draft.chapterId) !== String(normalized.chapterId))
  if (!setItem(recoveryKey, [normalized, ...drafts])) {
    return storageWriteFailure({ resource: 'writing-recovery-drafts' })
  }
  return mutationSuccess({ snapshot: normalized })
}

function clearWritingRecoveryDraft(chapterId) {
  const id = String(chapterId || '')
  if (!id) return mutationFailure('missing-chapter-id')
  const drafts = readDrafts().filter((draft) => String(draft.chapterId) !== id)
  if (!setItem(recoveryKey, drafts)) {
    return storageWriteFailure({ resource: 'writing-recovery-drafts' })
  }
  return mutationSuccess()
}

return Object.freeze({ listWritingRecoveryDrafts, saveWritingRecoveryDraft, clearWritingRecoveryDraft })
}
