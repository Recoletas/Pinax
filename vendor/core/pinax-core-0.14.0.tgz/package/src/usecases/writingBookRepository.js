/** Shared book repository behavior; storage and recovery are supplied by each Host. */
export function createWritingBookRepository({ getItem, setItem, writingBooksKey, normalizeManuscriptLanguage, recoverAssistantEdits = () => {}, mutationFailure, mutationSuccess, storageWriteFailure, now = () => new Date().toISOString(), idFactory = () => Date.now().toString() } = {}) {
  for (const port of [getItem, setItem, normalizeManuscriptLanguage, recoverAssistantEdits, mutationFailure, mutationSuccess, storageWriteFailure]) {
    if (typeof port !== 'function') throw new TypeError('Writing book repository requires explicit storage/result ports')
  }
let revision = 0
const revisionListeners = new Set()

function nextRevision() {
  revision += 1
  return revision
}

function normalizeWritingBook(raw) {
  if (!raw || typeof raw !== 'object') return null
  const id = raw.id === undefined || raw.id === null ? '' : String(raw.id).trim()
  if (!id) return null
  const book = { ...raw, id }
  book.title = String(book.title ?? book.name ?? '').trim()
  book.description = String(book.description ?? '')
  book.worldbookId = String(book.worldbookId ?? '').trim()
  if (!book.createdAt) book.createdAt = now()
  if (!Array.isArray(book.chapters)) book.chapters = []
  return book
}

function loadWritingBooks() {
  recoverAssistantEdits()
  const stored = getItem(writingBooksKey)
  if (!Array.isArray(stored)) return []
  return stored.map(normalizeWritingBook).filter(Boolean)
}

function saveWritingBooksDurable(books) {
  if (!Array.isArray(books)) return mutationFailure('invalid-books')
  const ok = setItem(writingBooksKey, books)
  if (!ok) return storageWriteFailure({ resource: 'writing-books' })

  return publishWritingBooks(books)
}

function publishWritingBooks(books) {
  const currentRevision = nextRevision()
  for (const listener of revisionListeners) {
    try {
      listener({ revision: currentRevision, books })
    } catch {
      // 订阅方异常不阻断持久化。
    }
  }
  return mutationSuccess({ books, revision: currentRevision })
}

// 兼容旧页面：新代码应使用结果型 API，旧布尔调用不再自己写盘。
function saveWritingBooks(books) {
  return saveWritingBooksDurable(books).ok
}

function findWritingBook(books, bookId) {
  if (!Array.isArray(books) || bookId === undefined || bookId === null || bookId === '') return null
  const wanted = String(bookId)
  return books.find((book) => String(book.id) === wanted) || null
}

function createWritingBookRecord({ title, description = '', worldbookId = '', manuscriptLanguage = '' } = {}) {
  const timestamp = now()
  return {
    id: idFactory(),
    title: String(title || '').trim(),
    ...(normalizeManuscriptLanguage(manuscriptLanguage) ? { manuscriptLanguage: normalizeManuscriptLanguage(manuscriptLanguage) } : {}),
    description: String(description || '').trim(),
    worldbookId: String(worldbookId || '').trim(),
    createdAt: timestamp,
    updatedAt: timestamp,
    chapters: []
  }
}

// 仓储级读改写：外部 surface（标签解析器、Experience 写回）不持有页面内存数组时使用。
// 页面内（Authoring）继续持有同一数组就地修改后交给结果型写盘边界，避免双写竞争。
function updateWritingBook(bookId, mutator) {
  const books = loadWritingBooks()
  const book = findWritingBook(books, bookId)
  if (!book) return mutationFailure('not-found')
  if (typeof mutator !== 'function') return mutationFailure('invalid-mutator')
  let patch
  try {
    patch = mutator(book)
  } catch {
    return mutationFailure('mutator-failed')
  }
  if (patch === false) return mutationFailure('mutator-rejected')
  if (patch && typeof patch === 'object' && patch !== book) {
    Object.assign(book, patch)
  }
  book.updatedAt = now()
  const persisted = saveWritingBooksDurable(books)
  return persisted.ok
    ? mutationSuccess({ book, revision: persisted.revision })
    : persisted
}

function renameWritingBook(bookId, title) {
  const nextTitle = String(title || '').trim()
  if (!nextTitle) return mutationFailure('empty-title')
  return updateWritingBook(bookId, () => ({ title: nextTitle }))
}

function deleteWritingBook(bookId) {
  const books = loadWritingBooks()
  const removed = findWritingBook(books, bookId)
  if (!removed) return mutationFailure('not-found')
  const remaining = books.filter((book) => String(book.id) !== String(bookId))
  const persisted = saveWritingBooksDurable(remaining)
  return persisted.ok
    ? mutationSuccess({ book: removed, revision: persisted.revision })
    : persisted
}

function subscribeWritingBooks(listener) {
  if (typeof listener !== 'function') return () => {}
  revisionListeners.add(listener)
  return () => revisionListeners.delete(listener)
}

function currentWritingBooksRevision() {
  return revision
}

return Object.freeze({ normalizeWritingBook, loadWritingBooks, saveWritingBooksDurable, publishWritingBooks, saveWritingBooks, findWritingBook, createWritingBookRecord, updateWritingBook, renameWritingBook, deleteWritingBook, subscribeWritingBooks, currentWritingBooksRevision })
}
