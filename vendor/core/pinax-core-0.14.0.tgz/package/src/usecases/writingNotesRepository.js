import { countNoteWords, deriveNoteTitle } from '../domain/note.js'
export function createWritingNotesRepository({ getItem, setItem, writingNotesKey, clock = () => new Date(), idFactory = () => `note_${Date.now()}_${Math.random().toString(36).slice(2, 8)}` } = {}) {
  if (typeof getItem !== 'function' || typeof setItem !== 'function') throw new TypeError('Writing notes require a storage port')

function normalizeText(value) {
  return String(value || '').trim()
}

function normalizeNoteSource(source = null) {
  if (!source || typeof source !== 'object') return null

  return {
    type: String(source.type || 'manual').trim() || 'manual',
    assetId: String(source.assetId || '').trim(),
    assetKind: String(source.assetKind || '').trim(),
    projectId: source.projectId ?? null,
    sourceType: String(source.sourceType || '').trim(),
    sourceId: String(source.sourceId || '').trim(),
    messageIds: Array.isArray(source.messageIds) ? source.messageIds : []
  }
}

function listWritingNotes() {
  const stored = getItem(writingNotesKey)
  return Array.isArray(stored) ? stored : []
}

function buildWritingNoteTitle(content, fallbackLabel = '素材') {
  const firstLine = deriveNoteTitle(normalizeText(content))
  if (firstLine) return firstLine

  const now = clock()
  const mm = String(now.getMonth() + 1).padStart(2, '0')
  const dd = String(now.getDate()).padStart(2, '0')
  const hh = String(now.getHours()).padStart(2, '0')
  const mi = String(now.getMinutes()).padStart(2, '0')
  return `${fallbackLabel} ${mm}-${dd} ${hh}:${mi}`
}

function createWritingNote(input = {}) {
  const now = clock().toISOString()
  const content = normalizeText(input.content)
  const title = normalizeText(input.title) || buildWritingNoteTitle(content, input.fallbackLabel || '素材')
  const source = normalizeNoteSource(input.source)

  return {
    id: input.id || idFactory(),
    title,
    content,
    contentFormat: input.contentFormat || 'md',
    wordCount: Number.isFinite(Number(input.wordCount))
      ? Math.max(0, Math.floor(Number(input.wordCount)))
      : countNoteWords(content),
    createdAt: input.createdAt || now,
    updatedAt: input.updatedAt || now,
    ...(source ? { source } : {})
  }
}

function createWritingNoteFromAsset(asset = {}, options = {}) {
  const content = normalizeText(asset.content)
  const title = normalizeText(asset.title) || buildWritingNoteTitle(content, options.fallbackLabel || '素材')

  return createWritingNote({
    title,
    content,
    contentFormat: options.contentFormat || 'md',
    wordCount: options.wordCount,
    source: {
      type: 'narrative-asset',
      assetId: String(asset.id || '').trim(),
      assetKind: String(asset.kind || '').trim(),
      projectId: asset.projectId ?? null,
      sourceType: String(asset.source?.type || '').trim(),
      sourceId: String(asset.source?.id || '').trim(),
      messageIds: Array.isArray(asset.source?.messageIds) ? asset.source.messageIds : []
    }
  })
}

function prependWritingNote(input = {}) {
  const note = createWritingNote(input)
  if (!note.content) {
    throw new Error('素材内容不能为空')
  }

  const current = listWritingNotes()
  setItem(writingNotesKey, [note, ...current])
  return note
}

function replaceWritingNotes(notes = []) {
  const next = Array.isArray(notes)
    ? notes.map((note) => createWritingNote(note))
    : []
  setItem(writingNotesKey, next)
  return next
}

return Object.freeze({ listWritingNotes, buildWritingNoteTitle, createWritingNote, createWritingNoteFromAsset, prependWritingNote, replaceWritingNotes })
}
