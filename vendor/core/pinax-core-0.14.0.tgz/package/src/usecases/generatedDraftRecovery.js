export function createGeneratedDraftRecovery({ storage, now = Date.now } = {}) {
// A text-only recovery copy; never writes manuscript content or reuses an old grant.
const PREFIX = 'pinax-generated-draft:v1:'
function key(target) {
  const book = target?.projectId
  const document = target?.documentId || target?.chapterId
  return book && document ? PREFIX + JSON.stringify([String(book), String(document)]) : ''
}
function saveGeneratedDraft(target, text) {
  const id = key(target)
  if (!id || !String(text || '').trim()) return false
  storage.setText(id, JSON.stringify({ text, target: { projectId: target.projectId, documentId: target.documentId || target.chapterId, chapterId: target.chapterId, documentRole: target.documentRole || target.role }, updatedAt: now() }))
  return true
}
function readGeneratedDraft(target) {
  try { const value = JSON.parse(storage.getText(key(target))); return typeof value?.text === 'string' ? value : null } catch { return null }
}
function clearGeneratedDraft(target) {
  const id = key(target)
  if (id) storage.remove(id)
}

return Object.freeze({ saveGeneratedDraft, readGeneratedDraft, clearGeneratedDraft })
}
