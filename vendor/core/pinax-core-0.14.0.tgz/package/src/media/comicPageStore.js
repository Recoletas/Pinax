import { getDefaultComicPanelFrame } from './comicLayout.js'
import { normalizeComicDisplaySelection, resolveComicPanelDisplay } from './comicPanelDisplay.js'

export function createComicPageRepository({ storageKeys: STORAGE_KEYS, normalizeSourceRefs, getMediaAssetDataUrl, listMediaAssets, getStorage, emitChanged }) {
const COMIC_PAGE_SCHEMA_VERSION = 5
const COMIC_PRODUCTION_STAGES = Object.freeze(['rough', 'line', 'flats', 'tones', 'render', 'effects'])

// B 夜：请求登记（防重/结果未知恢复）。仅向后兼容的可空附加字段，schema 仍为 5。
function setComicStagePendingRequest(pageId, panelId, stage, pending = null, options = {}) {
  return updateComicPanelStage(pageId, panelId, stage, {
    pendingRequest: pending ? normalizePendingRequest(pending) : null
  }, options)
}

function clearComicStagePendingRequest(pageId, panelId, stage, requestId, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  const current = page?.panels.find((item) => item.id === panelId)?.production?.[stage]
  if (!current?.pendingRequest) return null
  if (requestId && current.pendingRequest.requestId !== requestId) return null
  return updateComicPanelStage(pageId, panelId, stage, { pendingRequest: null }, options)
}

function setComicPanelPendingGeneration(pageId, panelId, pending = null, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page || !page.panels.some((item) => item.id === panelId)) return null
  return updateComicPanel(pageId, panelId, {
    pendingGeneration: pending ? normalizePendingRequest(pending) : null
  }, options)
}

function clearComicPanelPendingGeneration(pageId, panelId, requestId, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  const current = page?.panels.find((item) => item.id === panelId)
  if (!current?.pendingGeneration) return null
  if (requestId && current.pendingGeneration.requestId !== requestId) return null
  return updateComicPanel(pageId, panelId, { pendingGeneration: null }, options)
}

// B 夜：稳定页序目录（G-B05）。按序列分组、序列内按 pageNumber、
// 无序列按 createdAt；标题变化不影响顺序，编辑旧页不重排列表。
function listComicPagesInOrder(options = {}) {
  return readComicPages(resolveStorage(options.storage))
    .map(createComicPage)
    .sort((left, right) => {
      const sequenceLeft = left.sequenceId || ''
      const sequenceRight = right.sequenceId || ''
      if (sequenceLeft !== sequenceRight) {
        if (!sequenceLeft) return 1
        if (!sequenceRight) return -1
        return sequenceLeft < sequenceRight ? -1 : 1
      }
      if (sequenceLeft) {
        if (left.pageNumber !== right.pageNumber) return left.pageNumber - right.pageNumber
      }
      if (left.createdAt !== right.createdAt) return left.createdAt - right.createdAt
      return left.id < right.id ? -1 : left.id > right.id ? 1 : 0
    })
}

// B 夜：未归属旧页显式迁移（G-B03）。只改归属字段，不动内容与 lineage。
function adoptComicPageProject(pageId, projectId, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page) return null
  return saveComicPage({ ...page, projectId: normalizeNullableText(projectId) }, options)
}

function normalizePendingRequest(input = {}) {
  return {
    requestId: normalizeText(input.requestId),
    intentHash: normalizeText(input.intentHash),
    inputRevision: normalizeText(input.inputRevision),
    stage: normalizeText(input.stage) || null,
    mode: input.mode === 'inpaint' ? 'inpaint' : 'generate',
    sentAt: normalizeTimestamp(input.sentAt, Date.now())
  }
}

const VALID_LAYOUTS = new Set(['strip-4', 'feature-4', 'page-6', 'feature-6', 'free'])
const VALID_STATUSES = new Set(['draft', 'accepted'])
const VALID_GENERATION_STATUSES = new Set(['idle', 'generating', 'ready', 'error'])
const VALID_COLOR_MODES = new Set(['color', 'monochrome'])
const VALID_SHOT_SIZES = new Set(['extreme-wide', 'wide', 'medium', 'close', 'extreme-close', 'insert', 'empty'])
const VALID_CAMERA_ANGLES = new Set(['eye', 'high', 'low', 'bird', 'worm', 'dutch', 'pov'])
const VALID_PERSPECTIVES = new Set(['flat', 'one-point', 'two-point', 'three-point', 'fisheye'])
const VALID_VISUAL_BIBLE_STATUSES = new Set(['draft', 'confirmed'])

function createComicPage(input = {}) {
  const now = Date.now()
  const projectId = normalizeNullableText(input.projectId)
  const panelCount = Array.isArray(input.panels) ? input.panels.length : 0
  const layout = VALID_LAYOUTS.has(input.layout)
    ? input.layout
    : panelCount >= 6 ? 'page-6' : 'strip-4'
  const colorMode = VALID_COLOR_MODES.has(input.colorMode) ? input.colorMode : 'color'
  const panels = normalizePanels(input.panels, { projectId, layout, panelCount, colorMode })

  return {
    id: normalizeText(input.id) || createComicPageId(),
    schemaVersion: COMIC_PAGE_SCHEMA_VERSION,
    projectId,
    sequenceId: normalizeNullableText(input.sequenceId),
    sequenceTitle: normalizeText(input.sequenceTitle),
    pageNumber: normalizePositiveInteger(input.pageNumber, 1),
    adaptationCandidateId: normalizeNullableText(input.adaptationCandidateId),
    visualBibleStatus: VALID_VISUAL_BIBLE_STATUSES.has(input.visualBibleStatus)
      ? input.visualBibleStatus
      : 'draft',
    title: normalizeText(input.title) || '未命名漫画页',
    sourceRefs: normalizeSourceRefs(input.sourceRefs, { projectId }),
    layout,
    format: normalizeFormat(input.format),
    colorMode,
    canvas: normalizeCanvas(input.canvas),
    styleBible: String(input.styleBible || '').trim(),
    visualBible: normalizeVisualBible(input.visualBible, { projectId }),
    // R2-D.3: page-level fields. Old pages (schemaVersion < 3) get safe
    // defaults when re-saved through createComicPage — no data migration
    // required because every field falls back to '' or [] below.
    pagePurpose: normalizeText(input.pagePurpose),
    pageTurnHook: normalizeText(input.pageTurnHook),
    continuityNotes: normalizeStringList(input.continuityNotes, 20),
    visualBibleRefs: normalizeVisualBibleRefs(input.visualBibleRefs),
    panels,
    status: VALID_STATUSES.has(input.status) ? input.status : 'draft',
    revision: normalizePositiveInteger(input.revision, 1),
    createdAt: normalizeTimestamp(input.createdAt, now),
    updatedAt: normalizeTimestamp(input.updatedAt, now)
  }
}

function listComicPages(filters = {}, options = {}) {
  return readComicPages(resolveStorage(options.storage))
    .map(createComicPage)
    .filter((page) => filters.projectId === undefined || page.projectId === filters.projectId)
    .filter((page) => !filters.status || page.status === filters.status)
    .filter((page) => !filters.sourceRef || hasSourceRef(page, filters.sourceRef))
    .sort((a, b) => b.updatedAt - a.updatedAt)
}

function findComicPageBySources(sourceRefs = [], filters = {}, options = {}) {
  const expected = sourceRefSignature(normalizeSourceRefs(sourceRefs, { projectId: filters.projectId }))
  if (!expected) return null
  return listComicPages(filters, options)
    .find((page) => sourceRefSignature(page.sourceRefs) === expected) || null
}

function saveComicPage(input = {}, options = {}) {
  const storage = resolveStorage(options.storage)
  const current = readComicPages(storage)
  const existing = current.find((page) => page.id === input.id)
  const page = createComicPage({
    ...existing,
    ...input,
    createdAt: existing?.createdAt || input.createdAt,
    updatedAt: Date.now()
  })
  writeComicPages(storage, [page, ...current.filter((item) => item.id !== page.id)])
  return page
}

// 文本编辑只提交作者正在编辑的字段；异步生成的候选、选择和在途记录由
// 各自请求负责写入，不能被较早的编辑器快照覆盖。
function saveComicPageDraft(input = {}, options = {}) {
  const current = listComicPages({}, options).find((page) => page.id === input.id)
  if (!current || current.projectId !== input.projectId) throw new Error('漫画页或所属作品已变化')
  const pageKeys = ['title', 'status', 'pagePurpose', 'pageTurnHook', 'continuityNotes', 'visualBibleRefs', 'sourceRefs']
  const panelKeys = ['visual', 'beat', 'dialogue', 'caption', 'continuityRefs', 'letteringObjects']
  const pagePatch = Object.fromEntries(pageKeys.filter((key) => key in input).map((key) => [key, input[key]]))
  const drafts = new Map((input.panels || []).map((panel) => [panel.id, panel]))
  const panels = current.panels.map((panel) => {
    const draft = drafts.get(panel.id)
    if (!draft) return panel
    const patch = Object.fromEntries(panelKeys.filter((key) => key in draft).map((key) => [key, draft[key]]))
    const changedInput = ['visual', 'beat', 'continuityRefs'].some((key) => key in patch
      && compositionSignature(patch[key]) !== compositionSignature(panel[key]))
    return {
      ...panel, ...patch,
      production: changedInput ? markPanelStagesStale(panel.production, '格内容已更新') : panel.production
    }
  })
  return saveComicPage({ ...current, ...pagePatch, panels, revision: current.revision + 1 }, options)
}

function saveComicPages(inputs = [], options = {}) {
  const storage = resolveStorage(options.storage)
  const current = readComicPages(storage)
  const pages = (Array.isArray(inputs) ? inputs : []).map((input) => {
    const existing = current.find((page) => page.id === input?.id)
    return createComicPage({
      ...existing,
      ...input,
      createdAt: existing?.createdAt || input?.createdAt,
      updatedAt: Date.now()
    })
  })
  const ids = new Set(pages.map((page) => page.id))
  writeComicPages(storage, [...pages, ...current.filter((item) => !ids.has(item.id))])
  return pages
}

function listComicSequencePages(sequenceId, options = {}) {
  const id = normalizeText(sequenceId)
  if (!id) return []
  return listComicPages({}, options)
    .filter((page) => page.sequenceId === id)
    .sort((left, right) => left.pageNumber - right.pageNumber)
}

function buildComicPageManifest(input = {}, options = {}) {
  const page = createComicPage(input)
  return {
    format: 'pinax-comic-page',
    version: COMIC_PAGE_SCHEMA_VERSION,
    manifestVersion: 2,
    exportedAt: new Date(options.now || Date.now()).toISOString(),
    page
  }
}

function updateComicPanel(pageId, panelId, patch = {}, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page) return null
  let found = false
  const panels = page.panels.map((panel) => {
    if (panel.id !== panelId) return panel
    found = true
    const panelInput = {
      ...panel,
      ...patch,
      direction: patch.direction
        ? { ...panel.direction, ...patch.direction, revision: panel.direction.revision + 1 }
        : panel.direction
    }
    const next = normalizePanel(panelInput, panel.order, {
      projectId: page.projectId,
      layout: page.layout,
      panelCount: page.panels.length,
      colorMode: page.colorMode
    })
    return hasPanelDirectionChange(patch) ? {
      ...next,
      production: markPanelStagesStale(next.production, patchStaleReason(patch))
    } : next
  })
  return found ? saveComicPage({ ...page, panels, revision: page.revision + 1 }, options) : null
}

function updateComicPanelStage(pageId, panelId, stage, patch = {}, options = {}) {
  if (!COMIC_PRODUCTION_STAGES.includes(stage)) throw new Error('无效的漫画制作阶段')
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page) return null
  const panels = page.panels.map((panel) => {
    if (panel.id !== panelId) return panel
    const current = panel.production[stage]
    const next = normalizeStageState({ ...current, ...patch })
    const production = { ...panel.production, [stage]: next }
    return {
      ...panel,
      displaySelection: patch.selectedArtifactId
        ? { type: 'stage', stage, assetId: patch.selectedArtifactId }
        : panel.displaySelection,
      production: patch.selectedArtifactId !== undefined || patch.status !== undefined
        ? markPanelStagesStale(production, `${stage} 已更新`, stage, false)
        : production
    }
  })
  return saveComicPage({ ...page, panels, revision: page.revision + 1 }, options)
}

function addComicPanelStageArtifact(pageId, panelId, stage, artifact = {}, options = {}) {
  const artifactId = normalizeText(artifact.id)
  if (!artifactId) throw new Error('漫画阶段产物缺少 MediaAsset ID')
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  const panel = page?.panels.find((item) => item.id === panelId)
  if (!panel) return null
  const current = panel.production[stage]
  if (!current) throw new Error('无效的漫画制作阶段')
  const lineage = normalizeArtifactLineage([
    ...current.artifactLineage.filter((item) => item.id !== artifactId),
    {
      id: artifactId,
      parentAssetId: artifact.parentAssetId,
      inputRevision: artifact.inputRevision,
      origin: artifact.origin,
      createdAt: artifact.createdAt
    }
  ])
  if (options.preserveStageState && options.select === false) {
    return updateComicPanelStage(pageId, panelId, stage, {
      artifactIds: [...new Set([...current.artifactIds, artifactId])],
      artifactLineage: lineage
    }, options)
  }
  return updateComicPanelStage(pageId, panelId, stage, {
    artifactIds: [...new Set([...current.artifactIds, artifactId])],
    artifactLineage: lineage,
    selectedArtifactId: options.select === false ? current.selectedArtifactId : artifactId,
    inputRevision: options.select === false ? current.inputRevision : normalizeText(artifact.inputRevision),
    status: 'review',
    staleReason: '',
    approvedAt: null,
    error: null
  }, options)
}

function selectComicPanelStageArtifact(pageId, panelId, stage, artifactId, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  const panel = page?.panels.find((item) => item.id === panelId)
  const current = panel?.production?.[stage]
  if (!current || !current.artifactIds.includes(artifactId)) return null
  const lineage = current.artifactLineage.find((item) => item.id === artifactId)
  return updateComicPanelStage(pageId, panelId, stage, {
    selectedArtifactId: artifactId,
    inputRevision: lineage?.inputRevision || '',
    status: 'review',
    staleReason: '',
    approvedAt: null,
    error: null
  }, options)
}

function approveComicPanelStageArtifact(pageId, panelId, stage, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  const panel = page?.panels.find((item) => item.id === panelId)
  const current = panel?.production?.[stage]
  if (!current?.selectedArtifactId) throw new Error('请先选择阶段候选')
  if (current.status !== 'review') throw new Error('只有待审阅候选可以确认')
  const lineage = current.artifactLineage.find((item) => item.id === current.selectedArtifactId)
  if (options.expectedInputRevision && lineage?.inputRevision !== options.expectedInputRevision) {
    throw new Error('候选基于旧版分镜或上游，请重新生成后再确认')
  }
  return updateComicPanelStage(pageId, panelId, stage, {
    status: 'approved',
    inputRevision: lineage?.inputRevision || current.inputRevision,
    approvedAt: options.now || Date.now(),
    staleReason: '',
    error: null
  }, options)
}

function updateComicVisualBible(pageId, patch = {}, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page) return null
  const nextVisualBible = normalizeVisualBible({
    ...page.visualBible,
    ...patch,
    revision: page.visualBible.revision + 1
  }, { projectId: page.projectId })
  const targets = page.sequenceId ? listComicSequencePages(page.sequenceId, options) : [page]
  const saved = saveComicPages(targets.map((target) => ({
    ...target,
    visualBible: nextVisualBible,
    visualBibleStatus: 'draft',
    panels: target.panels.map((panel) => ({
      ...panel,
      production: markPanelStagesStale(panel.production, '视觉圣经已更新')
    })),
    revision: target.revision + 1
  })), options)
  return saved.find((item) => item.id === pageId) || null
}

function updateComicPageColorMode(pageId, colorMode, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page) return null
  const nextColorMode = colorMode === 'monochrome' ? 'monochrome' : 'color'
  if (page.colorMode === nextColorMode) return page
  return saveComicPage({
    ...page,
    colorMode: nextColorMode,
    visualBibleStatus: 'draft',
    panels: page.panels.map((panel) => ({
      ...panel,
      production: markPanelStagesStale(panel.production, '色制已更新')
    })),
    revision: page.revision + 1
  }, options)
}

function updateComicPageStyleBible(pageId, styleBible, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page) return null
  const nextStyleBible = normalizeText(styleBible)
  if (page.styleBible === nextStyleBible) return page
  const targets = page.sequenceId ? listComicSequencePages(page.sequenceId, options) : [page]
  const saved = saveComicPages(targets.map((target) => ({
    ...target,
    styleBible: nextStyleBible,
    visualBibleStatus: 'draft',
    panels: target.panels.map((panel) => ({
      ...panel,
      production: markPanelStagesStale(panel.production, '统一画风已更新')
    })),
    revision: target.revision + 1
  })), options)
  return saved.find((item) => item.id === pageId) || null
}

function updateComicPageComposition(pageId, input = {}, options = {}) {
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page) return null
  const pageGeometryChanged = compositionSignature({
    format: page.format,
    canvas: page.canvas
  }) !== compositionSignature({
    format: input.format ?? page.format,
    canvas: input.canvas ?? page.canvas
  })
  const existingById = new Map(page.panels.map((panel) => [panel.id, panel]))
  const panels = (Array.isArray(input.panels) ? input.panels : page.panels).map((panel) => {
    const existing = existingById.get(panel.id)
    if (!existing) return panel
    // 构图输入也可能早于一个已返回的图片请求；保留最新的媒体与任务槽位。
    panel = { ...panel, imageTakeIds: existing.imageTakeIds, selectedTakeId: existing.selectedTakeId,
      displaySelection: existing.displaySelection, production: existing.production,
      pendingGeneration: existing.pendingGeneration, generationStatus: existing.generationStatus,
      generationError: existing.generationError }
    const changed = pageGeometryChanged || compositionSignature({
      frame: existing.frame,
      direction: existing.direction
    }) !== compositionSignature({
      frame: panel.frame,
      direction: panel.direction
    })
    if (!changed) return panel
    return {
      ...panel,
      direction: {
        ...panel.direction,
        revision: normalizePositiveInteger(existing.direction?.revision, 1) + 1
      },
      production: markPanelStagesStale(panel.production, '分镜构图已更新')
    }
  })
  return saveComicPage({
    ...page,
    format: input.format ?? page.format,
    canvas: input.canvas ?? page.canvas,
    layout: input.layout ?? page.layout,
    panels,
    revision: page.revision + 1
  }, options)
}

function updateComicSequenceVisualBible(sequenceId, patch = {}, options = {}) {
  const pages = listComicSequencePages(sequenceId, options)
  if (!pages.length) return []
  const current = pages[0].visualBible
  const nextVisualBible = normalizeVisualBible({
    ...current,
    ...patch,
    revision: current.revision + 1
  }, { projectId: pages[0].projectId })
  return saveComicPages(pages.map((page) => ({
    ...page,
    visualBible: nextVisualBible,
    visualBibleStatus: 'draft',
    panels: page.panels.map((panel) => ({
      ...panel,
      production: markPanelStagesStale(panel.production, '视觉圣经已更新')
    })),
    revision: page.revision + 1
  })), options)
}

function confirmComicSequenceVisualBible(sequenceId, options = {}) {
  const pages = listComicSequencePages(sequenceId, options)
  if (!pages.length) return []
  const bible = pages[0].visualBible
  const hasReviewableContent = bible.references.length
    || bible.palette.length
    || bible.lineStyle
    || bible.renderingNotes
  if (!hasReviewableContent) throw new Error('视觉圣经为空，不能确认')
  return saveComicPages(pages.map((page) => ({
    ...page,
    visualBibleStatus: 'confirmed',
    revision: page.revision + 1
  })), options)
}

function canBatchGenerateComicPage(page = {}) {
  return !page.sequenceId || page.visualBibleStatus === 'confirmed'
}

function addComicPanelTake(pageId, panelId, mediaAssetId, options = {}) {
  const id = normalizeText(mediaAssetId)
  if (!id) throw new Error('漫画格缺少 MediaAsset ID')
  const page = listComicPages({}, options).find((item) => item.id === pageId)
  if (!page) return null
  const panel = page.panels.find((item) => item.id === panelId)
  if (!panel) return null
  const imageTakeIds = [...new Set([...panel.imageTakeIds, id])]
  if (options.preserveStageState && options.select === false) {
    return updateComicPanel(pageId, panelId, { imageTakeIds }, options)
  }
  return updateComicPanel(pageId, panelId, {
    imageTakeIds,
    selectedTakeId: options.select === false ? panel.selectedTakeId : id,
    displaySelection: options.select === false ? panel.displaySelection : { type: 'take', assetId: id },
    generationStatus: 'ready',
    generationError: ''
  }, options)
}

async function hydrateComicPageTakes(input = {}, options = {}) {
  const page = createComicPage(input)
  const dataById = new Map()
  const metadataById = new Map(listMediaAssets({}, options).map((asset) => [asset.id, asset]))
  const takeIds = [...new Set(page.panels.flatMap((panel) => [
    ...panel.imageTakeIds,
    resolveComicPanelDisplay(panel, page)?.id
  ]).filter(Boolean))]
  await Promise.all(takeIds.map(async (takeId) => {
    try {
      const data = await getMediaAssetDataUrl(takeId, options)
      if (data) dataById.set(takeId, data)
    } catch {
      // Keep the persisted take reference; IndexedDB may become available later.
    }
  }))
  return {
    ...page,
    panels: page.panels.map((panel) => ({
      ...panel,
      displayImage: (() => {
        const selected = resolveComicPanelDisplay(panel, page)
        return selected && dataById.has(selected.id) ? {
          ...selected,
          data: dataById.get(selected.id),
          width: metadataById.get(selected.id)?.width || 0,
          height: metadataById.get(selected.id)?.height || 0
        } : null
      })(),
      imageTakes: panel.imageTakeIds
        .filter((takeId) => dataById.has(takeId))
        .map((takeId) => ({
          id: takeId,
          data: dataById.get(takeId),
          width: metadataById.get(takeId)?.width || 0,
          height: metadataById.get(takeId)?.height || 0
        }))
    }))
  }
}

function normalizePanels(panels, context) {
  if (!Array.isArray(panels)) return []
  return panels.slice(0, 12).map((panel, index) => normalizePanel(panel, index + 1, context))
}

function normalizePanel(input = {}, fallbackOrder, context) {
  const imageTakeIds = [...new Set((Array.isArray(input.imageTakeIds) ? input.imageTakeIds : [])
    .map(normalizeText)
    .filter(Boolean))]
  const selectedTakeId = imageTakeIds.includes(input.selectedTakeId) ? input.selectedTakeId : null
  return {
    id: normalizeText(input.id) || `panel_${Date.now().toString(36)}_${fallbackOrder}_${Math.random().toString(36).slice(2, 6)}`,
    order: normalizePositiveInteger(input.order, fallbackOrder),
    visual: String(input.visual || '').trim(),
    beat: normalizeBeat(input.beat),
    frame: normalizeFrame(input.frame || getDefaultComicPanelFrame(context.layout, fallbackOrder, context.panelCount)),
    direction: normalizeComicPanelDirection(input.direction, context.projectId),
    dialogue: normalizeDialogue(input.dialogue),
    caption: String(input.caption || '').trim(),
    continuityRefs: normalizeSourceRefs(input.continuityRefs, context),
    referenceBindings: normalizeReferenceBindings(input.referenceBindings),
    imageTakeIds,
    selectedTakeId,
    displaySelection: normalizeComicDisplaySelection(input.displaySelection),
    production: normalizeProduction(input.production, imageTakeIds, selectedTakeId, context.colorMode),
    letteringObjects: normalizeLetteringObjects(input.letteringObjects),
    pendingGeneration: normalizePendingRequestOrNull(input.pendingGeneration),
    generationStatus: VALID_GENERATION_STATUSES.has(input.generationStatus)
      ? input.generationStatus
      : imageTakeIds.length ? 'ready' : 'idle',
    generationError: String(input.generationError || '').trim()
  }
}

function normalizeVisualBible(input = {}, context) {
  const references = normalizeSemanticReferences(input.references, context.projectId)
  const usesSemanticReferences = Array.isArray(input.references)
  const semanticGroups = (kind) => references
    .filter((reference) => reference.kind === kind)
    .map((reference) => ({
      entityRef: reference.sourceRef,
      assetIds: reference.assetIds,
      invariantNotes: reference.invariantNotes,
      locked: reference.locked,
      label: reference.label
    }))
  return {
    references,
    characterRefs: usesSemanticReferences
      ? semanticGroups('character')
      : normalizeReferenceGroups(input.characterRefs, context.projectId),
    locationRefs: usesSemanticReferences
      ? semanticGroups('location')
      : normalizeReferenceGroups(input.locationRefs, context.projectId),
    propRefs: usesSemanticReferences
      ? semanticGroups('prop')
      : normalizeReferenceGroups(input.propRefs, context.projectId),
    styleAssetIds: usesSemanticReferences
      ? [...new Set(references
          .filter((reference) => reference.kind === 'style')
          .flatMap((reference) => reference.assetIds))]
      : normalizeStringList(input.styleAssetIds),
    palette: normalizeStringList(input.palette, 16),
    lineStyle: normalizeText(input.lineStyle),
    renderingNotes: normalizeText(input.renderingNotes),
    invariantNotes: usesSemanticReferences
      ? normalizeStringList(references.flatMap((reference) => reference.invariantNotes), 20)
      : normalizeStringList(input.invariantNotes, 20),
    revision: normalizePositiveInteger(input.revision, 1)
  }
}

function normalizeReferenceGroups(groups, projectId) {
  if (!Array.isArray(groups)) return []
  return groups.slice(0, 60).map((group = {}) => ({
    entityRef: normalizeSourceRefs([group.entityRef], { projectId })[0] || null,
    assetIds: normalizeStringList(group.assetIds),
    invariantNotes: normalizeStringList(group.invariantNotes, 16),
    locked: group.locked !== false,
    label: normalizeText(group.label)
  })).filter((group) => group.entityRef || group.assetIds.length)
}

function normalizeSemanticReferences(references, projectId) {
  if (!Array.isArray(references)) return []
  return references.slice(0, 60).map((reference = {}) => {
    const sourceRef = normalizeSourceRefs([reference.sourceRef], { projectId })[0] || null
    if (!sourceRef) return null
    const kind = ['character', 'location', 'prop', 'style'].includes(reference.kind)
      ? reference.kind
      : 'style'
    return {
      id: normalizeText(reference.id) || `${kind}:${sourceRef.refType}:${sourceRef.refId}`,
      kind,
      label: normalizeText(reference.label) || sourceRef.refId,
      sourceRef,
      assetIds: normalizeStringList(reference.assetIds, 12),
      invariantNotes: normalizeStringList(reference.invariantNotes, 16),
      locked: reference.locked !== false
    }
  }).filter(Boolean)
}

function normalizeProduction(production, imageTakeIds, selectedTakeId, colorMode) {
  const normalized = Object.fromEntries(COMIC_PRODUCTION_STAGES.map((stage) => [
    stage,
    normalizeStageState(production?.[stage])
  ]))
  const activeStages = colorMode === 'monochrome'
    ? ['rough', 'line', 'tones', 'effects']
    : ['rough', 'line', 'flats', 'render', 'effects']
  if (imageTakeIds.length) {
    normalized.render = normalizeStageState({
      ...normalized.render,
      status: normalized.render.status === 'empty' ? 'review' : normalized.render.status,
      artifactIds: [...new Set([...normalized.render.artifactIds, ...imageTakeIds])],
      selectedArtifactId: normalized.render.selectedArtifactId || selectedTakeId,
      inputRevision: normalized.render.inputRevision || 'direct-image-take'
    })
  }
  for (const stage of COMIC_PRODUCTION_STAGES) {
    if (!activeStages.includes(stage) && !normalized[stage].artifactIds.length) normalized[stage] = createStageState()
  }
  return normalized
}

function normalizeStageState(input = {}) {
  const artifactIds = normalizeStringList(input.artifactIds, 40)
  const selectedArtifactId = artifactIds.includes(input.selectedArtifactId)
    ? input.selectedArtifactId
    : null
  return {
    status: ['empty', 'working', 'review', 'approved', 'stale', 'failed'].includes(input.status)
      ? input.status
      : artifactIds.length ? 'review' : 'empty',
    artifactIds,
    artifactLineage: normalizeArtifactLineage(input.artifactLineage, artifactIds),
    selectedArtifactId,
    inputRevision: normalizeText(input.inputRevision),
    staleReason: normalizeText(input.staleReason),
    approvedAt: normalizeTimestamp(input.approvedAt, 0) || null,
    error: input.error?.message ? {
      code: normalizeText(input.error.code) || 'unknown',
      message: normalizeText(input.error.message),
      retryable: Boolean(input.error.retryable)
    } : null,
    pendingRequest: normalizePendingRequestOrNull(input.pendingRequest)
  }
}

function normalizePendingRequestOrNull(input) {
  if (!input?.requestId) return null
  return normalizePendingRequest(input)
}

function normalizeArtifactLineage(input, fallbackIds = []) {
  const entries = Array.isArray(input) ? input : []
  const normalized = entries.slice(0, 40).map((entry = {}) => ({
    id: normalizeText(entry.id),
    parentAssetId: normalizeNullableText(entry.parentAssetId),
    inputRevision: normalizeText(entry.inputRevision),
    origin: entry.origin === 'inpaint'
      ? 'edited'
      : (['generated', 'uploaded', 'edited'].includes(entry.origin) ? entry.origin : 'generated'),
    createdAt: normalizeTimestamp(entry.createdAt, 0) || null
  })).filter((entry) => entry.id)
  const known = new Set(normalized.map((entry) => entry.id))
  for (const id of fallbackIds) {
    if (!known.has(id)) normalized.push({
      id,
      parentAssetId: null,
      inputRevision: '',
      origin: 'generated',
      createdAt: null
    })
  }
  return normalized
}

function createStageState() {
  return normalizeStageState({})
}

function markPanelStagesStale(production, reason, fromStage = null, includeStage = true) {
  const order = ['rough', 'line', 'flats', 'tones', 'render', 'effects']
  const start = fromStage ? order.indexOf(fromStage) + (includeStage ? 0 : 1) : 0
  return Object.fromEntries(Object.entries(production).map(([stage, state]) => {
    if (start >= 0 && order.indexOf(stage) < start) return [stage, state]
    if (!state.artifactIds.length && state.status === 'empty') return [stage, state]
    return [stage, { ...state, status: 'stale', approvedAt: null, staleReason: reason }]
  }))
}

function hasPanelDirectionChange(patch) {
  return ['visual', 'beat', 'frame', 'direction', 'referenceBindings', 'continuityRefs'].some((key) => patch[key] !== undefined)
}

function patchStaleReason(patch) {
  if (patch.direction || patch.frame) return '分镜构图已更新'
  if (patch.referenceBindings || patch.continuityRefs) return '参考绑定已更新'
  return '格内容已更新'
}

function normalizeBeat(input = {}) {
  return {
    action: normalizeText(input.action),
    emotion: normalizeText(input.emotion),
    reveal: normalizeText(input.reveal),
    transition: normalizeText(input.transition)
  }
}

function normalizeFrame(input = {}) {
  const points = Array.isArray(input.points) ? input.points.map(normalizePoint).filter(Boolean).slice(0, 12) : []
  return {
    kind: input.kind === 'polygon' ? 'polygon' : 'rect',
    points: points.length >= 3 ? points : [
      { x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 0, y: 1 }
    ],
    gutter: normalizeUnitNumber(input.gutter, 0.012),
    bleed: Boolean(input.bleed)
  }
}

function normalizeComicPanelDirection(input = {}, projectId = null) {
  input = input && typeof input === 'object' && !Array.isArray(input) ? input : {}
  return {
    revision: normalizePositiveInteger(input.revision, 1),
    notes: normalizeText(input.notes),
    shotSize: VALID_SHOT_SIZES.has(input.shotSize) ? input.shotSize : null,
    cameraAngle: VALID_CAMERA_ANGLES.has(input.cameraAngle) ? input.cameraAngle : null,
    perspective: VALID_PERSPECTIVES.has(input.perspective) ? input.perspective : null,
    focalPoint: normalizePoint(input.focalPoint),
    zoom: normalizeRangeNumber(input.zoom, 0.5, 3, 1),
    horizonY: input.horizonY === null || input.horizonY === undefined ? null : normalizeUnitNumber(input.horizonY, 0.5),
    blocking: normalizeBlocking(input.blocking, projectId),
    motionVectors: normalizeMotionVectors(input.motionVectors),
    balloonSafeZones: normalizeBalloonSafeZones(input.balloonSafeZones)
  }
}

function normalizeBlocking(input, projectId) {
  if (!Array.isArray(input)) return []
  return input.slice(0, 20).map((item = {}, index) => ({
    id: normalizeText(item.id) || `blocking_${index + 1}`,
    label: normalizeText(item.label) || `人物 ${index + 1}`,
    entityRef: normalizeSourceRefs([item.entityRef], { projectId })[0] || null,
    box: normalizeBoxTuple(item.box, [0.32, 0.2, 0.36, 0.66]),
    facing: normalizeText(item.facing)
  }))
}

function normalizeMotionVectors(input) {
  if (!Array.isArray(input)) return []
  return input.slice(0, 20).map((item = {}, index) => ({
    id: normalizeText(item.id) || `motion_${index + 1}`,
    label: normalizeText(item.label) || `动线 ${index + 1}`,
    from: normalizeTuplePoint(item.from, [0.22, 0.7]),
    to: normalizeTuplePoint(item.to, [0.76, 0.34])
  }))
}

function normalizeBalloonSafeZones(input) {
  if (!Array.isArray(input)) return []
  return input.slice(0, 20).map((item = {}, index) => ({
    id: normalizeText(item.id) || `balloon_${index + 1}`,
    label: normalizeText(item.label) || `留白 ${index + 1}`,
    box: normalizeBoxTuple(item.box, [0.52, 0.08, 0.4, 0.2])
  }))
}

function normalizeBoxTuple(input, fallback) {
  const values = Array.isArray(input) ? input.map(Number) : fallback
  const width = normalizeRangeNumber(values[2], 0.04, 1, fallback[2])
  const height = normalizeRangeNumber(values[3], 0.04, 1, fallback[3])
  return [
    normalizeRangeNumber(values[0], 0, 1 - width, fallback[0]),
    normalizeRangeNumber(values[1], 0, 1 - height, fallback[1]),
    width,
    height
  ]
}

function normalizeTuplePoint(input, fallback) {
  const values = Array.isArray(input) ? input.map(Number) : fallback
  return [
    normalizeUnitNumber(values[0], fallback[0]),
    normalizeUnitNumber(values[1], fallback[1])
  ]
}

function normalizeReferenceBindings(bindings) {
  if (!Array.isArray(bindings)) return []
  return bindings.slice(0, 40).map((binding = {}) => ({
    role: ['identity', 'costume', 'location', 'prop', 'style', 'pose', 'edge', 'depth'].includes(binding.role)
      ? binding.role
      : 'style',
    assetId: normalizeText(binding.assetId),
    entityRef: normalizeSourceRefs([binding.entityRef])[0] || null,
    region: Array.isArray(binding.region) ? binding.region.slice(0, 4).map((value) => normalizeUnitNumber(value, 0)) : null,
    weight: Number.isFinite(Number(binding.weight)) ? normalizeUnitNumber(binding.weight, 1) : null
  })).filter((binding) => binding.assetId)
}

function normalizeLetteringObjects(objects) {
  if (!Array.isArray(objects)) return []
  return objects.slice(0, 40).map((object = {}) => ({
    id: normalizeText(object.id) || `lettering_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    type: ['speech', 'thought', 'caption', 'sfx'].includes(object.type) ? object.type : 'speech',
    text: normalizeText(object.text),
    box: Array.isArray(object.box) ? object.box.slice(0, 4).map((value) => normalizeUnitNumber(value, 0)) : null,
    tailTarget: normalizePoint(object.tailTarget),
    style: normalizeLetteringStyle(object.style, object.type),
    zIndex: Number.isFinite(Number(object.zIndex)) ? Number(object.zIndex) : 0
  })).filter((object) => object.text)
}

function normalizeLetteringStyle(input = {}, type = 'speech') {
  const source = input && typeof input === 'object' ? input : {}
  const fontFamily = ['display', 'kai', 'serif', 'sans', 'rounded', 'mono'].includes(source.fontFamily) ? source.fontFamily : 'display'
  const fontWeight = [400, 600, 800].includes(Number(source.fontWeight))
    ? Number(source.fontWeight)
    : type === 'sfx' ? 800 : 600
  const textAlign = ['left', 'center', 'right'].includes(source.textAlign)
    ? source.textAlign
    : type === 'caption' ? 'left' : 'center'
  return {
    fontFamily,
    fontSize: normalizeRangeNumber(source.fontSize, 10, 72, type === 'sfx' ? 32 : 22),
    fontWeight,
    textAlign,
    textDirection: source.textDirection === 'vertical' ? 'vertical' : 'horizontal',
    rotation: normalizeRangeNumber(source.rotation, -180, 180, 0)
  }
}

function normalizeFormat(value) {
  return ['page-ltr', 'page-rtl', 'webtoon'].includes(value) ? value : 'page-ltr'
}

function normalizeCanvas(input = {}) {
  return {
    width: normalizePositiveInteger(input.width, 1200),
    height: normalizePositiveInteger(input.height, 1600),
    bleed: normalizeFiniteNumber(input.bleed, 36),
    safeInset: normalizeFiniteNumber(input.safeInset, 48)
  }
}

// R2-D.3: page-level visual bible refs (lighter binding than the
// full per-page visualBible block — useful when only one panel needs
// to pull a specific character/location/prop/style cue).
const VALID_VISUAL_BIBLE_REF_KINDS = new Set([
  'character', 'location', 'prop', 'palette', 'lineStyle'
])

function normalizeVisualBibleRefs(input) {
  if (!Array.isArray(input)) return []
  return input.slice(0, 40).map((entry = {}) => {
    const kind = VALID_VISUAL_BIBLE_REF_KINDS.has(entry.kind) ? entry.kind : 'character'
    const refId = normalizeText(entry.refId)
    if (!refId) return null
    return {
      kind,
      refId,
      note: normalizeText(entry.note),
      revision: normalizePositiveInteger(entry.revision, 1)
    }
  }).filter(Boolean)
}

function normalizePoint(value) {
  if (!value || !Number.isFinite(Number(value.x)) || !Number.isFinite(Number(value.y))) return null
  return { x: normalizeUnitNumber(value.x, 0), y: normalizeUnitNumber(value.y, 0) }
}

function normalizeUnitNumber(value, fallback) {
  const number = Number(value)
  return Number.isFinite(number) ? Math.min(1, Math.max(0, number)) : fallback
}

function normalizeFiniteNumber(value, fallback) {
  const number = Number(value)
  return Number.isFinite(number) ? number : fallback
}

function normalizeRangeNumber(value, min, max, fallback) {
  const number = Number(value)
  return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback
}

function normalizeStringList(values, limit = 40) {
  if (!Array.isArray(values)) return []
  return [...new Set(values.map(normalizeText).filter(Boolean))].slice(0, limit)
}

function compositionSignature(value) {
  return JSON.stringify(value ?? null)
}

function normalizeDialogue(dialogue) {
  if (!Array.isArray(dialogue)) return []
  return dialogue.slice(0, 6).map((line) => ({
    speaker: String(line?.speaker || '').trim(),
    text: String(line?.text || '').trim()
  })).filter((line) => line.speaker || line.text)
}

function hasSourceRef(page, sourceRef) {
  return page.sourceRefs.some((ref) => (
    ref.refType === sourceRef.refType
    && ref.refId === sourceRef.refId
    && (sourceRef.projectId === undefined || ref.projectId === sourceRef.projectId)
  ))
}

function sourceRefSignature(sourceRefs) {
  return sourceRefs
    .map((ref) => `${ref.refType}:${ref.refId}:${ref.projectId || ''}`)
    .sort()
    .join('|')
}

function readComicPages(storage) {
  try {
    const parsed = JSON.parse(storage.getItem(STORAGE_KEYS.COMIC_PAGES) || '[]')
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

function writeComicPages(storage, pages) {
  storage.setItem(STORAGE_KEYS.COMIC_PAGES, JSON.stringify(pages))
  emitChanged()
}

function resolveStorage(storage) {
  const resolved = storage || getStorage()
  if (!resolved?.getItem || !resolved?.setItem) throw new Error('当前环境不支持漫画页存储')
  return resolved
}

function createComicPageId() {
  return `comic_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
}

function normalizeText(value) {
  return String(value || '').trim()
}

function normalizeNullableText(value) {
  const text = normalizeText(value)
  return text || null
}

function normalizePositiveInteger(value, fallback) {
  const number = Number(value)
  return Number.isFinite(number) && number > 0 ? Math.floor(number) : fallback
}

function normalizeTimestamp(value, fallback) {
  const number = Number(value)
  return Number.isFinite(number) && number > 0 ? number : fallback
}

return { COMIC_PAGE_SCHEMA_VERSION, COMIC_PRODUCTION_STAGES, setComicStagePendingRequest, clearComicStagePendingRequest, setComicPanelPendingGeneration, clearComicPanelPendingGeneration, listComicPagesInOrder, adoptComicPageProject, createComicPage, listComicPages, findComicPageBySources, saveComicPage, saveComicPageDraft, saveComicPages, listComicSequencePages, buildComicPageManifest, updateComicPanel, updateComicPanelStage, addComicPanelStageArtifact, selectComicPanelStageArtifact, approveComicPanelStageArtifact, updateComicVisualBible, updateComicPageColorMode, updateComicPageStyleBible, updateComicPageComposition, updateComicSequenceVisualBible, confirmComicSequenceVisualBible, canBatchGenerateComicPage, addComicPanelTake, hydrateComicPageTakes, normalizeComicPanelDirection }
}
