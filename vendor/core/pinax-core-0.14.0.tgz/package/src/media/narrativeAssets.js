import { mutationFailure, mutationSuccess, storageWriteFailure } from '../contracts/mutationResult.js'

export function createNarrativeAssetModule({ getItem, setItem, storageKeys: STORAGE_KEYS }) {
const ASSET_SCHEMA_VERSION = 1

const assetListeners = new Set()
let notificationPending = false
function subscribeNarrativeAssets(listener) {
  assetListeners.add(listener)
  return () => assetListeners.delete(listener)
}
function writeNarrativeAssets(assets) {
  if (!setItem(STORAGE_KEYS.NARRATIVE_ASSETS, assets)) return false
  if (!notificationPending) {
    notificationPending = true
    queueMicrotask(() => {
      notificationPending = false
      for (const listener of [...assetListeners]) { try { listener() } catch { /* A view failure cannot undo a durable write. */ } }
    })
  }
  return true
}

const ASSET_KINDS = [
  {
    value: 'draft-prose',
    label: '正文候选',
    explanation: '可直接插入章节或作为续写底稿的段落素材。'
  },
  {
    value: 'event',
    label: '剧情事件',
    explanation: '用于推动剧情进展、冲突与转折的事件记录。'
  },
  {
    value: 'character-fact',
    label: '人物事实',
    explanation: '角色设定、关系和行为动机等稳定信息。'
  },
  {
    value: 'worldbook-draft',
    label: '世界书草稿',
    explanation: '可转换为世界书条目的设定草稿。'
  },
  {
    value: 'inspiration',
    label: '灵感',
    explanation: '待整理的意象、句子或片段灵感。'
  },
  {
    value: 'storyboard-seed',
    label: '分镜种子',
    explanation: '用于生成章节分镜的镜头线索或场面描述。'
  },
  {
    value: 'reference-image',
    label: '参考图',
    explanation: '可挂到分镜镜头卡的视觉参考图片。'
  }
]

const ASSET_STATUSES = ['inbox', 'accepted', 'rejected', 'archived']
const ACTIVE_ASSET_STATUSES = ['inbox', 'accepted']
const DEFAULT_IMAGE_PRESENTATION = Object.freeze({
  fit: 'contain',
  scale: 1,
  positionX: 50,
  positionY: 50,
  wrap: 'square',
  align: 'right',
  textGap: 16,
  anchorOffset: 0
})
const CONTENT_REF_TYPES = [
  'worldbook-entry',
  'map-site',
  'history-node',
  'session-message',
  'plot-journal',
  'narrative-asset',
  'canvas-card',
  'chapter',
  'storyboard-shot',
  'comic-page',
  'comic-panel',
  'scene-projection',
  'image',
  'video',
  'audio'
]

function listNarrativeAssets({ status = null, projectId = undefined, kind = null, sourceType = null, sourceId = null } = {}) {
  const stored = getItem(STORAGE_KEYS.NARRATIVE_ASSETS)
  const list = Array.isArray(stored) ? stored : []

  return list
    .filter((asset) => !status || asset.status === status)
    .filter((asset) => !kind || asset.kind === kind)
    .filter((asset) => projectId === undefined || asset.projectId === projectId)
    .filter((asset) => !sourceType || asset.source?.type === sourceType)
    .filter((asset) => !sourceId || asset.source?.id === sourceId)
    .sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0))
}

function listActiveNarrativeAssets(filters = {}) {
  return listNarrativeAssets({ ...filters, status: null })
    .filter((asset) => ACTIVE_ASSET_STATUSES.includes(asset.status))
}

function createNarrativeAsset(input = {}) {
  const now = Date.now()
  const content = normalizeText(input.content)
  const title = normalizeText(input.title) || buildAssetTitle(content)
  const source = normalizeSource(input.source)

  return {
    id: input.id || `asset_${now}_${Math.random().toString(36).slice(2, 8)}`,
    schemaVersion: ASSET_SCHEMA_VERSION,
    projectId: input.projectId ?? null,
    source,
    sourceRefs: normalizeSourceRefs(input.sourceRefs, { source, projectId: input.projectId }),
    contentHash: buildNarrativeAssetContentHash(content),
    kind: normalizeKind(input.kind),
    title,
    content,
    status: normalizeStatus(input.status),
    image: normalizeImage(input.image),
    embeddedImagePresentations: normalizeEmbeddedImagePresentations(input.embeddedImagePresentations),
    createdAt: input.createdAt || now,
    updatedAt: input.updatedAt || now
  }
}

function addNarrativeAsset(input = {}, { dedupe = false } = {}) {
  const result = addNarrativeAssetDurable(input, { dedupe })
  if (result.ok) return result.asset
  throw new Error(result.reason === 'empty-content' ? '素材内容不能为空' : '素材保存失败')
}

/** C-R3：结果型新建；存储写入失败返回 { ok:false }，不产生未持久化的“已创建素材”。 */
function addNarrativeAssetDurable(input = {}, { dedupe = false } = {}) {
  const asset = createNarrativeAsset(input)
  if (!asset.content) {
    return mutationFailure('empty-content')
  }
  const current = listNarrativeAssets({ status: null })
  if (dedupe) {
    const duplicate = findDuplicateNarrativeAsset(asset, current)
    if (duplicate) return mutationSuccess({ asset: duplicate, deduped: true })
  }
  if (!writeNarrativeAssets([asset, ...current])) {
    return storageWriteFailure({ resource: 'narrative-assets' })
  }
  return mutationSuccess({ asset })
}

function normalizeContentRef(ref = {}, fallbackProjectId = null) {
  if (!ref || typeof ref !== 'object') return null
  const refType = normalizeText(ref.refType || ref.type)
  const refId = normalizeText(ref.refId || ref.id)
  if (!CONTENT_REF_TYPES.includes(refType) || !refId) return null

  const normalized = {
    refType,
    refId,
    projectId: normalizeProjectId(ref.projectId ?? fallbackProjectId),
    version: normalizeRefVersion(ref.version),
    excerpt: normalizeExcerpt(ref.excerpt)
  }
  return normalized
}

function normalizeSourceRefs(refs = [], { source = null, projectId = null } = {}) {
  const inputRefs = Array.isArray(refs) ? refs : []
  const normalized = inputRefs
    .map((ref) => normalizeContentRef(ref, projectId))
    .filter(Boolean)

  if (normalized.length === 0) {
    normalized.push(...inferSourceRefs(source, projectId))
  }

  const seen = new Set()
  return normalized.filter((ref) => {
    const key = contentRefKey(ref)
    if (seen.has(key)) return false
    seen.add(key)
    return true
  }).slice(0, 12)
}

function mergeSourceRefs(...groups) {
  const refs = groups.flatMap((group) => Array.isArray(group) ? group : [])
  return normalizeSourceRefs(refs)
}

function createNarrativeAssetSourceRef(asset = {}) {
  if (!asset?.id) return null
  return normalizeContentRef({
    refType: 'narrative-asset',
    refId: asset.id,
    projectId: asset.projectId ?? null,
    excerpt: asset.content
  }, asset.projectId)
}

function sourceRefsToEvidenceRefs(refs = []) {
  return normalizeSourceRefs(refs)
    .map((ref) => `${ref.refType}:${ref.refId}`)
}

function buildNarrativeAssetContentHash(content = '') {
  const normalized = normalizeText(content).replace(/\s+/g, ' ')
  let hash = 2166136261
  for (let index = 0; index < normalized.length; index += 1) {
    hash ^= normalized.charCodeAt(index)
    hash = Math.imul(hash, 16777619)
  }
  return `fnv1a-${(hash >>> 0).toString(16).padStart(8, '0')}`
}

function findDuplicateNarrativeAsset(input = {}, assets = null) {
  const contentHash = input.contentHash || buildNarrativeAssetContentHash(input.content)
  const projectId = normalizeProjectId(input.projectId)
  const sourceRefs = normalizeSourceRefs(input.sourceRefs, {
    source: input.source,
    projectId
  })
  if (sourceRefs.length === 0) return null

  const candidates = Array.isArray(assets) ? assets : listNarrativeAssets({ status: null })
  return candidates.find((asset) => {
    if (!asset || asset.contentHash && asset.contentHash !== contentHash) return false
    if (!asset.contentHash && buildNarrativeAssetContentHash(asset.content) !== contentHash) return false
    if (normalizeProjectId(asset.projectId) !== projectId) return false
    const existingRefs = normalizeSourceRefs(asset.sourceRefs, {
      source: asset.source,
      projectId: asset.projectId
    })
    return sourceRefs.some((ref) => existingRefs.some((existing) => contentRefKey(existing) === contentRefKey(ref)))
  }) || null
}

function buildNarrativeAssetUpdate(current, assetId, patch = {}) {
  const now = Date.now()
  let updated = null

  const next = current.map((asset) => {
    if (asset.id !== assetId) return asset
    const content = patch.content !== undefined ? normalizeText(patch.content) : asset.content
    const source = patch.source !== undefined ? normalizeSource(patch.source) : asset.source
    const projectId = patch.projectId !== undefined ? patch.projectId : asset.projectId
    updated = {
      ...asset,
      ...patch,
      projectId,
      kind: patch.kind ? normalizeKind(patch.kind) : asset.kind,
      status: patch.status ? normalizeStatus(patch.status) : asset.status,
      title: patch.title !== undefined ? normalizeText(patch.title) : asset.title,
      content,
      source,
      sourceRefs: patch.sourceRefs !== undefined || patch.source !== undefined || patch.projectId !== undefined
        ? normalizeSourceRefs(patch.sourceRefs, { source, projectId })
        : (Array.isArray(asset.sourceRefs) ? asset.sourceRefs : normalizeSourceRefs([], { source, projectId })),
      image: patch.image !== undefined ? normalizeImage(patch.image) : asset.image,
      embeddedImagePresentations: patch.embeddedImagePresentations !== undefined
        ? normalizeEmbeddedImagePresentations(patch.embeddedImagePresentations)
        : normalizeEmbeddedImagePresentations(asset.embeddedImagePresentations),
      contentHash: patch.content !== undefined
        ? buildNarrativeAssetContentHash(content)
        : (asset.contentHash || buildNarrativeAssetContentHash(content)),
      updatedAt: now
    }
    return updated
  })

  return { next, updated }
}

function updateNarrativeAsset(assetId, patch = {}) {
  const result = updateNarrativeAssetDurable(assetId, patch)
  return result.ok ? result.asset : null
}

/**
 * C-R3：结果型更新。setItem 失败（含被吞掉的配额异常）返回 { ok:false }，
 * 不产生假成功对象；调用方据此跳过 receipt/画布清理等副作用。
 */
function updateNarrativeAssetDurable(assetId, patch = {}, { expected = null } = {}) {
  const current = listNarrativeAssets({ status: null })
  if (expected) {
    const stored = current.find(asset => asset.id === assetId)
    if (!stored) return mutationFailure('asset-not-found')
    if (['projectId', 'content', 'title'].some(key => (stored[key] ?? '') !== (expected[key] ?? ''))) return mutationFailure('asset-conflict', { assetId })
  }
  const { next, updated } = buildNarrativeAssetUpdate(current, assetId, patch)
  if (!updated) return mutationFailure('asset-not-found')
  if (!writeNarrativeAssets(next)) {
    return storageWriteFailure({ resource: 'narrative-assets', assetId: normalizeText(assetId) })
  }
  return mutationSuccess({ asset: updated })
}

function setNarrativeAssetStatus(assetId, status) {
  return updateNarrativeAsset(assetId, { status })
}

function buildNarrativeAssetRemoval(current, assetId) {
  const normalizedId = normalizeText(assetId)
  const deleted = current.find((asset) => asset.id === normalizedId) || null
  if (!normalizedId || !deleted) return { next: current, deleted: null }
  return {
    next: current.filter((asset) => asset.id !== normalizedId),
    deleted
  }
}

function deleteNarrativeAsset(assetId) {
  const result = deleteNarrativeAssetDurable(assetId)
  return result.ok ? result.deleted : null
}

function deleteNarrativeAssetDurable(assetId) {
  const current = listNarrativeAssets({ status: null })
  const { next, deleted } = buildNarrativeAssetRemoval(current, assetId)
  if (!deleted) return mutationFailure('asset-not-found')
  if (!writeNarrativeAssets(next)) {
    return storageWriteFailure({ resource: 'narrative-assets', assetId: normalizeText(assetId) })
  }
  return mutationSuccess({ deleted })
}

// 批量删除只写盘一次：任一目标不存在或写盘失败时，不产生“删了一半”的状态。
function deleteNarrativeAssetsDurable(assetIds = []) {
  const ids = [...new Set((Array.isArray(assetIds) ? assetIds : []).map(normalizeText).filter(Boolean))]
  if (ids.length === 0) return mutationSuccess({ deleted: [], deletedIds: [] })

  const current = listNarrativeAssets({ status: null })
  const wanted = new Set(ids)
  const deleted = current.filter((asset) => wanted.has(asset.id))
  if (deleted.length !== ids.length) {
    const found = new Set(deleted.map((asset) => asset.id))
    return mutationFailure('asset-not-found', {
      missingAssetIds: ids.filter((id) => !found.has(id))
    })
  }
  if (!writeNarrativeAssets(current.filter((asset) => !wanted.has(asset.id)))) {
    return storageWriteFailure({ resource: 'narrative-assets', assetIds: ids })
  }
  return mutationSuccess({ deleted, deletedIds: ids })
}

function buildNarrativeAssetsStatusUpdate(current, assetIds = [], status) {
  const ids = new Set(Array.isArray(assetIds) ? assetIds : [])
  const now = Date.now()
  const updated = []
  if (ids.size === 0) return { next: current, updated }
  const next = current.map((asset) => {
    if (!ids.has(asset.id)) return asset
    const item = {
      ...asset,
      status: normalizeStatus(status),
      updatedAt: now
    }
    updated.push(item)
    return item
  })
  return { next, updated }
}

function setNarrativeAssetsStatus(assetIds = [], status) {
  const result = setNarrativeAssetsStatusDurable(assetIds, status)
  return result.ok ? result.changed : []
}

function setNarrativeAssetsStatusDurable(assetIds = [], status) {
  const current = listNarrativeAssets({ status: null })
  const { next, updated } = buildNarrativeAssetsStatusUpdate(current, assetIds, status)
  if (updated.length === 0) return mutationSuccess({ changed: [] })
  if (!writeNarrativeAssets(next)) {
    return storageWriteFailure({ resource: 'narrative-assets' })
  }
  return mutationSuccess({ changed: updated })
}

function buildNarrativeAssetMerge(currentOrLoader, assetIds = [], { targetId = null, title = null, status = null } = {}) {
  const ids = [...new Set(Array.isArray(assetIds) ? assetIds.map(normalizeText).filter(Boolean) : [])]
  if (ids.length < 2) return null

  const current = typeof currentOrLoader === 'function' ? currentOrLoader() : currentOrLoader
  const byId = new Map(current.map((asset) => [asset.id, asset]))
  const selected = ids.map((id) => byId.get(id)).filter(Boolean)
  if (selected.length < 2) return null

  const projectIds = new Set(selected.map((asset) => normalizeProjectId(asset.projectId)))
  if (projectIds.size > 1) return null

  const target = selected.find((asset) => asset.id === targetId) || selected[0]
  const contentParts = []
  const seenContent = new Set()
  for (const asset of selected) {
    const content = normalizeText(asset.content)
    if (!content || seenContent.has(content)) continue
    seenContent.add(content)
    contentParts.push(content)
  }
  const mergedContent = contentParts.join('\n\n')
  const sourceRefs = selected.flatMap((asset) => normalizeSourceRefs(asset.sourceRefs, {
    source: asset.source,
    projectId: asset.projectId
  }))
  const merged = {
    ...target,
    title: normalizeText(title) || target.title,
    content: mergedContent,
    sourceRefs: normalizeSourceRefs(sourceRefs, { projectId: target.projectId }),
    contentHash: buildNarrativeAssetContentHash(mergedContent),
    status: status ? normalizeStatus(status) : target.status,
    updatedAt: Date.now()
  }
  const selectedIds = new Set(selected.map((asset) => asset.id))
  const next = current
    .map((asset) => asset.id === target.id ? merged : asset)
    .filter((asset) => asset.id === target.id || !selectedIds.has(asset.id))
  return {
    next,
    asset: merged,
    mergedIds: selected.filter((asset) => asset.id !== target.id).map((asset) => asset.id)
  }
}

function mergeNarrativeAssetsDurable(assetIds = [], options = {}) {
  const buildResult = buildNarrativeAssetMerge(listNarrativeAssets({ status: null }), assetIds, options)
  if (!buildResult) return mutationFailure('merge-invalid-selection')
  if (!writeNarrativeAssets(buildResult.next)) {
    return storageWriteFailure({ resource: 'narrative-assets' })
  }
  return mutationSuccess({ asset: buildResult.asset, mergedIds: buildResult.mergedIds })
}

function mergeNarrativeAssets(assetIds = [], options = {}) {
  const result = mergeNarrativeAssetsDurable(assetIds, options)
  return result.ok ? { asset: result.asset, mergedIds: result.mergedIds } : null
}

function getAssetKindLabel(kind) {
  return ASSET_KINDS.find((item) => item.value === kind)?.label || '素材'
}

function getAssetKindExplanation(kind) {
  return ASSET_KINDS.find((item) => item.value === kind)?.explanation || '可复用的写作素材条目。'
}

function getAssetSourceLabel(source = {}) {
  const type = String(source?.type || 'manual')
  switch (type) {
    case 'experience-session':
      return '体验会话'
    case 'poetry-node':
      return '诗歌节点'
    case 'prose-card':
      return '散文卡片'
    case 'relation-canvas':
      return '卡片画布'
    case 'note-image':
      return '素材生图'
    case 'note':
      return '素材'
    case 'chapter':
      return '章节'
    case 'manual':
    default:
      return '手动录入'
  }
}

function getAssetSourceDetail(source = {}) {
  const label = getAssetSourceLabel(source)
  const messageCount = Array.isArray(source?.messageIds) ? source.messageIds.length : 0
  const chapterId = source?.chapterId ? String(source.chapterId).trim() : ''
  const sourceId = String(source?.id || '').trim()
  const visibleId = chapterId || sourceId
  const parts = [label]
  if (visibleId) parts.push(visibleId)
  if (messageCount > 0) parts.push(`${messageCount} 段`)
  if (chapterId && source?.selectorOffset != null && source?.selectorLength != null) {
    const start = Number(source.selectorOffset)
    const length = Number(source.selectorLength)
    if (Number.isFinite(start) && Number.isFinite(length) && length >= 0) {
      parts.push(`${start}-${start + length}`)
    }
  }
  return parts.join(' · ')
}

function isChapterSelectionSource(source = {}) {
  if (!source || typeof source !== 'object') return false
  if (source.type !== 'chapter') return false
  if (!source.chapterId) return false
  if (!String(source.chapterId).trim()) return false
  return true
}

function createChapterSelectionSource({ chapterId, offset, length, snippet } = {}) {
  const text = String(chapterId || '').trim()
  if (!text) {
    throw new Error('createChapterSelectionSource 需要 chapterId')
  }
  return normalizeSource({
    type: 'chapter',
    id: text,
    chapterId: text,
    selectorOffset: offset,
    selectorLength: length,
    selectorSnippet: snippet
  })
}

function normalizeKind(kind) {
  return ASSET_KINDS.some((item) => item.value === kind) ? kind : 'inspiration'
}

function normalizeStatus(status) {
  return ASSET_STATUSES.includes(status) ? status : 'inbox'
}

function normalizeSource(source = null) {
  const safe = source && typeof source === 'object' ? source : {}
  return {
    type: safe.type || 'manual',
    id: safe.id || '',
    messageIds: Array.isArray(safe.messageIds) ? safe.messageIds : [],
    chapterId: normalizeChapterId(safe.chapterId),
    selectorOffset: normalizeSelectorOffset(safe.selectorOffset),
    selectorLength: normalizeSelectorLength(safe.selectorLength),
    selectorSnippet: normalizeSelectorSnippet(safe.selectorSnippet)
  }
}

function inferSourceRefs(source = null, projectId = null) {
  if (!source || typeof source !== 'object') return []
  const type = normalizeText(source.type)
  const id = normalizeText(source.id || source.chapterId)
  if (type === 'chapter' && (source.chapterId || id)) {
    return [normalizeContentRef({
      refType: 'chapter',
      refId: source.chapterId || id,
      projectId,
      excerpt: source.selectorSnippet
    }, projectId)].filter(Boolean)
  }
  if (type === 'experience-session' && Array.isArray(source.messageIds)) {
    return source.messageIds
      .map((messageId) => normalizeContentRef({
        refType: 'session-message',
        refId: `${id || 'session'}:${normalizeText(messageId)}`,
        projectId
      }, projectId))
      .filter(Boolean)
  }
  return []
}

function contentRefKey(ref) {
  return [ref.refType, ref.refId, ref.projectId || '', ref.version ?? ''].join(':')
}

function normalizeProjectId(value) {
  const text = normalizeText(value)
  return text || null
}

function normalizeRefVersion(value) {
  if (value === null || value === undefined || value === '') return null
  const text = normalizeText(value)
  return text || null
}

function normalizeExcerpt(value) {
  const text = normalizeText(value).replace(/\s+/g, ' ')
  return text ? text.slice(0, 240) : null
}

function normalizeChapterId(value) {
  const text = String(value || '').trim()
  return text || null
}

function normalizeSelectorOffset(value) {
  if (value === null || value === undefined || value === '') return null
  const num = Number(value)
  if (!Number.isFinite(num) || num < 0) return null
  return Math.floor(num)
}

function normalizeSelectorLength(value) {
  if (value === null || value === undefined || value === '') return null
  const num = Number(value)
  if (!Number.isFinite(num) || num < 0) return null
  return Math.floor(num)
}

function normalizeSelectorSnippet(value) {
  const text = String(value || '').trim()
  if (!text) return null
  return text.length > 60 ? text.slice(0, 60) : text
}

function normalizeImage(image = null) {
  if (!image || (!image.data && !image.mediaAssetId)) return null
  return {
    id: image.id || '',
    mediaAssetId: normalizeText(image.mediaAssetId),
    storageRef: normalizeText(image.storageRef),
    purpose: normalizeText(image.purpose),
    prompt: normalizeText(image.prompt),
    data: image.data || '',
    negativePrompt: normalizeText(image.negativePrompt),
    modelName: normalizeText(image.modelName),
    modelId: normalizeText(image.modelId),
    modelType: normalizeText(image.modelType),
    width: Number(image.width) || null,
    height: Number(image.height) || null,
    presentation: normalizeImagePresentation(image.presentation)
  }
}

function normalizeImagePresentation(presentation = {}) {
  const source = presentation && typeof presentation === 'object' ? presentation : {}
  const wrap = ['inline', 'square', 'tight', 'top-bottom', 'behind', 'front'].includes(source.wrap)
    ? source.wrap
    : DEFAULT_IMAGE_PRESENTATION.wrap
  const align = ['left', 'center', 'right'].includes(source.align)
    ? source.align
    : (wrap === 'inline' || wrap === 'top-bottom' ? 'center' : DEFAULT_IMAGE_PRESENTATION.align)
  return {
    fit: source.fit === 'cover' ? 'cover' : DEFAULT_IMAGE_PRESENTATION.fit,
    scale: clampNumber(source.scale, 0.5, 2, DEFAULT_IMAGE_PRESENTATION.scale),
    positionX: clampNumber(source.positionX, 0, 100, DEFAULT_IMAGE_PRESENTATION.positionX),
    positionY: clampNumber(source.positionY, 0, 100, DEFAULT_IMAGE_PRESENTATION.positionY),
    wrap,
    align,
    textGap: clampNumber(source.textGap, 0, 48, DEFAULT_IMAGE_PRESENTATION.textGap),
    anchorOffset: Math.round(clampNumber(source.anchorOffset, 0, Number.MAX_SAFE_INTEGER, 0))
  }
}

function normalizeEmbeddedImagePresentations(presentations = {}) {
  if (!presentations || typeof presentations !== 'object' || Array.isArray(presentations)) return {}
  const normalized = {}
  Object.entries(presentations).slice(0, 32).forEach(([rawKey, presentation]) => {
    const key = String(rawKey || '').trim().slice(0, 160)
    if (!key) return
    normalized[key] = normalizeImagePresentation(presentation)
  })
  return normalized
}

function clampNumber(value, min, max, fallback) {
  const number = Number(value)
  if (!Number.isFinite(number)) return fallback
  return Math.min(max, Math.max(min, number))
}

function normalizeText(value) {
  return String(value || '').trim()
}

function buildAssetTitle(content) {
  const firstLine = content
    .split(/\r?\n/)
    .map((line) => line.trim())
    .find(Boolean)

  if (firstLine) return firstLine.slice(0, 24)

  const now = new Date()
  const mm = String(now.getMonth() + 1).padStart(2, '0')
  const dd = String(now.getDate()).padStart(2, '0')
  const hh = String(now.getHours()).padStart(2, '0')
  const mi = String(now.getMinutes()).padStart(2, '0')
  return `素材 ${mm}-${dd} ${hh}:${mi}`
}

return { ASSET_SCHEMA_VERSION, subscribeNarrativeAssets, ASSET_KINDS, ASSET_STATUSES, ACTIVE_ASSET_STATUSES, DEFAULT_IMAGE_PRESENTATION, CONTENT_REF_TYPES, listNarrativeAssets, listActiveNarrativeAssets, createNarrativeAsset, addNarrativeAsset, addNarrativeAssetDurable, normalizeContentRef, normalizeSourceRefs, mergeSourceRefs, createNarrativeAssetSourceRef, sourceRefsToEvidenceRefs, buildNarrativeAssetContentHash, findDuplicateNarrativeAsset, updateNarrativeAsset, updateNarrativeAssetDurable, setNarrativeAssetStatus, deleteNarrativeAsset, deleteNarrativeAssetDurable, deleteNarrativeAssetsDurable, setNarrativeAssetsStatus, setNarrativeAssetsStatusDurable, mergeNarrativeAssetsDurable, mergeNarrativeAssets, getAssetKindLabel, getAssetKindExplanation, getAssetSourceLabel, getAssetSourceDetail, isChapterSelectionSource, createChapterSelectionSource, normalizeImagePresentation }
}
