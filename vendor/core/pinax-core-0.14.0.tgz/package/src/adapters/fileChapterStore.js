import { applyChapterPatch } from '../domain/chapterPatch.js'
import { normalizeChapterRecord } from '../domain/chapter.js'
import { ok } from '../contracts/result.js'

// File IO, ownership grants and atomicity remain in the existing fileService.
export function createFileChapterStore({ fileService, pluginId, dir = '正文', listFiles }) {
  const record = (file, value) => normalizeChapterRecord({ id: file, title: file.replace(/\.md$/iu, ''), content: value.text || '', revision: value.revision, fileReceipt: value })
  return {
    async list(bookId) {
      const listed = await listFiles()
      if (!listed.ok) return listed
      const rows = []
      for (const item of listed.value.chapters || []) {
        const file = item.file.startsWith(`${dir}/`) ? item.file.slice(dir.length + 1) : item.file
        const result = await this.read(bookId, file)
        if (!result.ok) return result
        rows.push(result.value)
      }
      return ok(rows)
    },
    async read(_bookId, file) { const result = await fileService.read({ pluginId, dir, file }); return result.ok ? ok(record(file, result.value)) : result },
    async create(_bookId, chapter) {
      const result = await fileService.write({ pluginId, dir, file: chapter.id, text: chapter.content, expectedRevision: 0 })
      return result.ok ? ok(record(chapter.id, { ...result.value, text: chapter.content })) : result
    },
    async update(bookId, file, patch, options) {
      const before = await this.read(bookId, file)
      if (!before.ok) return before
      const next = applyChapterPatch(before.value, patch, options)
      if (!next.ok) return next
      const result = await fileService.write({ pluginId, dir, file, text: next.value.content, expectedRevision: options.expectedRevision })
      return result.ok ? ok(record(file, { ...result.value, text: next.value.content })) : result
    },
    async remove(_bookId, file, options) { return fileService.deleteFile({ pluginId, dir, file, expectedRevision: options.expectedRevision }) }
  }
}
