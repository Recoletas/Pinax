const SNAPSHOT_SCHEMA_VERSION = 1

function checksum(text) {
  let hash = 2166136261
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index)
    hash = Math.imul(hash, 16777619)
  }
  return (hash >>> 0).toString(16).padStart(8, '0')
}

function readStorage(storage, excludedKeys) {
  const values = {}
  for (let index = 0; index < storage.length; index += 1) {
    const key = storage.key(index)
    if (key !== null && !excludedKeys.has(key)) values[key] = storage.getItem(key)
  }
  return values
}

function encodeSnapshot(values, revision) {
  const payload = JSON.stringify({ schemaVersion: SNAPSHOT_SCHEMA_VERSION, revision, values })
  return JSON.stringify({ payload, checksum: checksum(payload) })
}

function decodeSnapshot(raw) {
  try {
    const envelope = JSON.parse(String(raw || ''))
    if (!envelope?.payload || checksum(envelope.payload) !== envelope.checksum) return null
    const snapshot = JSON.parse(envelope.payload)
    if (snapshot.schemaVersion !== SNAPSHOT_SCHEMA_VERSION || !snapshot.values) return null
    return snapshot
  } catch {
    return null
  }
}

export function createStorageSnapshotMirror({
  readSnapshotFile,
  writeSnapshotFile,
  storage,
  native = false,
  snapshotFiles = ['pinax-state-a.json', 'pinax-state-b.json'],
  excludedKeys = []
} = {}) {
  const SNAPSHOT_FILES = snapshotFiles
  const EXCLUDED_KEYS = new Set(excludedKeys)
  if (!storage || !Array.isArray(snapshotFiles) || snapshotFiles.length < 2 || (native && [readSnapshotFile, writeSnapshotFile].some(port => typeof port !== 'function'))) throw new TypeError('Snapshot mirror requires storage and native file ports')
  let revision = 0
  let timer = null
  let queued = false
  let running = Promise.resolve({ ok: true, skipped: true })

  async function readSlot(path) {
    try {
      return decodeSnapshot(await readSnapshotFile(path))
    } catch {
      return null
    }
  }

  async function hydrate() {
    if (!native) return { ok: true, skipped: true, reason: 'web-storage' }
    const snapshots = (await Promise.all(SNAPSHOT_FILES.map(readSlot))).filter(Boolean)
    const latest = snapshots.sort((left, right) => right.revision - left.revision)[0]
    if (!latest) return { ok: true, restored: false, revision: 0 }
    // WebView localStorage remains the live working set. Never overwrite a
    // newer surviving value with an older recovery snapshot; only repair keys
    // that are absent after startup/storage eviction.
    for (const [key, value] of Object.entries(latest.values)) {
      if (storage.getItem(key) === null) storage.setItem(key, String(value))
    }
    revision = Number(latest.revision || 0)
    return { ok: true, restored: true, revision }
  }

  async function writeNow() {
    if (!native) return { ok: true, skipped: true, reason: 'web-storage' }
    revision += 1
    const path = SNAPSHOT_FILES[revision % SNAPSHOT_FILES.length]
    try {
      await writeSnapshotFile(path, encodeSnapshot(readStorage(storage, EXCLUDED_KEYS), revision))
      return { ok: true, durable: true, revision, path }
    } catch (error) {
      revision -= 1
      return { ok: false, error, code: 'NATIVE_STORAGE_WRITE_FAILED' }
    }
  }

  function flush() {
    if (timer) clearTimeout(timer)
    timer = null
    queued = false
    running = running.then(writeNow, writeNow)
    return running
  }

  function schedule() {
    if (!native || queued) return
    queued = true
    timer = setTimeout(flush, 250)
  }

  return Object.freeze({ flush, hydrate, schedule })
}

