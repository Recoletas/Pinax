// Project/plugin identity is bound once by the Host. No ambient current-project lookup.
export function createFileBinaryStore({ fileService, pluginId, dir }) {
  const revisions = new Map()
  const base = { pluginId, dir }
  function fileOf(id) {
    const key = String(id || '')
    if (!/^[a-zA-Z0-9_-]+$/.test(key)) throw new Error('媒体 ID 无效')
    return `${key}.bin`
  }
  function unwrap(result) {
    if (result?.ok) return result.value
    throw Object.assign(new Error(result?.error?.message || '媒体文件操作失败'), result?.error)
  }
  async function read(id) {
    const result = await fileService.readBinary({ ...base, file: fileOf(id) })
    if (!result.ok && result.error?.details?.missing === true) {
      revisions.set(id, 0)
      return null
    }
    const value = unwrap(result)
    revisions.set(id, value.revision)
    return value.data
  }
  return {
    get: read,
    async put(id, data) {
      fileOf(id)
      const bytes = data instanceof Uint8Array ? new Uint8Array(data) : new Uint8Array(await data.arrayBuffer())
      if (!revisions.has(id)) await read(id)
      const value = unwrap(await fileService.writeBinary({ ...base, file: fileOf(id), data: bytes, expectedRevision: revisions.get(id) }))
      revisions.set(id, value.revision)
    },
    async delete(id) {
      if (!revisions.has(id)) await read(id)
      if (revisions.get(id) === 0) return
      unwrap(await fileService.deleteFile({ ...base, file: fileOf(id), expectedRevision: revisions.get(id) }))
      revisions.set(id, 0)
    },
    async keys() {
      const value = unwrap(await fileService.list(base))
      return value.entries.filter(entry => entry.kind === 'file' && /^[a-zA-Z0-9_-]+\.bin$/.test(entry.name)).map(entry => entry.name.slice(0, -4))
    }
  }
}
