const ensureString = value => String(value ?? '')
function revisionOf(raw) {
  return ensureString(raw?.updatedAt ?? '')
}

/**
 * 每本世界书一个串行双写队列：
 * - enqueue 前置 isAvailable() 门（不可用零开销）；
 * - coalesceMs 窗口内多次保存合并为一次推送（编辑连击不放大流量）；
 * - 执行前复核「仍是这本书（readFile 有值）/ revision 未变」——过期写直接拒绝，
 *   新变更自己的入队会接管推送；执行后若期间又变更，成功标记让位给新推送；
 * - 世界书已删除 → 跳过（文件侧不删档，kit「不删档」语义，删除联动不在 A3 范围）；
 * - 一切异常收敛到 onSyncFailed，绝不上抛打断编辑。
 */
export function createWorldbookFileSyncController({
  readFile,
  resolveRoot,
  isAvailable = () => true,
  assemble = (raw) => raw,
  push,
  onSynced = () => {},
  onSyncFailed = () => {},
  coalesceMs = 0,
  setTimeoutFn = (handler, ms) => setTimeout(handler, ms),
  clearTimeoutFn = (handle) => clearTimeout(handle)
} = {}) {
  const states = new Map()

  function safeRead(id) {
    try {
      const raw = readFile(id)
      return raw && typeof raw === 'object' ? raw : null
    } catch {
      return null
    }
  }

  async function run(id) {
    const state = states.get(id)
    if (!state) return
    if (state.running) {
      state.rerunQueued = true
      return
    }
    state.running = true
    try {
      const raw = safeRead(id)
      if (!raw) return
      const expectedRevision = state.expectedRevision
      // 竞争守卫（副作用 owner 复核）：入队后 revision 已变 → 本次是过期写，拒绝。
      if (revisionOf(raw) !== expectedRevision) return
      const root = await resolveRoot(id)
      if (!root || revisionOf(safeRead(id)) !== expectedRevision) return
      const result = await push(root, assemble(raw))
      if (result && result.ok) {
        const current = safeRead(id)
        if (current && revisionOf(current) === expectedRevision) {
          onSynced(id, { dir: ensureString(result.dir), at: Date.now() })
        } else {
          // 过期完成：不盖成功标记，期间新变更的入队会立即重新推送。
          console.warn('[worldbookFileRepository] 世界书文件双写完成前已有更新，等待新推送接管', id)
        }
      } else {
        onSyncFailed(id, (result && result.error) || { code: 'SYNC_FAILED', message: '世界书文件同步失败' })
      }
    } catch (error) {
      onSyncFailed(id, { code: 'SYNC_ERROR', message: ensureString(error?.message || error) })
    } finally {
      state.running = false
      if (state.rerunQueued) {
        state.rerunQueued = false
        await run(id)
      }
    }
  }

  return {
    /** 入队一次双写。返回是否确实入队（未入队=不可用/书不存在，调用方无需处理）。 */
    enqueue(worldbookId) {
      const id = ensureString(worldbookId).trim()
      if (!id) return false
      try {
        if (!isAvailable()) return false
      } catch {
        return false
      }
      const raw = safeRead(id)
      if (!raw) return false
      const state = states.get(id) || { handle: null, expectedRevision: '', running: false, rerunQueued: false }
      state.expectedRevision = revisionOf(raw)
      if (state.handle !== null && state.handle !== undefined) clearTimeoutFn(state.handle)
      state.handle = setTimeoutFn(() => {
        state.handle = null
        void run(id)
      }, Math.max(0, Number(coalesceMs) || 0))
      states.set(id, state)
      return true
    },
    /** 测试观察用：当前等待推送的世界书数。 */
    pendingCount() {
      let count = 0
      for (const state of states.values()) {
        if (state.handle !== null && state.handle !== undefined) count += 1
      }
      return count
    }
  }
}

/* ---------- localStorage 快照（readWorldbookSnapshot 域外的一次性读取，供 C 组复用） ---------- */

