import { serializeToolOutput, createUsageTally, absorbUsage, usageOf } from './carrierToolLoop.js'

function textOf(content) {
  return typeof content === 'string' ? content : (content || []).filter(part => part.type === 'text').map(part => part.text).join('\n')
}

// Complete-only gateways produce one real completion event, never fabricated token deltas.
export function createGatewayNativeModels({ model, complete, createEventStream, tally }) {
  async function completeSimple(selected, context, options = {}) {
    const messages = context.messages.map(message => {
      if (message.role === 'toolResult') return { role: 'tool', toolCallId: message.toolCallId, toolName: message.toolName, output: textOf(message.content), isError: !!message.isError }
      if (message.role !== 'assistant') return { role: message.role, content: textOf(message.content) }
      const toolCalls = message.content.filter(part => part.type === 'toolCall').map(part => ({ id: part.id, name: part.name, arguments: part.arguments }))
      return { role: 'assistant', content: textOf(message.content), ...(toolCalls.length ? { toolCalls } : {}) }
    })
    const result = await complete({ systemPrompt: context.systemPrompt, messages, tools: (context.tools || []).map(tool => ({ name: tool.name, description: tool.description, parameters: tool.parameters })), toolChoice: 'auto' }, { signal: options.signal })
    if (options.signal?.aborted) throw options.signal.reason || new Error('已停止')
    if (result.finishReason === 'error' || result.finishReason === 'length') throw new Error(result.message || `模型未完成回答：${result.finishReason}`)
    absorbUsage(tally, result.usage)
    const calls = result.toolCalls || []
    const usage = result.usage
    return {
      role: 'assistant', api: selected.api, provider: selected.provider, model: selected.id,
      content: [...(result.content ? [{ type: 'text', text: String(result.content) }] : []), ...calls.map(call => ({ type: 'toolCall', id: call.id, name: call.name, arguments: call.arguments || {} }))],
      stopReason: calls.length ? 'toolUse' : 'stop', timestamp: Date.now(),
      usage: { input: Number(usage?.inputTokens) || 0, output: Number(usage?.outputTokens) || 0, totalTokens: Number(usage?.totalTokens) || 0, cacheRead: 0, cacheWrite: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } }
    }
  }
  return {
    getModel: (provider, id) => provider === model.provider && id === model.id ? model : undefined,
    completeSimple,
    streamSimple(selected, context, options) {
      const stream = createEventStream()
      completeSimple(selected, context, options).then(message => { stream.push({ type: 'start', partial: message }); stream.push({ type: 'done', reason: message.stopReason, message }) }, error => stream.push({ type: 'error', reason: options?.signal?.aborted ? 'aborted' : 'error', error: { role: 'assistant', content: [], api: selected.api, provider: selected.provider, model: selected.id, timestamp: Date.now(), stopReason: options?.signal?.aborted ? 'aborted' : 'error', errorMessage: error.message, usage: { input: 0, output: 0, totalTokens: 0, cacheRead: 0, cacheWrite: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } } } }))
      return stream
    }
  }
}

// Both carriers execute through createNativeAssistantSessionModule. The legacy loop is compatibility-only.
export function createCarrierNativeRunner({ createAssistantSession, createEventStream, model, complete, callTool, interceptors, tasksDir, idFactory, compaction }) {
  return {
    async run({ question = '', envelope = null, tools = [], writeMode, runId, history = [], signal, abort, onEvent = () => {}, buildUserMessage }) {
      const steps = [], calls = [], tally = createUsageTally()
      const emit = event => { try { const sent = onEvent(event); sent?.catch?.(() => {}) } catch { /* observers do not own a run */ } }
      const models = createGatewayNativeModels({ model, complete, createEventStream, tally })
      let step = 0
      const stopped = () => signal?.aborted || abort?.() === true
      const session = createAssistantSession({
        compaction,
        initialState: { model, tools: tools.map(tool => ({ name: tool.name, description: tool.description || tool.title || tool.name, parameters: tool.inputSchema || { type: 'object', properties: {} }, async execute(id, args) {
          if (stopped()) throw new Error('PINAX_ADAPTER_ABORTED')
          const call = { id, name: tool.name, arguments: args }
          const ctx = { call, step, tools, writeMode, runId }
          const started = Date.now()
          calls.push({ id, name: tool.name })
          emit({ stage: 'tool-start', callId: id, name: tool.name, runId })
          let result, isError = false
          try {
            const decided = await interceptors?.runBefore(tool.name, args, ctx)
            if (decided?.veto) {
              isError = decided.decision !== 'proposal'
              const proposalId = String(decided.proposal?.id || decided.proposal?.name || '')
              result = isError ? { ok: false, code: decided.code, message: decided.reason } : { ok: true, proposalId, message: '已生成提案，等待作者采用。' }
              emit({ stage: isError ? 'tool-denied' : 'proposal-created', callId: id, name: tool.name, proposalId, code: decided.code, runId })
            } else {
              try { result = await callTool(tool.name, decided?.args || args) }
              catch (error) { result = { ok: false, error: { code: error.code, message: error.message } } }
              await interceptors?.runAfter(tool.name, result, { ...ctx, guardDecision: decided?.guardDecision })
              isError = result?.ok === false
            }
          } catch (error) { isError = true; result = { ok: false, error: { code: error.code, message: error.message } } }
          emit({ stage: 'tool-end', callId: id, name: tool.name, ok: !isError, ms: Date.now() - started, runId })
          return { content: [{ type: 'text', text: serializeToolOutput(result) }], details: result, isError }
        } })), messages: history },
        streamFn: (selected, input, options) => models.streamSimple(selected, input, options),
        beforeToolCall: () => stopped() ? { block: true, reason: '作者已停止任务。' } : undefined
      }, { models, tasksDir, req: { bookId: envelope?.target?.bookId || 'project', taskId: runId || idFactory() }, signal })
      session.subscribe(event => {
        if (event.type === 'turn_start') { step++; steps.push({ step }); emit({ stage: 'step', step, tools: tools.map(tool => tool.name), runId }) }
        if (stopped()) session.abort()
      })
      try {
        if (!stopped()) await session.prompt(typeof buildUserMessage === 'function' ? buildUserMessage({ question, envelope }) : question)
        const last = session.state.messages.filter(message => message.role === 'assistant').at(-1)
        const kind = stopped() ? 'stopped' : 'final'
        return { protocol: 'pi-native', kind, text: textOf(last?.content), steps, calls, dropped: [], stoppedAt: step, usage: usageOf(tally) }
      } catch (error) {
        if (!stopped()) throw error
        return { protocol: 'pi-native', kind: 'stopped', text: '', steps, calls, dropped: [], stoppedAt: step, usage: usageOf(tally) }
      } finally { await session.close() }
    }
  }
}
