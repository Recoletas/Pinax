export const EXTERNAL_WRITE_HINT = /_(save|write|import|delete|create|update)$/u

export function isExternalWriteToolName(name) {
  return EXTERNAL_WRITE_HINT.test(String(name ?? '').trim())
}

/** 工具是否显式声明了读／写（annotations 的 readOnlyHint 或 destructiveHint 至少一个为布尔）。 */
export function hasWriteDeclaration(annotations) {
  if (!annotations || typeof annotations !== 'object') return false
  return typeof annotations.readOnlyHint === 'boolean' || typeof annotations.destructiveHint === 'boolean'
}

