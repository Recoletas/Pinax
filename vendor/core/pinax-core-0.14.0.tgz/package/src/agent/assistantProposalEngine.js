import { applyEntryDetails, entryDetailsSnapshot } from './assistantEntryDetails.js'
import { validateAssistantChanges, reserveAssistantCreateIds } from './assistantEditProposal.js'

// Document representation and character projections belong to the host. No Vue/editor imports.
export function createAssistantProposalEngine({ documents, parseCharacterEntryProfile, now = () => new Date().toISOString(), timestamp = () => Date.now(), idFactory } = {}) {
  const { mergeWritingDocumentFromMarkdown, getChapterMarkdown, getWritingBlockAtPosition, getWritingDocumentNodes, createWritingDocument } = documents || {}
  if ([mergeWritingDocumentFromMarkdown, getChapterMarkdown, getWritingBlockAtPosition, getWritingDocumentNodes, createWritingDocument, parseCharacterEntryProfile, idFactory].some(fn => typeof fn !== 'function')) throw new TypeError('Proposal engine requires document, character and identity adapters')
const clone = value => JSON.parse(JSON.stringify(value))
const valueOf = (target, change) => change.kind === 'chapter' && change.field === 'content' ? getChapterMarkdown(target) : String(target?.[change.field] || '')
function listOf(book, worldbook, kind) { return kind === 'chapter' ? book.chapters : kind === 'outline' ? (book.outlineNodes ||= []) : worldbook?.entries || [] }
function prepareAssistantProposal(input, { book, worldbook, runId }) {
  const changes = reserveAssistantCreateIds(validateAssistantChanges(input), { chapter: book.chapters || [], worldbook: worldbook?.entries || [], outline: book.outlineNodes || [] }, { idFactory })
  const worldIds = new Set([...(worldbook?.entries || []).map(entry => String(entry.id)), ...changes.filter(change => change.kind === 'worldbook' && change.operation === 'create').map(change => change.targetId)])
  for (const change of changes) if (change.details?.relations?.some(row => !worldIds.has(row.to))) throw new Error('关系目标不在本书设定中，请先查阅或新建对应条目。')
  const ranges = new Map()
  const prepared = changes.map((change, index) => {
    const key = `${change.kind}:${change.targetId}:${change.field}`
    if (change.kind === 'worldbook' && !worldbook && book.worldbookId) throw new Error('绑定的资料库尚未读取。')
    const list = listOf(book, worldbook, change.kind)
    if (!Array.isArray(list)) throw new Error('目标资料库尚未关联。')
    const target = list.find(item => String(item.id) === change.targetId)
    const identity = { changeId: `change-${index + 1}`, status: 'pending', groupId: change.groupId || `change-${index + 1}` }
    if (change.operation === 'create') {
      if (target || preparedTargetExists(changes, change, index)) throw new Error('新建条目 ID 已存在或重复。')
      return { ...change, ...identity, label: change.title, baseline: null }
    }
    if (!target) throw new Error('修改目标已不存在。')
    const baseline = valueOf(target, change)
    const sourceStart = baseline.indexOf(change.before)
    const from = change.operation === 'append' ? baseline.length : change.operation === 'insert' ? sourceStart + change.before.length : sourceStart
    if (change.operation !== 'append' && (sourceStart < 0 || sourceStart !== baseline.lastIndexOf(change.before))) throw new Error('修改原文不存在或有多处相同文字，请重新定位。')
    const to = ['append', 'insert'].includes(change.operation) ? from : from + change.before.length
    const previous = ranges.get(key) || []
    if (previous.some(range => from < range.to && to > range.from || from === range.from)) throw new Error('同一字段的修改重叠，请合并后提交。')
    previous.push({ from, to }); ranges.set(key, previous)
    // Surrounding text protects location while permitting unrelated edits elsewhere.
    const sourceNode = change.kind === 'chapter' && target.editorDocument ? getWritingBlockAtPosition(target.editorDocument, from) : null
    const anchor = { from, to, nodeId: sourceNode?.nodeId || '', unitId: sourceNode?.unitId || '', prefix: baseline.slice(Math.max(0, from - 48), from), suffix: baseline.slice(to, to + 48) }
    return { ...change, ...identity, ...(change.kind === 'worldbook' ? { entryType: target.type || change.entryType } : {}), ...(change.details ? { detailsBaseline: entryDetailsSnapshot(target) } : {}), label: target.name || target.title || change.targetId, baseline, anchor }
  })
  for (const change of prepared) if ((change.dependsOn || []).some(id => !prepared.some(item => item.changeId === id) || id === change.changeId)) throw new Error('修改依赖不存在。')
  return { schemaVersion: 2, id: `${runId}:edit`, runId, bookId: String(book.id), worldbookId: String(book.worldbookId || ''), status: 'pending', changes: prepared }
}
function preparedTargetExists(changes, change, index) { return changes.slice(0, index).some(item => item.kind === change.kind && item.targetId === change.targetId && item.operation === 'create') }
function selectAssistantProposalChanges(proposal, changeIds, discard = false) {
  const pending = proposal.changes.filter(change => !change.status || change.status === 'pending')
  const selected = changeIds ? pending.filter(change => changeIds.includes(change.changeId)) : pending
  if (!selected.length) throw new Error('修改已处理或不存在。')
  const groups = new Set(selected.map(change => change.groupId))
  const expanded = changeIds ? selected : pending.filter(change => groups.has(change.groupId))
  for (const change of expanded) if (!discard && ((change.dependsOn || []).some(id => !expanded.some(item => item.changeId === id) && !proposal.changes.some(item => item.changeId === id && item.status === 'adopted')))) throw new Error('请先采用关联修改，或一起采用。')
  return expanded
}
function locateTextChange(before, change) {
  const needle = change.anchor.prefix + (change.operation === 'insert' ? '' : change.before) + change.anchor.suffix
  const index = before.indexOf(needle)
  if (needle && index >= 0 && index === before.lastIndexOf(needle)) return index + change.anchor.prefix.length
  // Adjacent edits may change context without changing the selected text.
  // Inserts still require context: an empty range is never a unique match.
  if (change.operation !== 'insert' && change.before) {
    const exact = before.indexOf(change.before)
    if (exact >= 0 && exact === before.lastIndexOf(change.before)) return exact
  }
  throw new Error('修改原文已变化或有多处相同文字，建议已保留。')
}
function applyTextChange(before, change) {
  if (!change.anchor) {
    if (before !== change.baseline) throw new Error('目标内容已修改，建议已保留，请重新定位。')
    return change.operation === 'append' ? `${before}${before ? '\n\n' : ''}${change.after}` : before.replace(change.before, () => change.after)
  }
  if (change.operation === 'append') {
    const tail = change.anchor.prefix
    if (before !== change.baseline && (!tail || !before.endsWith(tail))) throw new Error('原落笔位置已变化，请重新定位。')
    return `${before}${before ? '\n\n' : ''}${change.after}`
  }
  const start = locateTextChange(before, change)
  return before.slice(0, start) + change.after + before.slice(start + (change.operation === 'insert' ? 0 : change.before.length))
}

function applyAssistantProposal(proposal, { book, worldbook, undo = false, discard = false, changeIds = null }) {
  if (discard) {
    if (String(book?.id) !== proposal.bookId) throw new Error('作品已切换。')
    const selected = selectAssistantProposalChanges(proposal, changeIds, true)
    const ids = new Set(selected.map(change => change.changeId))
    const proposalChanges = proposal.changes.map(change => ids.has(change.changeId) ? { ...change, status: 'discarded' } : { ...change })
    const pending = proposalChanges.some(change => !change.status || change.status === 'pending')
    const adopted = proposalChanges.some(change => change.status === 'adopted')
    return { book, worldbook, changes: [], proposalChanges, status: pending ? adopted ? 'partial' : 'pending' : adopted ? 'adopted' : 'discarded', protectionSnapshots: [] }
  }
  const expectedWorldbook = proposal.receipt?.worldbookId ?? proposal.worldbookId
  const assistantCreatedBinding = !expectedWorldbook && String(book?.worldbookId || '') === `assistant-world-${book.id}` && String(worldbook?.id) === String(book.worldbookId)
  if (String(book?.id) !== proposal.bookId || String(book?.worldbookId || '') !== expectedWorldbook && !assistantCreatedBinding) throw new Error('作品或关联资料库已变化。')
  const nextBook = clone(book); let nextWorldbook = worldbook ? clone(worldbook) : null
  const selected = undo ? [] : selectAssistantProposalChanges(proposal, changeIds, discard)
  const createdWorldbook = !undo && !discard && !nextWorldbook && !book.worldbookId && selected.some(change => change.kind === 'worldbook' && change.operation === 'create')
  if (createdWorldbook) {
    nextWorldbook = { id: `assistant-world-${book.id}`, name: book.title || '作品资料库', entries: [], sourceDocuments: [], groups: [], createdAt: timestamp(), updatedAt: timestamp() }
    nextBook.worldbookId = nextWorldbook.id
  }
  const receipts = []
  const changes = undo ? [...proposal.receipt.changes].filter(change => !changeIds || changeIds.includes(change.changeId)).reverse() : discard ? [] : selected
  if (undo && !changes.length) throw new Error('所选分类没有可撤销的修改。')
  if (undo && proposal.changes.some(change => change.status === 'adopted' && !changes.some(selected => selected.changeId === change.changeId) && change.dependsOn?.some(id => changes.some(selected => selected.changeId === id)))) throw new Error('其他已采纳修改依赖这一分类，请先撤销关联分类或使用全部撤销。')
  const placements = new Map()
  const alreadyApplied = new Set()
  if (!undo && !discard) for (const change of changes.filter(item => item.operation !== 'create')) {
    const target = listOf(book, worldbook, change.kind)?.find(item => String(item.id) === change.targetId)
    if (!target) throw new Error(`${change.label || change.targetId}：修改目标已不存在。`)
    const original = valueOf(target, change)
    const detailsApplied = !change.details || (() => { const updated = clone(target); applyEntryDetails(updated, change.details); return entryDetailsSnapshot(updated) === entryDetailsSnapshot(target) })()
    if (original === applyTextChange(change.baseline, change) && detailsApplied) { alreadyApplied.add(change.changeId); continue }
    if (change.anchor?.nodeId && target?.editorDocument && !getWritingDocumentNodes(target.editorDocument).some(item => item.node.attrs.nodeId === change.anchor.nodeId)) throw new Error('原段落已删除，请重新定位。')
    if (change.details && entryDetailsSnapshot(target) !== change.detailsBaseline) throw new Error('条目属性已变化，请重新生成修改。')
    try { applyTextChange(original, change) } // Validate against the original field before changing it.
    catch (error) { throw new Error(`${change.label || change.targetId}：${error.message}`) }
    placements.set(change.changeId, change.operation === 'append' ? original.length : change.anchor ? locateTextChange(original, change) : original.indexOf(change.before))
  }
  for (const change of changes) {
    if (alreadyApplied.has(change.changeId)) continue
    const list = listOf(nextBook, nextWorldbook, change.kind)
    if (!Array.isArray(list)) throw new Error('目标资料库尚未关联。')
    const target = list.find(item => String(item.id) === change.targetId)
    if (undo && change.created) {
      if (!target || JSON.stringify(target) !== change.afterEntity) throw new Error('新建内容已被修改，无法直接撤销。')
      list.splice(list.indexOf(target), 1); continue
    }
    if (!undo && change.operation === 'create') {
      if (target) {
        const updated = clone(target); applyEntryDetails(updated, change.details)
        const title = change.kind === 'worldbook' ? target.name : target.title
        if (title === change.title && valueOf(target, change) === change.after && (change.kind !== 'worldbook' || target.type === change.entryType) && entryDetailsSnapshot(updated) === entryDetailsSnapshot(target)) continue
        throw new Error(`${change.label || change.title || change.targetId}：同 ID 条目已存在且内容不同，未覆盖。`)
      }
      const created = { id: change.targetId, ...(change.kind === 'worldbook' ? { type: change.entryType, name: change.title, content: '' } : { title: change.title, content: '' }) }
      assign(created, change, change.after)
      applyEntryDetails(created, change.details)
      list.push(created); receipts.push({ ...change, created: true, afterEntity: JSON.stringify(created) }); continue
    }
    if (!target) throw new Error('修改目标已不存在。')
    const before = valueOf(target, change)
    const beforeEditorDocument = change.kind === 'chapter' && change.field === 'content' ? clone(target.editorDocument || null) : undefined
    if (undo && before !== change.applied) throw new Error('目标内容已修改，无法直接撤销，请手动调整。')
    let after = change.baseline
    if (!undo) {
      let position = placements.get(change.changeId)
      const originalPosition = position
      for (const applied of receipts.filter(item => item.kind === change.kind && item.targetId === change.targetId && item.field === change.field && placements.get(item.changeId) < originalPosition)) {
        position += applied.after.length - (applied.operation === 'insert' ? 0 : applied.before.length)
      }
      after = change.operation === 'append' ? `${before}${before ? '\n\n' : ''}${change.after}` : before.slice(0, position) + change.after + before.slice(position + (change.operation === 'insert' ? 0 : change.before.length))
    }
    const characterContent = change.kind === 'worldbook' && target.type === 'character' && change.field === 'content'
    const hadCharacterProfile = Object.hasOwn(target.metadata || {}, 'characterProfile')
    const beforeCharacterProfile = hadCharacterProfile ? clone(target.metadata.characterProfile) : null
    if (undo && characterContent && change.appliedCharacterProfile && JSON.stringify(target.metadata?.characterProfile) !== change.appliedCharacterProfile) throw new Error('人物资料已被修改，无法直接撤销。')
    const beforeDetails = change.details ? entryDetailsSnapshot(target) : null
    if (undo && change.details && beforeDetails !== change.appliedDetails) throw new Error('条目属性已变化，不能直接撤销。')
    assign(target, change, after)
    if (change.details) {
      if (undo) {
        for (const key of ['aliases', 'profile', 'relations', 'links', 'sourceRefs']) delete target[key]
        Object.assign(target, JSON.parse(change.beforeDetails))
      } else applyEntryDetails(target, change.details)
    }
    if (undo && Object.hasOwn(change, 'beforeEditorDocument')) {
      if (change.beforeEditorDocument) target.editorDocument = { ...clone(change.beforeEditorDocument), revision: Number(target.editorDocument?.revision || 0) + 1 }
      else delete target.editorDocument
    }
    if (characterContent) {
      target.metadata ||= {}
      const input = { ...target, metadata: { ...target.metadata } }; delete input.metadata.characterProfile
      const parsed = parseCharacterEntryProfile(input)
      const labels = { background: '背景', personality: '性格', appearance: '外貌', identity: '身份', gender: '性别', age: '年龄', goal: '目标', relation: '关系', openingState: '开场状态', other: '其他' }
      target.metadata.characterProfile = { ...(target.metadata.characterProfile || {}), ...Object.fromEntries(Object.entries(parsed).filter(([key, value]) => value || (labels[key] && target.content.includes(`${labels[key]}：`)))) }
      if (undo) {
        if (change.hadCharacterProfile) target.metadata.characterProfile = clone(change.beforeCharacterProfile)
        else delete target.metadata.characterProfile
      }
    }
    receipts.push({ ...change, ...(change.details ? { beforeDetails, appliedDetails: entryDetailsSnapshot(target) } : {}), ...(beforeEditorDocument !== undefined ? { beforeEditorDocument } : {}), baseline: before, applied: valueOf(target, change), ...(characterContent ? { hadCharacterProfile, beforeCharacterProfile, appliedCharacterProfile: JSON.stringify(target.metadata.characterProfile) } : {}) })
  }
  if (undo && changes.some(change => change.kind === 'worldbook') && proposal.receipt.createdWorldbook && !nextWorldbook.entries.length && !(nextWorldbook.sourceDocuments || []).length) { nextBook.worldbookId = ''; nextWorldbook = null }
  if (nextWorldbook) nextWorldbook.entriesMap = Object.fromEntries(nextWorldbook.entries.map(entry => [entry.id, entry]))
  nextBook.updatedAt = now()
  if (nextWorldbook && changes.some(change => change.kind === 'worldbook')) nextWorldbook.updatedAt = Math.max(timestamp(), Number(worldbook?.updatedAt || 0) + 1)
  const handled = new Set((undo ? changes : selected).map(change => change.changeId))
  const proposalChanges = proposal.changes.map(change => handled.has(change.changeId) ? { ...change, status: undo ? 'undone' : discard ? 'discarded' : 'adopted' } : { ...change })
  // Partial adoption advances anchors using the recorded positions, never by guessing a repeated fragment.
  if (!undo && !discard) for (const remaining of proposalChanges.filter(change => change.status === 'pending' && change.anchor)) {
    const originalTarget = listOf(book, worldbook, remaining.kind)?.find(item => String(item.id) === remaining.targetId)
    const originalText = valueOf(originalTarget, remaining)
    const originalNeedle = remaining.anchor.prefix + (remaining.operation === 'insert' ? '' : remaining.before) + remaining.anchor.suffix
    const originalIndex = originalText.indexOf(originalNeedle)
    if (remaining.operation !== 'append' && (originalIndex < 0 || originalIndex !== originalText.lastIndexOf(originalNeedle))) continue
    let position = remaining.operation === 'append' ? originalText.length : originalIndex + remaining.anchor.prefix.length
    for (const applied of selected.filter(change => change.kind === remaining.kind && change.targetId === remaining.targetId && change.field === remaining.field && placements.get(change.changeId) + (change.operation === 'insert' ? 0 : change.before.length) <= (remaining.operation === 'append' ? originalText.length : originalIndex + remaining.anchor.prefix.length))) {
      position += applied.operation === 'append' ? applied.after.length + 2 : applied.after.length - (applied.operation === 'insert' ? 0 : applied.before.length)
    }
    const target = listOf(nextBook, nextWorldbook, remaining.kind)?.find(item => String(item.id) === remaining.targetId)
    const baseline = valueOf(target, remaining)
    if (remaining.operation === 'append') position = baseline.length
    if (!['append', 'insert'].includes(remaining.operation) && baseline.slice(position, position + remaining.before.length) !== remaining.before) continue
    remaining.baseline = baseline
    const to = position + (remaining.operation === 'insert' ? 0 : remaining.before.length)
    remaining.anchor = { ...remaining.anchor, from: position, to, prefix: baseline.slice(Math.max(0, position - 48), position), suffix: baseline.slice(to, to + 48) }
  }
  const hasAdopted = proposalChanges.some(change => change.status === 'adopted')
  const status = proposalChanges.some(change => !change.status || change.status === 'pending') ? (hasAdopted ? 'partial' : 'pending') : hasAdopted ? 'adopted' : undo ? 'undone' : 'discarded'
  const protectionSnapshots = undo || discard ? [] : [...new Set(selected.filter(change => change.kind === 'chapter' && change.operation !== 'create').map(change => change.targetId))].map(id => { const chapter = book.chapters.find(item => String(item.id) === id); return { chapterId: id, chapterTitle: chapter.title || '', document: clone(chapter.editorDocument || createWritingDocument(getChapterMarkdown(chapter))), markdown: getChapterMarkdown(chapter), annotations: clone(chapter.annotations || []) } })
  return { book: nextBook, worldbook: nextWorldbook, changes: receipts, createdWorldbook, proposalChanges, status, protectionSnapshots }
}
function assign(target, change, value) {
  target[change.field] = value
  if (change.kind === 'chapter' && change.field === 'content') {
    const previous = target.editorDocument
    target.editorDocument = mergeWritingDocumentFromMarkdown(value, previous)
    target.editorDocument.revision = Number(previous?.revision || 0) + 1
    target.wordCount = value.length
  }
}

  return Object.freeze({ prepareAssistantProposal, selectAssistantProposalChanges, applyAssistantProposal })
}
