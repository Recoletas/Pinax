import { ok, fail } from '../contracts/result.js'

// Storage adapters own key layout and synchronously durable local writes.
// Commands carry the same project/entity/revision/operation identity on every host.
export function createProjectTransactionService({ journal, read, keyOf, operationKeyOf, hashText, revisionOf = value => value?.revision ?? 0 } = {}) {
  if (!journal?.commit || [read, keyOf, operationKeyOf, hashText, revisionOf].some(fn => typeof fn !== 'function')) throw new TypeError('Transaction adapters are required')
  const identity = value => typeof value === 'string' && value.trim() && !/[\u0000-\u001f]/.test(value)
  function commit(command) {
    if (!identity(command?.projectId) || !identity(command?.operationId) || !Array.isArray(command.writes) || !command.writes.length) return fail('INVALID_INPUT', 'Transaction identity and writes are required')
    try {
      journal.recover()
      const operationKey = operationKeyOf(command.projectId, command.operationId)
      const fingerprint = hashText(JSON.stringify(command))
      const previous = read(operationKey, null)
      if (previous) return previous.fingerprint === fingerprint ? ok(previous) : fail('OPERATION_CONFLICT', 'Operation ID already belongs to a different command')
      const writes = [], entities = []
      for (const item of command.writes) {
        if (!identity(item.entityType) || !identity(item.entityId) || !Number.isSafeInteger(item.expectedRevision) || item.expectedRevision < 0 || !item.after || typeof item.after !== 'object' || Array.isArray(item.after)) return fail('INVALID_INPUT', 'Invalid entity mutation')
        const key = keyOf(command.projectId, item.entityType, item.entityId)
        if (typeof key !== 'string' || !key || key === operationKey || writes.some(write => write.key === key)) return fail('INVALID_INPUT', 'Transaction targets overlap')
        const current = read(key, null)
        const actual = revisionOf(current)
        if (actual !== item.expectedRevision) return fail('STALE_REVISION', 'Entity revision changed', { entityId: item.entityId, expected: item.expectedRevision, actual })
        const revision = actual + 1
        if (!Number.isSafeInteger(revision)) return fail('INVALID_INPUT', 'Entity revision overflow')
        const after = { ...item.after, revision }
        writes.push({ key, expected: current, after })
        entities.push({ entityType: item.entityType, entityId: item.entityId, revision })
      }
      const receipt = { projectId: command.projectId, operationId: command.operationId, fingerprint, entities, committed: true }
      journal.commit([...writes, { key: operationKey, expected: null, after: receipt }], command.operationId)
      return ok(receipt)
    } catch (error) { return fail('IO_FAILED', String(error?.message || error)) }
  }
  return Object.freeze({ commit })
}

// Native hosts can persist a local journal then flush it to their durable store.
// A failed flush is pending persistence; retry the SAME operation before reporting success.
export function createDurableTransactionService({ local, flush } = {}) {
  if (!local?.commit || typeof flush !== 'function') throw new TypeError('Local transaction and flush adapters are required')
  let pending = Promise.resolve()
  return Object.freeze({ commit(command) {
    const execute = async () => {
      const committed = local.commit(command)
      if (!committed.ok) return committed
      try {
        const result = await flush(committed.value)
        if (result !== true && result?.ok !== true) return fail('PERSISTENCE_PENDING', 'Durable commit not confirmed', committed.value)
        return ok({ ...committed.value, durable: true })
      } catch (error) { return fail('PERSISTENCE_PENDING', String(error?.message || error), committed.value) }
    }
    const result = pending.then(execute)
    pending = result.then(() => undefined, () => undefined)
    return result
  } })
}
