/** Shared entry edit semantics; persistence, fingerprints and place projection remain in their Host owners. */
export function createWorldbookEntryEditor({ parseCharacterProfile, normalizeVoice, userTouchedKey, now = Date.now } = {}) {
  if (typeof parseCharacterProfile !== 'function' || typeof normalizeVoice !== 'function' || !userTouchedKey) {
    throw new TypeError('Worldbook entry editor requires profile, voice and userTouched adapters')
  }
  return function editEntry(entry, updates, entryId = entry.id) {
      // A1.3 守卫：structured entry 被用户编辑了「sync 会覆盖的字段」
      // (name/type/injection) 时，标记 userTouched，避免后续 reload 被静默还原。
      const isStructuredEntry = entry.metadata?.importSource === 'structured-setting' ||
        Boolean(entry.metadata?.structuredSettingRef)
      const isStructuredCharacterCard = Boolean(entry.metadata?.structuredCharacterKey)
      const touchedByUser = isStructuredEntry && (
        Object.prototype.hasOwnProperty.call(updates, 'name') ||
        Object.prototype.hasOwnProperty.call(updates, 'type') ||
        Object.prototype.hasOwnProperty.call(updates, 'injection') ||
        (isStructuredCharacterCard && (
          Object.prototype.hasOwnProperty.call(updates, 'content') ||
          Object.prototype.hasOwnProperty.call(updates?.metadata || {}, 'characterProfile')
        ))
      )
      let updatedBase = {
        ...entry,
        ...updates,
        id: entryId, // 不可更改
        metadata: {
          ...entry.metadata,
          ...(updates.metadata && typeof updates.metadata === 'object' ? updates.metadata : {}),
          updatedAt: now(),
          ...(touchedByUser ? { [userTouchedKey]: true } : {})
        }
      }
      if (
        String(updatedBase.type || '').trim().toLowerCase() === 'character' &&
        Object.prototype.hasOwnProperty.call(updates, 'content') &&
        !Object.prototype.hasOwnProperty.call(updates?.metadata || {}, 'characterProfile')
      ) {
        updatedBase = {
          ...updatedBase,
          metadata: {
            ...updatedBase.metadata,
            characterProfile: parseCharacterProfile({
              ...updatedBase,
              metadata: { ...updatedBase.metadata, characterProfile: null }
            })
          }
        }
      }

      return normalizeVoice(updatedBase)
  }
}
