import { worldClaimQualifiers } from './worldClaimPresentation.js'
import { prepareEdition, storeEdition, editionAnchor } from './manuscriptEdition.js'
import { encodeScopeKey, normalizeScopeRef } from './ledgerContract.js'
import { legacyWorldClaimForVersion } from './worldClaims.js'
import { loadCalendarAt, normalizeStoryClock } from './worldCalendars.js'
import { knowledgeBasis } from './knowledgeReplay.js'
import { isVisibleAt } from './recordAxis.js'
import { recordPassageEvidence, validQuotedAnchor } from './manuscriptEvidence.js'

const disclosureKinds = ['narrator-assertion', 'reported-speech']
const useKinds = ['assertion-use', 'belief-use', 'constraint-use']
const requiresFact = kind => ['narrator-assertion', 'assertion-use'].includes(kind)
const unknown = () => ({ ok: true, status: 'unknown', items: [] })
const fail = reason => ({ ok: false, reason, items: [] })
const atUnit = (a, b) => a.bookId === b.bookId && a.chapterId === b.chapterId && a.unitId === b.unitId

const validSpeaker = speaker => typeof speaker?.entityRef === 'string' && speaker.entityRef.trim() &&
  typeof speaker.label === 'string' && speaker.label.trim()
const speakerRef = speaker => ({ entityRef: speaker.entityRef.trim(), label: speaker.label.trim() })

function scopeForBook(input, bookId) {
  const resolved = normalizeScopeRef(input)
  if (!resolved.ok || !['book', 'session'].includes(resolved.scope.domain) || resolved.scope.bookId !== bookId) return fail('manuscript-scope-mismatch')
  return { ...resolved, scopeKey: encodeScopeKey(resolved.scope) }
}

async function readBasis(db, scopeKey, claimId, { actorKey, storyAt, storyClock }, recordedSeq) {
  const events = await db.table('knowledgeEvents').where('[scopeKey+claimId]').equals([scopeKey, claimId])
    .filter(row => row.actorKey === actorKey && (recordedSeq == null || (row.visibleFromSeq ?? row.recordedSeq) <= recordedSeq)).toArray()
  const clock = normalizeStoryClock(storyClock)
  const calendar = clock && await loadCalendarAt(db, scopeKey, clock.timelineId, recordedSeq)
  if (!calendar?.eras.some(era => era.id === clock.eraId)) return { incomparable: true }
  return knowledgeBasis(events, { actorKey, claimId, storyAt, recordedSeq, storyClock: clock, calendar })
}

async function checkBeliefUse(db, row, recordedSeq) {
  if (!row.beliefUse) return null
  const current = await readBasis(db, row.scopeKey, row.claimId, row.beliefUse, recordedSeq)
  const expected = row.beliefUse.basis
  if (!current) return 'unaware'
  if (current.incomparable) return 'incomparable'
  if (current.dateUnknown) return 'date-unknown'
  if (current.belief === 'forgotten') return 'forgotten'
  return current.belief !== expected.belief || current.channel !== expected.channel ||
    current.speakerKey !== expected.speakerKey ? 'knowledge-changed' : null
}

export function createWorldManuscriptModule({ ledgerId, runWorldCommand }) {
  async function recordManuscriptLink(db, input) {
    const { scope, commandId, claimId, kind, manuscriptAnchor, quote, useId = null } = input
    if (!validQuotedAnchor(manuscriptAnchor, quote)) return fail('manuscript-anchor-invalid')
    const resolved = scopeForBook(scope, manuscriptAnchor.bookId)
    if (!resolved.ok) return resolved
    const prepared = input.editionChapters ? prepareEdition(resolved.scope, input.editionChapters) : null
    if (prepared) {
      if (!prepared.ok) return fail(prepared.reason)
      const source = editionAnchor({ chapters: input.editionChapters }, manuscriptAnchor.chapterId, manuscriptAnchor.unitId)
      if (!source || source.unitHash !== manuscriptAnchor.unitHash || source.orderRevision !== manuscriptAnchor.orderRevision) return fail('manuscript-edition-invalid')
    }
    const disclosure = disclosureKinds.includes(kind)
    if (!disclosure && !useKinds.includes(kind)) return fail('manuscript-link-kind-invalid')
    if (useId && disclosure) return fail('manuscript-use-invalid')
    const expectedVersionId = input.factVersionId || null
    if (requiresFact(kind) && !expectedVersionId) return fail('confirmed-fact-required')
    const payload = { action: 'record-manuscript-link', claimId, kind, expectedVersionId, manuscriptAnchor, useId }
    if (input.speaker != null) {
      if (kind !== 'reported-speech' || !validSpeaker(input.speaker)) return fail('disclosure-speaker-invalid')
      payload.speaker = speakerRef(input.speaker)
    }
    if (input.beliefUse != null) {
      const { actorKey, actorLabel, storyAt } = input.beliefUse
      if (kind !== 'belief-use' || typeof actorKey !== 'string' || !actorKey.trim() || !Number.isSafeInteger(storyAt)) return fail('belief-use-invalid')
      const clock = normalizeStoryClock(input.beliefUse.storyClock)
      if (!clock) return fail('story-clock-invalid')
      payload.beliefUse = { actorKey, ...(clock.timelineId !== 'default' ? { storyClock: clock } : {}), actorLabel: typeof actorLabel === 'string' && actorLabel.trim() ? actorLabel.trim() : actorKey, storyAt }
    }
    return runWorldCommand(db, resolved.scope, commandId, payload, async ({ tables, scope, scopeKey, seq }) => {
      const claim = await tables.claims.get(claimId)
      if (!claim || claim.scopeKey !== scopeKey) return fail('claim-scope-mismatch')
      if (expectedVersionId) {
        const version = await tables.versions.get(expectedVersionId)
        if (version?.scopeKey !== scopeKey || version.claimId !== claimId || !isVisibleAt(version) || version.supersedesKind) return fail('fact-version-changed')
      }
      const table = db.table(disclosure ? 'disclosures' : 'claimUses')
      const { chapterId, unitId } = manuscriptAnchor
      const previous = useId && await table.get(useId)
      if (useId && (!previous || previous.scopeKey !== scopeKey || previous.kind !== kind || !atUnit(previous.manuscriptAnchor, manuscriptAnchor) || !isVisibleAt(previous))) return fail('manuscript-use-changed')
      const reference = payload.beliefUse ?? previous?.beliefUse
      let beliefUse = null
      if (reference) {
        const { actorKey, actorLabel, storyAt } = reference
        const basis = await readBasis(db, scopeKey, claimId, reference, seq)
        if (basis?.incomparable) return fail('belief-use-incomparable')
        if (basis?.dateUnknown) return fail('belief-use-date-unknown')
        if (!basis || basis.belief === 'forgotten') return fail('belief-use-unavailable')
        beliefUse = { basisVersion: 2, actorKey, actorLabel, storyAt, ...(reference.storyClock ? { storyClock: reference.storyClock } : {}), basis }
      }
      const existing = await table.where('[scopeKey+chapterId]').equals([scopeKey, chapterId]).toArray()
      const matching = existing.filter(row => isVisibleAt(row) && row.kind === kind && row.claimId === claimId &&
        row.manuscriptAnchor.unitId === unitId && row.speaker?.entityRef === payload.speaker?.entityRef && row.beliefUse?.actorKey === beliefUse?.actorKey && row.beliefUse?.storyAt === beliefUse?.storyAt &&
        row.beliefUse?.storyClock?.timelineId === beliefUse?.storyClock?.timelineId && row.beliefUse?.storyClock?.eraId === beliefUse?.storyClock?.eraId)
      const same = matching.find(row => (!prepared || row.manuscriptEditionId) && row.manuscriptAnchor.unitHash === manuscriptAnchor.unitHash &&
        row.manuscriptAnchor.orderRevision === manuscriptAnchor.orderRevision && row.expectedVersionId === expectedVersionId &&
        row.beliefUse?.basis.observationId === beliefUse?.basis.observationId && row.beliefUse?.basis.attitudeId === beliefUse?.basis.attitudeId)
      const beforeIds = [...new Set([...matching.map(row => row.id), ...(previous ? [previous.id] : [])])].filter(id => id !== same?.id)
      for (const id of beforeIds) await table.update(id, { invalidatedSeq: seq })
      if (prepared) await storeEdition(db, prepared, { scope, seq })
      let linkId = same?.id
      if (!linkId) {
        const evidence = await recordPassageEvidence(tables.evidence, { scope, scopeKey, manuscriptAnchor, quote, ledgerId })
        linkId = ledgerId(disclosure ? 'disclosure' : 'use')
        await table.add({ id: linkId, scopeKey, scope, claimId, expectedVersionId, kind, chapterId,
          manuscriptAnchor, ...(payload.speaker ? { speaker: payload.speaker } : {}), ...(beliefUse ? { beliefUse } : {}), ...(prepared ? { manuscriptEditionId: prepared.edition.id } : {}), evidenceIds: [evidence.id], recordedSeq: seq, invalidatedSeq: null })
      }
      return { operation: useId ? 'review-manuscript-use' : 'record-' + kind, beforeIds, afterIds: [linkId], result: { linkId, ...(prepared ? { manuscriptEditionId: prepared.edition.id } : {}) } }
    })
  }

  async function changeDisclosureSpeaker(db, { scope, bookId, disclosureId, speaker = null, commandId, matches }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    if (speaker !== null && !validSpeaker(speaker)) return fail('disclosure-speaker-invalid')
    const next = speaker && speakerRef(speaker)
    return runWorldCommand(db, resolved.scope, commandId, { action: 'change-disclosure-speaker', disclosureId, speaker: next }, async ({ seq, scopeKey }) => {
      const table = db.table('disclosures')
      const original = await table.get(disclosureId)
      if (original?.scopeKey !== scopeKey || original.kind !== 'reported-speech' || !isVisibleAt(original)) return fail('disclosure-changed')
      if (!matches(original.manuscriptAnchor)) return fail('manuscript-changed')
      if (original.speaker?.entityRef === next?.entityRef) return fail('no-change')
      const duplicate = await table.where('[scopeKey+claimId]').equals([scopeKey, original.claimId]).filter(row =>
        row.kind === original.kind && isVisibleAt(row) && atUnit(row.manuscriptAnchor, original.manuscriptAnchor) &&
        row.speaker?.entityRef === next?.entityRef).first()
      if (duplicate) return fail('disclosure-speaker-exists')
      const id = ledgerId('disclosure')
      const row = { ...original, id, recordedSeq: seq, supersedesDisclosureId: original.id, sourceRecordedSeq: original.sourceRecordedSeq ?? original.recordedSeq }
      if (next) row.speaker = next
      else delete row.speaker
      await table.update(original.id, { invalidatedSeq: seq })
      await table.add(row)
      return { operation: 'change-disclosure-speaker', beforeIds: [original.id], afterIds: [id], result: { linkId: id } }
    })
  }

  async function withdrawDisclosure(db, { scope, bookId, disclosureId, commandId, matches }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    return runWorldCommand(db, resolved.scope, commandId, { action: 'withdraw-reader-disclosure', disclosureId }, async ({ seq, scopeKey }) => {
      const table = db.table('disclosures')
      const row = await table.get(disclosureId)
      if (row?.scopeKey !== scopeKey || !isVisibleAt(row)) return fail('disclosure-changed')
      if (!matches(row.manuscriptAnchor)) return fail('manuscript-changed')
      await table.update(row.id, { invalidatedSeq: seq })
      return { operation: 'withdraw-reader-disclosure', beforeIds: [row.id], result: { withdrawnDisclosureId: row.id } }
    })
  }

  async function queryManuscript(db, { scope, bookId, chapterId, unitId, recordedSeq = null, positionOf }, reader) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    if (recordedSeq !== null && (!Number.isSafeInteger(recordedSeq) || recordedSeq < 0)) return fail('recorded-as-of-invalid')
    const table = db.table(reader ? 'disclosures' : 'claimUses')
    const { scopeKey } = resolved
    return db.transaction('r', [table, db.table('worldClaims'), db.table('factVersions'), db.table('manuscriptEditions'), db.table('manuscriptChapterRevisions'), ...(reader ? [db.table('evidenceSnapshots')] : [db.table('knowledgeEvents'), db.table('factDecisions')])], async () => {
      const rows = reader ? await table.where('scopeKey').equals(scopeKey).toArray()
        : await table.where('[scopeKey+chapterId]').equals([scopeKey, chapterId]).toArray()
      const items = []
      for (const row of rows.sort((a, b) => a.recordedSeq - b.recordedSeq)) {
        if (!isVisibleAt(row, recordedSeq)) continue
        if (!reader && row.manuscriptAnchor.unitId !== unitId) continue
        const position = await positionOf(row.manuscriptAnchor, row.manuscriptEditionId)
        if (reader && position === 'after-target') continue
        if (reader && !['before-target', 'at-target'].includes(position)) return unknown()
        const claim = await db.table('worldClaims').get(row.claimId)
        if (claim?.scopeKey !== scopeKey || (recordedSeq !== null && claim.recordedSeq > recordedSeq)) return unknown()
        const item = { id: row.id, subjectLabel: claim.subjectLabel, subjectKey: claim.subjectKey, predicate: claim.predicate, object: claim.object,
          ...worldClaimQualifiers(claim),
          ...(claim.eventContext ? { eventContext: claim.eventContext, eventLabels: claim.eventLabels } : {}) }
        if (reader) {
          const source = await db.table('evidenceSnapshots').get(row.evidenceIds[0])
          items.push({ ...item, claimId: row.claimId, disclosureKind: row.kind, quote: source?.scopeKey === scopeKey ? source.quote : null, chapterId: row.chapterId, unitId: row.manuscriptAnchor.unitId,
            ...(row.speaker ? { speaker: row.speaker } : {}) })
        } else {
          const version = row.expectedVersionId && await db.table('factVersions').get(row.expectedVersionId)
          const staleFact = row.kind !== 'belief-use' && row.expectedVersionId && (!version || !isVisibleAt(version, recordedSeq))
          const knowledgeIssue = await checkBeliefUse(db, row, recordedSeq)
          items.push({ ...item, kind: row.kind, claimId: row.claimId, ...(row.beliefUse ? { beliefUse: row.beliefUse, knowledgeIssue } : {}),
            needsReview: position !== 'at-target' || Boolean(staleFact || knowledgeIssue) })
        }
      }
      return { ok: true, status: 'ok', items }
    })
  }
  async function listAnchorIssues(db, { scope, bookId, matches }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    return db.transaction('r', ['worldClaims', 'disclosures', 'claimUses', 'evidenceSnapshots'], async () => {
      const items = []
      for (const table of ['disclosures', 'claimUses']) {
        const rows = await db.table(table).where('scopeKey').equals(resolved.scopeKey).toArray()
        for (const row of rows) {
          if (!isVisibleAt(row) || matches(row.manuscriptAnchor)) continue
          const claim = await db.table('worldClaims').get(row.claimId)
          const evidence = await db.table('evidenceSnapshots').get(row.evidenceIds[0])
          if (claim?.scopeKey === resolved.scopeKey) items.push({ id: row.id, kind: row.kind, chapterId: row.chapterId,
            unitId: row.manuscriptAnchor.unitId, quote: evidence?.scopeKey === resolved.scopeKey ? evidence.quote : '',
            subjectLabel: claim.subjectLabel, subjectKey: claim.subjectKey, predicate: claim.predicate, object: claim.object,
          ...worldClaimQualifiers(claim),
          ...(claim.eventContext ? { eventContext: claim.eventContext, eventLabels: claim.eventLabels } : {}) })
        }
      }
      return { ok: true, items }
    })
  }

  async function archiveAnchor(db, { scope, bookId, linkId, kind, commandId, matches }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    if (![...disclosureKinds, ...useKinds].includes(kind)) return fail('manuscript-link-kind-invalid')
    return runWorldCommand(db, resolved.scope, commandId, { action: 'archive-world-anchor', kind, linkId }, async ({ seq, scopeKey }) => {
      const table = db.table(disclosureKinds.includes(kind) ? 'disclosures' : 'claimUses')
      const row = await table.get(linkId)
      if (!row || row.kind !== kind || row.scopeKey !== scopeKey || !isVisibleAt(row) || matches(row.manuscriptAnchor)) return fail('manuscript-link-changed')
      await table.update(linkId, { invalidatedSeq: seq })
      return { operation: 'archive-world-anchor', beforeIds: [linkId], result: { linkId } }
    })
  }

  async function previewFactChange(db, { scope, bookId, factVersionId, matches }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    const { scopeKey } = resolved
    return db.transaction('r', ['factVersions', 'claimUses', 'evidenceSnapshots'], async () => {
      const version = await db.table('factVersions').get(factVersionId)
      if (version?.scopeKey !== scopeKey || !isVisibleAt(version) || version.supersedesKind) return fail('fact-version-changed')
      const uses = await db.table('claimUses').where('[scopeKey+expectedVersionId]').equals([scopeKey, factVersionId]).toArray()
      const items = []
      for (const row of uses) {
        if (!isVisibleAt(row) || row.kind === 'belief-use') continue
        const evidence = await db.table('evidenceSnapshots').get(row.evidenceIds[0])
        items.push({ id: row.id, kind: row.kind, chapterId: row.chapterId, unitId: row.manuscriptAnchor.unitId,
          quote: evidence?.scopeKey === scopeKey ? evidence.quote : '', needsReview: !matches(row.manuscriptAnchor) })
      }
      return { ok: true, items }
    })
  }
  async function listBeliefUseIssues(db, { scope, bookId }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    return db.transaction('r', ['claimUses', 'knowledgeEvents', 'evidenceSnapshots', 'factDecisions'], async () => {
      const rows = await db.table('claimUses').where('scopeKey').equals(resolved.scopeKey).filter(row => row.beliefUse && isVisibleAt(row)).toArray()
      const items = []
      for (const row of rows) {
        const issue = await checkBeliefUse(db, row, null)
        if (!issue) continue
        const evidence = await db.table('evidenceSnapshots').get(row.evidenceIds[0])
        items.push({ id: row.id, kind: row.kind, chapterId: row.chapterId, unitId: row.manuscriptAnchor.unitId,
          quote: evidence?.scopeKey === resolved.scopeKey ? evidence.quote : '', beliefUse: row.beliefUse, knowledgeIssue: issue })
      }
      return { ok: true, items }
    })
  }

  async function retireBeliefUse(db, { scope, bookId, useId, commandId }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    return runWorldCommand(db, resolved.scope, commandId, { action: 'retire-belief-use', useId }, async ({ scopeKey, seq }) => {
      const table = db.table('claimUses')
      const row = await table.get(useId)
      if (!row?.beliefUse || row.scopeKey !== scopeKey || !isVisibleAt(row) || !await checkBeliefUse(db, row, null)) return fail('manuscript-use-changed')
      await table.update(useId, { invalidatedSeq: seq })
      return { operation: 'retire-belief-use', beforeIds: [useId], afterIds: [], result: { useId } }
    })
  }
  async function listEventPassages(db, { scope, bookId, factVersionId, recordedSeq = null }) {
    const resolved = scopeForBook(scope, bookId)
    if (!resolved.ok) return resolved
    if (recordedSeq !== null && (!Number.isSafeInteger(recordedSeq) || recordedSeq < 0)) return fail('recorded-as-of-invalid')
    const { scopeKey } = resolved
    return db.transaction('r', ['factVersions', 'disclosures', 'claimUses', 'knowledgeEvents', 'evidenceSnapshots'], async () => {
      const versions = db.table('factVersions')
      const current = await versions.get(factVersionId)
      if (current?.scopeKey !== scopeKey || !isVisibleAt(current, recordedSeq) || current.supersedesKind ||
          (current.kind ?? legacyWorldClaimForVersion(current)?.kind) !== 'event') return fail('fact-version-changed')
      const history = await versions.where('[scopeKey+factKey]').equals([scopeKey, current.factKey]).toArray()
      const claims = [...new Set(history.filter(row => recordedSeq === null || (row.visibleFromSeq ?? row.recordedSeq) <= recordedSeq).map(row => row.claimId).filter(Boolean))]
      const keys = claims.map(id => [scopeKey, id])
      const rows = (await Promise.all(['disclosures', 'claimUses'].map(name =>
        db.table(name).where('[scopeKey+claimId]').anyOf(keys).toArray()))).flat().filter(row => isVisibleAt(row, recordedSeq))
      const observations = await db.table('knowledgeEvents').where('[scopeKey+claimId]').anyOf(keys)
        .filter(row => recordedSeq === null || (row.visibleFromSeq ?? row.recordedSeq) <= recordedSeq).toArray()
      const replaced = new Set(observations.map(row => row.supersedesEventId).filter(Boolean))
      for (const event of observations) {
        if (replaced.has(event.id) || !event.passage) continue
        const { manuscriptAnchor, evidenceId } = event.passage
        rows.push({ id: event.id, kind: event.kind === 'known' ? 'knowledge-source' : 'belief-source',
          actorLabel: event.actorLabel || event.actorKey, claimId: event.claimId, expectedVersionId: event.factVersionId,
          chapterId: manuscriptAnchor.chapterId, manuscriptAnchor, evidenceIds: [evidenceId] })
      }
      const evidence = await db.table('evidenceSnapshots').bulkGet(rows.map(row => row.evidenceIds[0]))
      return { ok: true, items: rows.map((row, i) => ({
        id: row.id, kind: row.kind, ...(row.speaker ? { speaker: row.speaker } : {}), ...(row.actorLabel ? { actorLabel: row.actorLabel } : {}), chapterId: row.chapterId, manuscriptAnchor: row.manuscriptAnchor,
        quote: evidence[i]?.scopeKey === scopeKey ? evidence[i].quote : '',
        historical: row.claimId !== current.claimId || Boolean(row.expectedVersionId && row.expectedVersionId !== current.id)
      })) }
    })
  }
  return { recordManuscriptLink, withdrawDisclosure, changeDisclosureSpeaker, listBeliefUseIssues, retireBeliefUse, listEventPassages, listAnchorIssues, archiveAnchor, previewFactChange,
    readReader: (db, input) => queryManuscript(db, input, true), readUses: (db, input) => queryManuscript(db, input, false) }
}
