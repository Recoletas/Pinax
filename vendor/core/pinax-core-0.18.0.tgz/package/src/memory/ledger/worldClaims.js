import {
  normalizeClaim, normalizeScopeRef, encodeScopeKey, resolvePredicateTemporalKind, worldClaimId
} from './ledgerContract.js'
import { isVisibleAt } from './recordAxis.js'

const kindByPolicy = { 'single-value-state': 'state', 'multi-value-relation': 'relation', event: 'event' }

export function normalizeWorldClaim(input, defaultOccurrenceId) {
  const normalized = normalizeClaim(input)
  if (!normalized.ok) return normalized
  if (input.kind != null && !['state', 'event', 'relation'].includes(input.kind)) return { ok: false, reason: 'claim-kind-invalid' }
  for (const key of ['objectRef', 'occurrenceId']) {
    if (input[key] != null && (typeof input[key] !== 'string' || !input[key].trim())) return { ok: false, reason: 'claim-invalid' }
  }
  const kind = kindByPolicy[resolvePredicateTemporalKind(normalized.claim.predicate, input.kind)]
  if (kind !== 'event' && input.occurrenceId != null) return { ok: false, reason: 'claim-occurrence-invalid' }
  const claim = { ...normalized.claim, kind }
  // Explicit references are opaque. Preserve case in structured subjects,
  // including identities submitted through the ordinary proposal workflow.
  if (input.kind || String(input.subjectKey).includes(':')) claim.subjectKey = String(input.subjectKey).trim()
  if (input.objectRef) claim.objectRef = input.objectRef.trim()
  if (kind === 'event') {
    claim.occurrenceId = input.occurrenceId?.trim() || defaultOccurrenceId
    if (!claim.occurrenceId) return { ok: false, reason: 'claim-occurrence-required' }
  }
  return { ok: true, claim }
}

export async function ensureWorldClaim(table, { scopeKey, scope, seq }, claim) {
  const id = worldClaimId(scopeKey, claim)
  if (!(await table.get(id))) {
    await table.add({ id, scopeKey, scope, ...claim, recordedSeq: seq })
  }
  return id
}

// v2 had no independent occurrence identity. An event from one historical
// fact chain stays one occurrence even if that chain contains corrections.
export function legacyWorldClaimForVersion(version) {
  const normalized = normalizeWorldClaim(version, 'legacy:' + version.factKey)
  if (!normalized.ok) throw new Error('历史事实的命题字段无效')
  const claim = normalized.claim
  claim.subjectKey = version.subjectKey
  return {
    id: worldClaimId(version.scopeKey, claim), scopeKey: version.scopeKey, scope: version.scope,
    ...claim, recordedSeq: version.recordedSeq
  }
}

// Used by the Dexie upgrade and the backup importer in their existing write
// transaction. Only the new foreign key is added to historical versions.
export async function materializeLegacyWorldClaims(store, { versionIds, knowledgeIds } = {}) {
  if (typeof store.transaction === 'function') {
    return store.transaction('rw', ['factVersions', 'worldClaims', 'knowledgeEvents'],
      tx => materializeLegacyWorldClaims(tx, { versionIds, knowledgeIds }))
  }
  const versions = store.table('factVersions')
  const claims = store.table('worldClaims')
  const events = store.table('knowledgeEvents')
  const unlinked = async (table, ids) => Array.isArray(ids)
    ? (await table.bulkGet(ids)).filter(row => row && !row.claimId)
    : table.filter(row => !row.claimId).toArray()
  const legacy = await unlinked(versions, versionIds)
  legacy.sort((left, right) => left.recordedSeq - right.recordedSeq || left.id.localeCompare(right.id))
  const insertedClaimIds = []
  const linkedVersionIds = []
  const linkedKnowledgeIds = []
  for (const version of legacy) {
    const row = legacyWorldClaimForVersion(version)
    if (!(await claims.get(row.id))) {
      await claims.add(row)
      insertedClaimIds.push(row.id)
    }
    await versions.update(version.id, { claimId: row.id })
    linkedVersionIds.push(version.id)
  }
  for (const event of await unlinked(events, knowledgeIds)) {
    const version = event.factVersionId && await versions.get(event.factVersionId)
    if (!version?.claimId || version.scopeKey !== event.scopeKey) continue
    await events.update(event.id, { claimId: version.claimId })
    linkedKnowledgeIds.push(event.id)
  }
  return { insertedClaimIds, linkedVersionIds, linkedKnowledgeIds }
}

export async function listWorldStatements(db, { scope } = {}) {
  const normalized = normalizeScopeRef(scope)
  if (!normalized.ok) return normalized
  const scopeKey = encodeScopeKey(normalized.scope)
  try {
    return await db.transaction('r', ['worldClaims', 'factVersions'], async () => {
      const [claims, versions] = await Promise.all([
        db.table('worldClaims').where('scopeKey').equals(scopeKey).toArray(),
        db.table('factVersions').where('scopeKey').equals(scopeKey).toArray()
      ])
      const historical = new Set()
      const active = new Map()
      for (const row of versions) {
        if (!row.claimId) continue
        historical.add(row.claimId)
        if (!row.supersedesKind && isVisibleAt(row) && (!active.has(row.claimId) || row.recordedSeq > active.get(row.claimId).recordedSeq)) {
          active.set(row.claimId, row)
        }
      }
      const items = claims.sort((a, b) => b.recordedSeq - a.recordedSeq || a.id.localeCompare(b.id)).map(claim => {
        const head = active.get(claim.id)
        return head
          ? { ...claim, authority: 'fact', factVersionId: head.id, factKey: head.factKey, validInterval: head.validInterval }
          : { ...claim, authority: historical.has(claim.id) ? 'historical' : 'rumor' }
      })
      return { ok: true, items }
    })
  } catch (error) {
    return { ok: false, reason: 'db-unavailable', detail: error?.message || String(error), items: [] }
  }
}
