import { listWorldCalendars } from './worldCalendars.js'
import { normalizeScopeRef, encodeScopeKey, worldClaimId } from './ledgerContract.js'
import { stableStringify } from '../knowledgeContract.js'
import { factForkSession } from './worldFactFork.js'

function groupVersions(rows) {
  const groups = new Map()
  for (const row of rows) {
    const group = groups.get(row.factKey) || []
    // Both scopes have their own writable claim/version IDs. Compare the
    // underlying assertion and its authored bounds rather than those IDs.
    const interval = row.validInterval
    const signature = stableStringify([worldClaimId('', row), interval ?
      [interval.timelineId, interval.start, interval.end, interval.endSemantic] : null])
    group.push({ row, signature })
    groups.set(row.factKey, group)
  }
  for (const group of groups.values()) group.sort((a, b) => a.signature.localeCompare(b.signature))
  return groups
}

export function compareWorldVersions(baseline, candidate) {
  const before = groupVersions(baseline)
  const after = groupVersions(candidate)
  const items = []
  for (const factKey of new Set([...before.keys(), ...after.keys()])) {
    const left = before.get(factKey) || [], right = after.get(factKey) || []
    if (left.length === right.length && left.every((entry, i) => entry.signature === right[i].signature)) continue
    items.push({ factKey, kind: !left.length ? 'added' : !right.length ? 'removed' : 'changed',
      baseline: left.map(entry => entry.row), branch: right.map(entry => entry.row) })
  }
  return items
}

export async function compareWorldFactFork(db, { scope, storyAt = null, storyClock = null }, readFacts) {
  const child = normalizeScopeRef(scope)
  if (!child.ok || child.scope.domain !== 'session' || child.scope.sessionId !== factForkSession || !child.scope.bookId) return { ok: false, reason: 'fork-scope-invalid' }
  const parent = { domain: 'book', bookId: child.scope.bookId }
  const key = encodeScopeKey(child.scope)
  return db.transaction('r', ['factDecisions', 'factVersions', 'ledgerMeta'], async () => {
    const origin = await db.table('factDecisions').where('[scopeKey+operation+recordedSeq]')
      .between([key, 'fork-world-facts', 0], [key, 'fork-world-facts', Number.MAX_SAFE_INTEGER], true, true).first()
    const fork = origin?.result?.fork
    if (fork?.parentScopeKey !== encodeScopeKey(parent)) return { ok: false, reason: 'fork-scope-invalid' }
    const [baseline, branch, baselineClocks, branchClocks] = await Promise.all([
      readFacts(db, { scope: parent, storyAt, storyClock, recordedSeq: fork.parentRecordedSeq }),
      readFacts(db, { scope: child.scope, storyAt, storyClock }),
      listWorldCalendars(db, { scope: parent, recordedSeq: fork.parentRecordedSeq }),
      listWorldCalendars(db, { scope: child.scope })
    ])
    if (!baseline.ok) return baseline
    if (!branch.ok) return branch
    const adopted = await db.table('factDecisions').where('[scopeKey+operation+recordedSeq]').between(
      [fork.parentScopeKey, 'adopt-fork-fact', 0], [fork.parentScopeKey, 'adopt-fork-fact', Number.MAX_SAFE_INTEGER], true, true)
      .filter(row => row.result?.adoptedFromFork?.forkId === origin.id).toArray()
    return { ok: true, adopted: adopted.map(row => row.result.adoptedFromFork.factVersionId), items: compareWorldVersions(baseline.items, branch.items), parentRecordedSeq: fork.parentRecordedSeq,
      baselineUnknown: baseline.unknownTimeCount, branchUnknown: branch.unknownTimeCount, baselineClocks: baselineClocks.items, branchClocks: branchClocks.items }
  })
}
